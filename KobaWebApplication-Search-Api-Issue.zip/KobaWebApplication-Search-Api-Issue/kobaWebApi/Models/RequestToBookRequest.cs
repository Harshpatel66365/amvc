﻿using System.ComponentModel.DataAnnotations;

namespace Koba.API.Models
{
    public class RequestToBookRequest
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        public string BookCategory { get; set; }
        
        [Required]
        public string BookSrNo { get; set; }
        
        [Required]
        [Display(Name ="Book Title/Name")]
        public string BookTitle { get; set; }
        
        [Required]
        public string RequestedPersonMobile { get; set; }        
        
        [Required]
        public string RequestedPersonName { get; set; }
        
        [Required]
        public string RequestedPersonCity { get; set; }
        
        [Required]
        public string RequestedPersonState { get; set; }
    }
}
