﻿using kobaWebApi.Models;

namespace Koba.API.Models
{
    public class KrutiInformation : Book
    {
        public string Kr_Key { get; set; }
        public string Kr_Nam { get; set; }
        public string AdiVakya { get; set; }
        public string AntimVakya { get; set; }
        public string Vid_Nam { get; set; }
        public string Year_Value { get; set; }
        public string Publisher_Name { get; set; }
        public string Language { get; set; }
        public string Year { get; set; }

        // New fields
        public string Main_Nam { get; set; }
        public string Swarup_Short_Name { get; set; }
        public string KrVid { get; set; }
        public string Prakar_Short_Name { get; set; }
        public string Vibhag_Code { get; set; }
        public string Dharma_Code { get; set; }
        public string KrYear { get; set; }
        public string Vir_St_Duration { get; set; }
        public string Vir_End_Duration { get; set; }
        public string Vik_st_Duration { get; set; }
        public string Isvi_st_Duration { get; set; }
        public string Granthagra { get; set; }
        public string KrChand { get; set; }
        public string KrAdhyay { get; set; }
        public string Related_Tot_Prksn { get; set; }
        public string Related_Tot_Hp { get; set; }
        public string Related_Tot_Mag_Ank_Petank { get; set; }
        public string Related_Tot_Childs { get; set; }
        public string Related_Tot_Aadharit_Kr { get; set; }
        public string Related_Tot_Aadharbhut_Kr { get; set; }
        public string Related_Tot_Karta_Group_Vidvan { get; set; }
        public string Related_Tot_Vidvan { get; set; }
        public string Related_Tot_Kr_Nam { get; set; }
        public string Vid_No { get; set; }
        public string Year_Type_Short_Name { get; set; }
    }

}
