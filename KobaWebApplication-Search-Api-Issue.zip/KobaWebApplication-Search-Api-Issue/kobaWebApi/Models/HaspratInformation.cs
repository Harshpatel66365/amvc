﻿using kobaWebApi.Models;

namespace Koba.API.Models
{
    public class HaspratInformation : Book
    {
        public string Hp_Nam { get; set; }
        public string Bhandar_Code { get; set; }
        public string Hp_No { get; set; }
        public string Lipi_Short_Nm { get; set; }
        public string Year { get; set; }
        public string Bhandar_Short_Name { get; set; }

        // New fields
        public string Main_Nam { get; set; }
        public string Hp_Tot_Pet { get; set; }
        public string Purnata_Short_Name { get; set; }
        public string Dasha_Short_Name { get; set; }
        public string Lipi_Short_Name { get; set; }
        public string Material_Short_Name { get; set; }
        public string Hp_Type_Short_Name { get; set; }
        public string Dharma_Code { get; set; }
        public string Pgs_Net { get; set; }
        public string Length_Min { get; set; }
        public string Width_Min { get; set; }
        public string Lines_Min { get; set; }
        public string Char_Min { get; set; }
        public string Lekhan_Prakar_Short_Name { get; set; }
        public string Related_Tot_Vidvan { get; set; }
        public string Related_Tot_Kruti { get; set; }
        public string Related_Tot_Laksn { get; set; }
        public string Related_Tot_Dasha_Detail_Codes { get; set; }
        public string Related_Tot_Nam { get; set; }
        public string Related_Tot_Shlok { get; set; }
        public string Related_Tot_Year { get; set; }
        public string Related_Tot_City { get; set; }
        public string Related_Tot_Internal_Issue { get; set; }
        public string Related_Tot_External_Issue { get; set; }
        public string Related_Tot_Xerox_Issue { get; set; }
        public string HpYear { get; set; }
        public string Vir_End_Year { get; set; }
        public string Vik_St_Year { get; set; }
        public string Isvi_St_Year { get; set; }
        public string Vid_Type_Short_Name { get; set; }
        public string Vid_No { get; set; }
        public string Vid_Nam { get; set; }
        public string year_value { get; set; }
        public string year_type_short_name { get; set; }
    }

}
