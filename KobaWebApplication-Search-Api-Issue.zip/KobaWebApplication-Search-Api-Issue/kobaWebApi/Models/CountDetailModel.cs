﻿namespace Koba.API.Models
{
    public class Bucket
    {
        public string Key { get; set; }
        public int DocCount { get; set; }
    }

    public class AggregationResult
    {
        public List<Bucket> Buckets { get; set; }
    }
}
