﻿namespace Koba.API.Models.Enum
{
    public enum ElasticSearchIndexEnum
    {
        elk_koba_kruti_new,
        elk_koba_prakashan_new,
        elk_koba_hastprat_new,
        elk_koba_vidvan_new
    }
}