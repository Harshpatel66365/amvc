﻿namespace kobaWebApi.Models
{
    public class ElasticsearchSettings
    {
        public string Node { get; set; }
        public string DefaultIndex { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
