﻿namespace Koba.API.Models
{
    public class HaspratInfoDto
    {
        public string? Hp_No { get; set; }
        public string? Bhandar_Code { get; set; }
        public string? Bhandar_Name { get; set; }
        public string? lipi_name { get; set; }
        public string? year_value { get; set; }
        public string? Hp_Tot_Pet { get; set; }
        public string? Purnata_short_name { get; set; }
        public string? Dasha_Short_Name { get; set; }        
        public string? Lipi_Short_Name { get; set; }
        public string? Material_Short_Name { get; set; }
        public string? Hp_Type_Short_Name { get; set; }
        public string? Dharma_Code { get; set; }        
        public int? Pgs_Net { get; set; }
        public decimal? Length_Min { get; set; }
        public decimal? Width_Min { get; set; }
        public int? Lines_Min { get; set; }
        public int? Lines_Max { get; set; }
        public int? Char_Min { get; set; }
        public string? Lekhan_Prakar_short_name { get; set; }
        public int? Related_Tot_Vidvan { get; set; }
        public int? Related_Tot_Kruti { get; set; }
        public int? Related_Tot_Laksn { get; set; }
        public int? Related_Tot_Dasha_Detail_Codes { get; set; }
        public int? Related_Tot_Nam { get; set; }
        public int? Related_Tot_Shlok { get; set; }
        public int? Related_Tot_Year { get; set; }
        public int? Related_Tot_City { get; set; }
        public int? Related_Tot_Internal_Issue { get; set; }
        public int? Related_Tot_External_Issue { get; set; }
        public int? Related_Tot_Xerox_Issue { get; set; }
        public string? Hp_Nam { get; set; }
        public string? Main_Nam { get; set; }
        public string? year_type_short_name { get; set; }
        public string? Bhandar_Short_Name { get; set; }
        public string? Name_Type_Short_Name { get; set; }
        public short? vir_st_year { get; set; }
        public short? vir_end_year { get; set; }
        public string? vid_No { get; set; }
        public string? Vid_Type_Short_Name { get; set; }
        public string? Vid_Name { get; set; }

    }
}
