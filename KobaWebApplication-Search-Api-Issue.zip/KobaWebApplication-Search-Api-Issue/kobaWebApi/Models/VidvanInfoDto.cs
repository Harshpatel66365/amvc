﻿namespace Koba.API.Models
{
    public class VidvanInfoDto
    {
        public string? Vid_No { get; set; }
        public string? Swarup_Short_Name { get; set; }
        public string? Vid_Nam { get; set; }
        public string? Guru_Swarup { get; set; }
        public string? Guru_Name { get; set; }
        public string? Dada_Guru_Swarup { get; set; }
        public string? Dada_Guru_Name { get; set; }
        public string? Gach_nam { get; set; }
        public string? Year_Type_Short_Name { get; set; }
        public string? Vid_Duration { get; set; }
        public int? Related_Tot_Kr { get; set; }
        public int? Related_Tot_Prksn { get; set; }
        public int? Related_Tot_Hp { get; set; }
        public int? Related_Tot_Pblsr { get; set; }
        public int? Related_Tot_Series { get; set; }
        public int? Related_Tot_Mag_ank { get; set; }
        public int? Related_Tot_Mag_Ank_Petank { get; set; }
        public int? Related_Tot_Museum_Antique { get; set; }
        public int? Related_Tot_Child { get; set; }
        public string? Name_Type_Short_Name { get; set; }
        public string? Guru_Vid_No { get; set; }
        public string? Dada_Guru_Vid_No { get; set; }

        public string? Gach_Key { get; set; }
        public string? year_value { get; set; }
        public short? vir_st_duration { get; set; }
        public short? vir_end_duration { get; set; }
        public string? Dharma_Code { get; set; }
        public string? Sadhu_Grihast_Code { get; set; }

        public string? Male_Female_Code { get; set; }

    }
}
