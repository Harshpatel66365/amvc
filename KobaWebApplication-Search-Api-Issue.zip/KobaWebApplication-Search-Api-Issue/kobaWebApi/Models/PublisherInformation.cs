﻿using kobaWebApi.Models;

namespace Koba.API.Models
{
    public class PublisherInformation : Book
    {
        public string Prksn_Key { get; set; }
        public string Prksn_Nam { get; set; }
        public string Pblsr_Nam { get; set; }
        public string Prksn_Year { get; set; }
        public string Vir_St_Duration { get; set; }
        public string Vir_End_Duration { get; set; }
        public string Dharma_Code { get; set; }
        public string Language { get; set; }
        public string Year { get; set; }

        // Additional fields
        public string Edition { get; set; }
        public string Reprint { get; set; }
        public string PrksnYr { get; set; }
        public string Vik_st_Duration { get; set; }
        public string Isvi_st_Duration { get; set; }
        public string Vol_Sub_Vol { get; set; }
        public string Pages { get; set; }
        public string Isbn { get; set; }
        public string Isbn_Set_No { get; set; }
        public string Purnata_short_name { get; set; }
        public string Tot_Petank { get; set; }
        public string Prksn_Pet_No { get; set; }
        public string Pet_Pages { get; set; }
        public string Related_Tot_Editor_Group_Only { get; set; }
        public string Related_Tot_All_Vidvan { get; set; }
        public string Related_Tot_Book { get; set; }
        public string Related_Tot_Nam { get; set; }
        public string Related_Tot_Image { get; set; }
        public string Related_Tot_Emedia { get; set; }
        public string Series_Key { get; set; }
        public string Series_Nam { get; set; }
        public string Vid_No { get; set; }
        public string PrksnVid { get; set; }
        public string JPdf1 { get; set; }
        public string JPdf2 { get; set; }
        public string Year_type_short_name { get; set; }
        public string Jild { get; set; }
    }

}
