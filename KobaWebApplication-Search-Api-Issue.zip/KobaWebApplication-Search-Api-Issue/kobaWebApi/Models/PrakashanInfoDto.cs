﻿namespace Koba.API.Models
{
    public class PrakashanInfoDto
    {
        public string Prksn_Key { get; set; }
        public int? Edition { get; set; }
        public int? Reprint { get; set; }
        public string? Year_Type_Short_Name { get; set; }
        public string? Prksn_Year { get; set; }
        public string? Vol_Sub_Vol { get; set; }
        public string? Pages { get; set; }
        public string? Isbn { get; set; }
        public string? Isbn_Set_No { get; set; }
        public string? Purnata_short_name { get; set; }
        public string? Dharma_Code { get; set; }
        public string? Tot_Petank { get; set; }
        public string? Prksn_Nam { get; set; }
        public string? Prksn_Pet_No { get; set; }
        public string? Pet_Pages { get; set; }
        public string? Pblsr_Nam { get; set; }
        public string? City_Nam { get; set; }
        public int Related_Tot_Editor_Group_Only { get; set; }
        public int Related_Tot_All_Vidvan { get; set; }
        public int Related_Tot_Book { get; set; }
        public int Related_Tot_Nam { get; set; }
        public int Related_Tot_Image { get; set; }
        public int Related_Tot_Emedia { get; set; }

        public short? vir_st_duration { get; set; }
        public short? vir_end_duration { get; set; }
        public string name_type { get; set; }
        public string pet_no { get; set; }
        public string series_key { get; set; }
        public string series_name { get; set; }
    }
}
