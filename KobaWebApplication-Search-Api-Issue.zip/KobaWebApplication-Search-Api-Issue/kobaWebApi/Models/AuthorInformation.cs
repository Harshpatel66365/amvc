﻿using kobaWebApi.Models;

namespace Koba.API.Models
{
    public class AuthorInformation : Book
    {
        public string Vid_No { get; set; }
        public string Vid_Nam { get; set; }
        public string Vid_Nam_filtered { get; set; }
        public string Dharma_Code { get; set; }
        public string Gach_Key { get; set; }
        public string Gach_nam { get; set; }
        public string Vid_Duration { get; set; }
        public int Kruti_count { get; set; }
        public int Prakashan_count { get; set; }
        public int Hashprath_count { get; set; }
        public string Guru_Name { get; set; }
        public string Year { get; set; }

        // New fields
        public string Dada_Guru_Name { get; set; }
        public string Vir_St_Duration { get; set; }
        public string Vir_End_Duration { get; set; }
        public string Vik_st_Duration { get; set; }
        public string Isvi_st_Duration { get; set; }
        public string Related_Tot_Kr { get; set; }
        public string Related_Tot_Prksn { get; set; }
        public string Related_Tot_Hp { get; set; }
        public string Related_Tot_Pblsr { get; set; }
        public string Related_Tot_Series { get; set; }
        public string Related_Tot_Mag_ank { get; set; }
        public string Related_Tot_Mag_Ank_Petank { get; set; }
        public string Related_Tot_Museum_Antique { get; set; }
        public string Related_Tot_Child { get; set; }
        public string Sadhu_Grihast_Code { get; set; }
        public string Male_Female_Code { get; set; }
    }

}
