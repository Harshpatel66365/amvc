﻿using Nest;

namespace kobaWebApi.Models
{
    public class Book
    {
    }
}
