﻿using Koba.API.Models;

namespace Koba.API.Services
{
    public interface IEmailService
    {
        Task SendEmailAsync(string subject, RequestToBookRequest message);
    }
}
