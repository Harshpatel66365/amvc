﻿using Koba.API.DBContext;
using Koba.API.Models;
using Koba.API.Models.Enum;
using Koba.API.Repository.Interface;
using kobaWebApi.Models;
using KobaWebApplication.Dto.Browser;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Nest;
using Newtonsoft.Json;
using System.Text.RegularExpressions;

namespace kobaWebApi.Services
{
    public class ElasticsearchService
    {
        private readonly ElasticClient _client;
        private readonly ElasticsearchSettings _settings;
        private readonly IHashpratRepository _hashpratRepository;
        private readonly IKrutiRepository _krutiRepository;
        private readonly IAuthorRepository _authorRepository;
        private readonly IPrakashanRepository _prakashanRepository;
        private ApplicationDBContext _dbContext;

        private readonly string googleTranslateApiKey = "AIzaSyDEzEeYdMN2uAxAWOW40R566MZ-Ug6KRko";
        private readonly string indexes = "elk_koba_vidvan_new,elk_koba_hastprat_new,elk_koba_kruti_new,elk_koba_prakashan_new";

        public ElasticsearchService(IOptions<ElasticsearchSettings> elasticSettings, ApplicationDBContext applicationDBContext, IHashpratRepository hashpratRepository, IKrutiRepository krutiRepository,
            IAuthorRepository authorRepository, IPrakashanRepository prakashanRepository)
        {
            _settings = elasticSettings.Value;
            var node = new Uri(_settings.Node);
            var settings = new ConnectionSettings(node)
                .DefaultIndex(_settings.DefaultIndex) // default index, can be overridden in each method
                .BasicAuthentication(_settings.Username, _settings.Password)
                .ServerCertificateValidationCallback((sender, certificate, chain, sslPolicyErrors) => true);

            _client = new ElasticClient(settings);
            _dbContext = applicationDBContext;
            _hashpratRepository = hashpratRepository;
            _krutiRepository = krutiRepository;
            _authorRepository = authorRepository;
            _prakashanRepository = prakashanRepository;
        }

        public async Task<SearchResultDto> SearchAsync(KobaWebApplication.Dto.Browser.SearchRequest request)
        {
            var TranslatedWords = await GetTranslatedWords(request.SearchTerm);

            SearchResultDto searchResultDto = new SearchResultDto();
            if (request.SelectedIndex.ToLower() == "prakashan")
            {
                var result = await _client.SearchAsync<PublisherInformation>(s => s
                    .Index(request.IndexName.ToLower()) // Use the selected index
                    .From((request.PageNumber - 1) * request.PageSize)
                    .Size(request.PageSize)
                    .Query(q => q
                        .Bool(b =>
                        {
                            b.Should(
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("en") ?? request.SearchTerm) // English or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(3) // Higher boost for English matches
                                ),
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("hi") ?? request.SearchTerm) // Hindi or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(2) // Slightly lower boost for Hindi matches
                                ),
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("gu") ?? request.SearchTerm) // Gujarati or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(1.5) // Lower boost for Gujarati matches
                                ),
                                sh => sh.Term(t => t
                                    .Field("prksn_Nam") // The field you want exact term matches on
                                    .Value(request.SearchTerm)
                                    .Boost(5) // Highest priority for exact matches
                                )
                            );

                            b.MinimumShouldMatch(1); // At least one should match

                            // Add the filter only if IsAdvanceSearch is true
                            if (request.IsAdvanceSearch && request.filterCriterias != null)
                            {
                                var filters = new List<Func<QueryContainerDescriptor<PublisherInformation>, QueryContainer>>();

                                foreach (var filter in request.filterCriterias)
                                {
                                    // Apply filters only if the index name is "prakashan"
                                    if (filter.IndexName.ToLower() == "prakashan")
                                    {
                                        if (!string.IsNullOrEmpty(filter.SearchTerm))
                                        {
                                            var termsArray = filter.SearchTerm.Split(',').Select(term => term.Trim()).ToArray();

                                            switch (filter.FieldName)
                                            {
                                                case "dharma_code":
                                                    if (termsArray.Contains("(empty)"))
                                                    {
                                                        filters.Add(f => f.Term(t => t
                                                                        .Field(f => f.Dharma_Code.Suffix("keyword"))
                                                                        .Value("")
                                                                    ));
                                                        termsArray = termsArray.Where(term => term != "(empty)").ToArray();
                                                    }

                                                    filters.Add(f => f.Terms(t => t
                                                                    .Field(f => f.Dharma_Code.Suffix("keyword"))
                                                                    .Terms(termsArray)
                                                                ));
                                                    break;

                                                case "edition":
                                                    if (termsArray.Contains("(empty)"))
                                                    {
                                                        filters.Add(f => f.Term(t => t
                                                                        .Field(f => f.Edition.Suffix("keyword"))
                                                                        .Value("")
                                                                    ));
                                                        termsArray = termsArray.Where(term => term != "(empty)").ToArray();
                                                    }

                                                    filters.Add(f => f.Terms(t => t
                                                                    .Field(f => f.Edition.Suffix("keyword"))
                                                                    .Terms(termsArray)
                                                                ));
                                                    break;

                                                case "pblsr_Nam":
                                                    if (termsArray.Contains("(empty)"))
                                                    {
                                                        filters.Add(f => f.Term(t => t
                                                                        .Field(f => f.Pblsr_Nam.Suffix("keyword"))
                                                                        .Value("")
                                                                    ));
                                                        termsArray = termsArray.Where(term => term != "(empty)").ToArray();
                                                    }

                                                    filters.Add(f => f.Terms(t => t
                                                                    .Field(f => f.Pblsr_Nam.Suffix("keyword"))
                                                                    .Terms(termsArray)
                                                                ));
                                                    break;

                                                case "granthmala":
                                                    if (termsArray.Contains("(empty)"))
                                                    {
                                                        filters.Add(f => f.Term(t => t
                                                                        .Field(f => f.Series_Nam.Suffix("keyword"))
                                                                        .Value("")
                                                                    ));
                                                        termsArray = termsArray.Where(term => term != "(empty)").ToArray();
                                                    }

                                                    filters.Add(f => f.Terms(t => t
                                                                    .Field(f => f.Series_Nam.Suffix("keyword"))
                                                                    .Terms(termsArray)
                                                                ));
                                                    break;
                                            }
                                        }

                                        if (filter.start > 0 && filter.end > 0)
                                        {
                                            filters.Add(f => f.Range(r => r
                                                .Field(filter.FieldName)
                                                .GreaterThanOrEquals(filter.start - 1)
                                                .LessThanOrEquals(filter.end)
                                            ));
                                        }
                                    }
                                }

                                // Apply the filters only if "prakashan" filters were added
                                if (filters.Any())
                                {
                                    b.Filter(f => f.Bool(bf => bf.Must(filters)));
                                }
                            }

                            return b;
                        })
                    )
                );

                searchResultDto.TotalCount = result.Total;

                var searchResults = new List<SearchResult>();
                foreach (var item in result.Hits.Where(x => x.Source.Prksn_Key != null))
                {
                    searchResults.Add(new SearchResult
                    {
                        Index = item.Index.Replace("elk_koba_", "").Replace("_new", ""),
                        Source = item.Source
                    });
                }
                searchResultDto.Results = searchResults;
                return searchResultDto;
            }
            else if (request.SelectedIndex.ToLower() == "hastprat")
            {
                var result = await _client.SearchAsync<HaspratInformation>(s => s
                    .Index(request.IndexName.ToLower()) // Use the selected index
                    .From((request.PageNumber - 1) * request.PageSize)
                    .Size(request.PageSize)
                    .Query(q => q
                        .Bool(b =>
                        {
                            b.Should(
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("en") ?? request.SearchTerm) // English or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(3) // Higher boost for English matches
                                ),
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("hi") ?? request.SearchTerm) // Hindi or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(2) // Slightly lower boost for Hindi matches
                                ),
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("gu") ?? request.SearchTerm) // Gujarati or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(1.5) // Lower boost for Gujarati matches
                                ),
                                sh => sh.Term(t => t
                                    .Field("hp_Nam") // The field you want exact term matches on
                                    .Value(request.SearchTerm)
                                    .Boost(5) // Give an even higher boost to exact term matches
                                )
                            );
                            b.MinimumShouldMatch(1); // At least one should match

                            // Add the filter only if IsAdvanceSearch is true
                            if (request.IsAdvanceSearch && request.filterCriterias != null)
                            {
                                var filters = new List<Func<QueryContainerDescriptor<HaspratInformation>, QueryContainer>>();

                                foreach (var filter in request.filterCriterias)
                                {
                                    if (!string.IsNullOrEmpty(filter.SearchTerm))
                                    {
                                        var termsArray = filter.SearchTerm.Split(',').Select(term => term.Trim()).ToArray();

                                        switch (filter.FieldName)
                                        {
                                            case "lipi_Short_Nm":
                                                if (termsArray.Contains("(empty)"))
                                                {
                                                    filters.Add(f => f.Term(t => t
                                                                    .Field(f => f.Lipi_Short_Nm.Suffix("keyword"))
                                                                    .Value("")
                                                                ));
                                                    termsArray = termsArray.Where(term => term != "(empty)").ToArray();
                                                }

                                                filters.Add(f => f.Terms(t => t
                                                                .Field(f => f.Lipi_Short_Nm.Suffix("keyword"))
                                                                .Terms(termsArray)
                                                            ));
                                                break;

                                            case "bhandar_Short_Name":
                                                if (termsArray.Contains("(empty)"))
                                                {
                                                    filters.Add(f => f.Term(t => t
                                                                    .Field(f => f.Bhandar_Short_Name.Suffix("keyword"))
                                                                    .Value("")
                                                                ));
                                                    termsArray = termsArray.Where(term => term != "(empty)").ToArray();
                                                }

                                                filters.Add(f => f.Terms(t => t
                                                                .Field(f => f.Bhandar_Short_Name.Suffix("keyword"))
                                                                .Terms(termsArray)
                                                            ));
                                                break;

                                            case "vid_Type_Short_Name":
                                                if (termsArray.Contains("(empty)"))
                                                {
                                                    filters.Add(f => f.Term(t => t
                                                                    .Field(f => f.Vid_Type_Short_Name.Suffix("keyword"))
                                                                    .Value("")
                                                                ));
                                                    termsArray = termsArray.Where(term => term != "(empty)").ToArray();
                                                }

                                                filters.Add(f => f.Terms(t => t
                                                                .Field(f => f.Vid_Type_Short_Name.Suffix("keyword"))
                                                                .Terms(termsArray)
                                                            ));
                                                break;

                                            case "vid_Nam":
                                                if (termsArray.Contains("(empty)"))
                                                {
                                                    filters.Add(f => f.Term(t => t
                                                                    .Field(f => f.Vid_Nam.Suffix("keyword"))
                                                                    .Value("")
                                                                ));
                                                    termsArray = termsArray.Where(term => term != "(empty)").ToArray();
                                                }

                                                filters.Add(f => f.Terms(t => t
                                                                .Field(f => f.Vid_Nam.Suffix("keyword"))
                                                                .Terms(termsArray)
                                                            ));
                                                break;
                                        }
                                    }

                                    if (filter.start > 0 && filter.end > 0)
                                    {
                                        filters.Add(f => f.Range(r => r
                                            .Field(filter.FieldName)
                                            .GreaterThanOrEquals(filter.start - 1)
                                            .LessThanOrEquals(filter.end)
                                        ));
                                    }
                                }

                                // Apply the filters only if "hastprat" filters were added
                                if (filters.Any())
                                {
                                    b.Filter(f => f.Bool(bf => bf.Must(filters)));
                                }
                            }

                            return b;
                        })
                    )
                );

                searchResultDto.TotalCount = result.Total;

                var searchResults = new List<SearchResult>();
                for (int i = 0; i < result.Hits.Count; i++)
                {
                    searchResults.Add(new SearchResult
                    {
                        Index = result.Hits.ToList()[i].Index.Replace("elk_koba_", "").Replace("_new", ""),
                        Source = result.Hits.ToList()[i].Source
                    });
                }

                searchResultDto.Results = searchResults;
                return searchResultDto;
            }
            else if (request.SelectedIndex.ToLower() == "kruti")
            {
                var result = await _client.SearchAsync<KrutiInformation>(s => s
                    .Index(request.IndexName.ToLower()) // Use the selected index
                    .From((request.PageNumber - 1) * request.PageSize)
                    .Size(request.PageSize)
                    .Query(q => q
                        .Bool(b =>
                        {
                            b.Should(
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("en") ?? request.SearchTerm) // English or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(3) // Higher boost for English matches
                                ),
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("hi") ?? request.SearchTerm) // Hindi or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(2) // Slightly lower boost for Hindi matches
                                ),
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("gu") ?? request.SearchTerm) // Gujarati or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(1.5) // Even lower boost for Gujarati matches
                                ),
                                sh => sh.Term(t => t
                                    .Field("kr_Nam") // The field you want exact term matches on
                                    .Value(request.SearchTerm)
                                    .Boost(5) // Give an even higher boost to exact term matches
                                )
                            );
                            b.MinimumShouldMatch(1); // At least one should match

                            // Add the filter only if IsAdvanceSearch is true
                            if (request.IsAdvanceSearch && request.filterCriterias != null)
                            {
                                var filters = new List<Func<QueryContainerDescriptor<KrutiInformation>, QueryContainer>>();

                                foreach (var filter in request.filterCriterias)
                                {
                                    // Apply filters only if the index name is "kruti"
                                    if (filter.IndexName.ToLower() == "kruti")
                                    {
                                        if (!string.IsNullOrEmpty(filter.SearchTerm))
                                        {
                                            var termsArray = filter.SearchTerm.Split(',').Select(term => term.Trim()).ToArray();

                                            switch (filter.FieldName)
                                            {
                                                case "language":
                                                    if (termsArray.Contains("(empty)"))
                                                    {
                                                        filters.Add(f => f.Term(t => t
                                                                        .Field(f => f.Language.Suffix("keyword"))
                                                                        .Value("")
                                                                    ));
                                                        termsArray = termsArray.Where(term => term != "(empty)").ToArray();
                                                    }

                                                    filters.Add(f => f.Terms(t => t
                                                                    .Field(f => f.Language.Suffix("keyword"))
                                                                    .Terms(termsArray)
                                                                ));
                                                    break;

                                                case "publisher_Name":
                                                    if (termsArray.Contains("(empty)"))
                                                    {
                                                        filters.Add(f => f.Term(t => t
                                                                        .Field(f => f.Publisher_Name.Suffix("keyword"))
                                                                        .Value("")
                                                                    ));
                                                        termsArray = termsArray.Where(term => term != "(empty)").ToArray();
                                                    }

                                                    filters.Add(f => f.Terms(t => t
                                                                    .Field(f => f.Publisher_Name.Suffix("keyword"))
                                                                    .Terms(termsArray)
                                                                ));
                                                    break;
                                            }
                                        }

                                        if (filter.start > 0 && filter.end > 0)
                                        {
                                            filters.Add(f => f.Range(r => r
                                                .Field(filter.FieldName)
                                                .GreaterThanOrEquals(filter.start - 1)
                                                .LessThanOrEquals(filter.end)
                                            ));
                                        }
                                    }
                                }

                                // Apply the filters only if "kruti" filters were added
                                if (filters.Any())
                                {
                                    b.Filter(f => f.Bool(bf => bf.Must(filters)));
                                }
                            }

                            return b;
                        })
                    )
                );

                searchResultDto.TotalCount = result.Total;

                var searchResults = new List<SearchResult>();
                for (int i = 0; i < result.Hits.Count; i++)
                {
                    searchResults.Add(new SearchResult
                    {
                        Index = result.Hits.ToList()[i].Index.Replace("elk_koba_", "").Replace("_new", ""),
                        Source = result.Hits.ToList()[i].Source
                    });
                }

                searchResultDto.Results = searchResults;
                return searchResultDto;
            }
            else if (request.SelectedIndex.ToLower() == "vidvan")
            {
                var result = await _client.SearchAsync<AuthorInformation>(s => s
                    .Index(request.IndexName.ToLower()) // Use the selected index
                    .From((request.PageNumber - 1) * request.PageSize)
                    .Size(request.PageSize)
                    .Query(q => q
                        .Bool(b =>
                        {
                            b.Should(
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("en") ?? request.SearchTerm) // English or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(3) // Higher boost for English matches
                                ),
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("hi") ?? request.SearchTerm) // Hindi or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(2) // Slightly lower boost for Hindi matches
                                ),
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("gu") ?? request.SearchTerm) // Gujarati or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(1.5) // Even lower boost for Gujarati matches
                                ),
                                sh => sh.Term(t => t
                                    .Field("vid_Nam") // Exact term match field
                                    .Value(request.SearchTerm)
                                    .Boost(5) // Higher boost for exact term matches
                                )
                            );
                            b.MinimumShouldMatch(1); // At least one should match

                            // Add the filter only if IsAdvanceSearch is true
                            if (request.IsAdvanceSearch && request.filterCriterias != null)
                            {
                                var filters = new List<Func<QueryContainerDescriptor<AuthorInformation>, QueryContainer>>();

                                foreach (var filter in request.filterCriterias)
                                {
                                    if (filter.IndexName.ToLower() == "vidvan")
                                    {
                                        var termsArray = filter.SearchTerm.Split(',').Select(term => term.Trim()).ToArray();

                                        switch (filter.FieldName)
                                        {
                                            case "gach_name":
                                                if (termsArray.Contains("(empty)"))
                                                {
                                                    filters.Add(f => f.Term(t => t
                                                                    .Field(f => f.Gach_nam.Suffix("keyword"))
                                                                    .Value("")
                                                                ));
                                                    termsArray = termsArray.Where(term => term != "(empty)").ToArray();
                                                }

                                                filters.Add(f => f.Terms(t => t
                                                                  .Field(f => f.Gach_nam.Suffix("keyword"))
                                                                  .Terms(termsArray)
                                                                ));
                                                break;

                                            case "guru_name":
                                                if (termsArray.Contains("(empty)"))
                                                {
                                                    filters.Add(f => f.Term(t => t
                                                                    .Field(f => f.Guru_Name.Suffix("keyword"))
                                                                    .Value("")
                                                                ));
                                                    termsArray = termsArray.Where(term => term != "(empty)").ToArray();
                                                }
                                                if (termsArray.Count() > 0)
                                                    filters.Add(f => f.Terms(t => t
                                                                      .Field(f => f.Guru_Name.Suffix("keyword"))
                                                                      .Terms(termsArray)
                                                                    ));
                                                break;

                                            case "dadaguru_name":
                                                if (termsArray.Contains("(empty)"))
                                                {
                                                    filters.Add(f => f.Term(t => t
                                                                    .Field(f => f.Dada_Guru_Name.Suffix("keyword"))
                                                                    .Value("")
                                                                ));
                                                    termsArray = termsArray.Where(term => term != "(empty)").ToArray();
                                                }

                                                filters.Add(f => f.Terms(t => t
                                                                  .Field(f => f.Dada_Guru_Name.Suffix("keyword"))
                                                                  .Terms(termsArray)
                                                                ));
                                                break;

                                            case "genderCode":
                                                if (termsArray.Contains("(empty)"))
                                                {
                                                    filters.Add(f => f.Term(t => t
                                                                    .Field(f => f.Male_Female_Code.Suffix("keyword"))
                                                                    .Value("")
                                                                ));
                                                    termsArray = termsArray.Where(term => term != "(empty)").ToArray();
                                                }

                                                filters.Add(f => f.Terms(t => t
                                                                  .Field(f => f.Male_Female_Code.Suffix("keyword"))
                                                                  .Terms(termsArray)
                                                                ));
                                                break;

                                            case "gruhasth":
                                                if (termsArray.Contains("(empty)"))
                                                {
                                                    filters.Add(f => f.Term(t => t
                                                                    .Field(f => f.Sadhu_Grihast_Code.Suffix("keyword"))
                                                                    .Value("")
                                                                ));
                                                    termsArray = termsArray.Where(term => term != "(empty)").ToArray();
                                                }

                                                filters.Add(f => f.Terms(t => t
                                                                  .Field(f => f.Sadhu_Grihast_Code.Suffix("keyword"))
                                                                  .Terms(termsArray)
                                                                ));
                                                break;
                                        }

                                        if (filter.start > 0 && filter.end > 0)
                                        {
                                            filters.Add(f => f.Range(r => r
                                                .Field(filter.FieldName)
                                                .GreaterThanOrEquals(filter.start - 1)
                                                .LessThanOrEquals(filter.end)
                                            ));
                                        }
                                    }
                                }

                                // Apply the filters if any filters were added
                                if (filters.Any())
                                {
                                    b.Filter(f => f.Bool(bf => bf.Must(filters)));
                                }
                            }

                            return b;
                        })
                    )
                );

                searchResultDto.TotalCount = result.Total;

                var searchResults = new List<SearchResult>();
                foreach (var item in result.Hits)
                {
                    searchResults.Add(new SearchResult
                    {
                        Index = "vidvan", // Keep the index name "vidvan"
                        Source = item.Source
                    });
                }

                searchResultDto.Results = searchResults;
                return searchResultDto;
            }
            else
            {
                var response = await _client.SearchAsync<object>(s => s
                            .Index(indexes)
                            .From((request.PageNumber - 1) * request.PageSize)
                            .Size(request.PageSize)
                            .Query(q => q
                                .Bool(b =>
                                {
                                    b.Should(
                                        sh => sh.MultiMatch(mm => mm
                                            .Query(TranslatedWords.GetValueOrDefault("en") ?? request.SearchTerm) // English or fallback to search term
                                            .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                            .Operator(Operator.And)
                                            .Type(TextQueryType.BestFields)
                                            .Boost(3) // Higher boost for English matches
                                        ),
                                        sh => sh.MultiMatch(mm => mm
                                            .Query(TranslatedWords.GetValueOrDefault("hi") ?? request.SearchTerm) // Hindi or fallback to search term
                                            .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                            .Operator(Operator.And)
                                            .Type(TextQueryType.BestFields)
                                            .Boost(2) // Slightly lower boost for Hindi matches
                                        ),
                                        sh => sh.MultiMatch(mm => mm
                                            .Query(TranslatedWords.GetValueOrDefault("gu") ?? request.SearchTerm) // Gujarati or fallback to search term
                                            .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                            .Operator(Operator.And)
                                            .Type(TextQueryType.BestFields)
                                            .Boost(1.5) // Lower boost for Gujarati matches
                                        ),
                                        sh => sh.MultiMatch(mm => mm
                                            .Query(request.SearchTerm) // Search the exact term directly (across all fields)
                                            .Type(TextQueryType.Phrase) // Exact phrase match for closer results
                                            .Boost(5) // Give the highest priority to exact matches
                                        )
                                    );

                                    b.MinimumShouldMatch(1); // At least one should match

                                    // Add the filter only if IsAdvanceSearch is true
                                    if (request.IsAdvanceSearch && request.filterCriterias != null)
                                    {
                                        var filters = new List<Func<QueryContainerDescriptor<object>, QueryContainer>>();

                                        foreach (var filter in request.filterCriterias)
                                        {
                                            if (filter.start > 0 && filter.end > 0)
                                            {
                                                filters.Add(f => f.Range(r => r
                                                    .Field(filter.FieldName)
                                                    .GreaterThanOrEquals(filter.start - 1)
                                                    .LessThanOrEquals(filter.end)
                                                ));
                                            }
                                            else if (!string.IsNullOrEmpty(filter.SearchTerm))
                                            {
                                                // Use Match for full-text queries
                                                filters.Add(f => f.Match(m => m
                                                    .Field(filter.FieldName)
                                                    .Query(filter.SearchTerm)
                                                ));
                                            }
                                        }

                                        b.Filter(f => f.Bool(bf => bf
                                            .Must(filters)
                                        ));
                                    }

                                    return b;
                                })
                            )
                        );

                searchResultDto.TotalCount = response.Total;
                var searchResults = new List<SearchResult>();

                foreach (var hit in response.Hits)
                {
                    if (hit.Index.Contains("elk_koba_vidvan"))
                    {
                        //var res = _authorRepository.GetGuruNameByAuthorId(((IDictionary<string, object>)hit.Source)["vid_No"].ToString());
                        //((IDictionary<string, object>)hit.Source)["Guru_Name"] = res.Result.Guru_Name;

                        searchResults.Add(new SearchResult
                        {
                            Index = hit.Index.Replace("elk_koba_", "").Replace("_new", ""),
                            Source = hit.Source
                        });
                    }
                    else if (hit.Index.Contains("elk_koba_hastprat"))
                    {
                        //var HPDetails = _hashpratRepository.getByHPId(((IDictionary<string, object>)hit.Source)["Hp_No"].ToString());
                        //((IDictionary<string, object>)hit.Source)["Lipi_Short_Nm"] = HPDetails.Result.Lipi_Short_Name;
                        //((IDictionary<string, object>)hit.Source)["Year"] = HPDetails.Result.year_value;

                        searchResults.Add(new SearchResult
                        {
                            Index = hit.Index.Replace("elk_koba_", "").Replace("_new", ""),
                            Source = hit.Source
                        });
                    }
                    else if (hit.Index.Contains("elk_koba_kruti"))
                    {
                        //var krutiDetails = _krutiRepository.getByKrutiId(((IDictionary<string, object>)hit.Source)["kr_Key"].ToString());
                        //((IDictionary<string, object>)hit.Source)["Year_Value"] = krutiDetails.Result.Year_Value;
                        //((IDictionary<string, object>)hit.Source)["Publisher_Name"] = "NA";
                        //((IDictionary<string, object>)hit.Source)["Vid_Nam"] = krutiDetails.Result.Vid_Nam;

                        searchResults.Add(new SearchResult
                        {
                            Index = hit.Index.Replace("elk_koba_", "").Replace("_new", ""),
                            Source = hit.Source
                        });
                    }
                    else if (hit.Index.Contains("elk_koba_prakashan"))
                    {
                        //var HPDetails = _prakashanRepository.getByPrakashanId(((IDictionary<string, object>)hit.Source)["prksn_Key"].ToString());
                        //((IDictionary<string, object>)hit.Source)["prksn_Nam"] = HPDetails.Result.pblsr_name;
                        //((IDictionary<string, object>)hit.Source)["language"] = "NA";
                        //((IDictionary<string, object>)hit.Source)["year"] = HPDetails.Result.prksn_year;

                        searchResults.Add(new SearchResult
                        {
                            Index = hit.Index.Replace("elk_koba_", "").Replace("_new", ""),
                            Source = hit.Source
                        });
                    }
                }

                searchResultDto.Results = searchResults;
                return searchResultDto;
            }
        }

        public async Task<SearchCountResponseDto> GetCount(string searchTerm, bool IsExactSearch)
        {
            try
            {
                var TranslatedWords = await GetTranslatedWords(searchTerm);
                var searchResponse = _client.Search<AggregationResult>(s => s
                                            .Index(indexes)
                                            .Size(0)
                                            .Query(q => q
                                                .Bool(b => b
                                                    .Should(
                                                        sh => sh.MultiMatch(mm => mm
                                                            .Query(TranslatedWords.GetValueOrDefault("en") ?? searchTerm) // English or fallback to search term
                                                            .Fuzziness(IsExactSearch ? null : Fuzziness.Auto)
                                                            .Operator(Operator.And)
                                                            .Type(TextQueryType.BestFields)
                                                            .Boost(3) // Higher boost for English matches
                                                        ),
                                                        sh => sh.MultiMatch(mm => mm
                                                            .Query(TranslatedWords.GetValueOrDefault("hi") ?? searchTerm) // Hindi or fallback to search term
                                                            .Fuzziness(IsExactSearch ? null : Fuzziness.Auto)
                                                            .Operator(Operator.And)
                                                            .Type(TextQueryType.BestFields)
                                                            .Boost(2) // Slightly lower boost for Hindi matches
                                                        ),
                                                        sh => sh.MultiMatch(mm => mm
                                                            .Query(TranslatedWords.GetValueOrDefault("gu") ?? searchTerm) // Gujarati or fallback to search term
                                                            .Fuzziness(IsExactSearch ? null : Fuzziness.Auto)
                                                            .Operator(Operator.And)
                                                            .Type(TextQueryType.BestFields)
                                                            .Boost(1.5) // Lower boost for Gujarati matches
                                                        ),
                                                        sh => sh.MultiMatch(mm => mm
                                                            .Query(searchTerm) // Search the exact term directly (across all fields)
                                                            .Type(TextQueryType.Phrase) // Exact phrase match for closer results
                                                            .Boost(5) // Give the highest priority to exact matches
                                                        )
                                                    )
                                                    .MinimumShouldMatch(1) // At least one should match
                                                )
                                            )
                                            .Aggregations(a => a
                                                .Terms("counts_per_index", t => t
                                                    .Field("_index")
                                                    .Size(10)
                                                )
                                            )
                                        );

                var buckets = searchResponse.Aggregations.Terms("counts_per_index").Buckets;
                SearchCountResponseDto searchCountResponseDto = new SearchCountResponseDto();
                foreach (var bucket in buckets)
                {
                    if (bucket.Key == ElasticSearchIndexEnum.elk_koba_kruti_new.ToString())
                    {
                        searchCountResponseDto.KrutiCount = bucket.DocCount;
                    }
                    else if (bucket.Key == ElasticSearchIndexEnum.elk_koba_vidvan_new.ToString())
                    {
                        searchCountResponseDto.AuthorCount = bucket.DocCount;
                    }
                    else if (bucket.Key == ElasticSearchIndexEnum.elk_koba_hastprat_new.ToString())
                    {
                        searchCountResponseDto.hastpratCount = bucket.DocCount;
                    }
                    else if (bucket.Key == ElasticSearchIndexEnum.elk_koba_prakashan_new.ToString())
                    {
                        searchCountResponseDto.publisherCount = bucket.DocCount;
                    }
                }
                return searchCountResponseDto;
            }
            catch (Exception e)
            {
                return null;
            }
        }

        public async Task<string> IsParakashanAvailableInLibrary(string prksnNo)
        {
            var pdfImage300 = "";
            var result = await _dbContext.prksn_pdf_lnk
                       .Where(p => p.Prksn_Key == prksnNo)
                       .ToListAsync();
            if (result != null && result.Count > 0)
            {
                pdfImage300 = result.FirstOrDefault().Pdf_Image_300;
            }
            if (string.IsNullOrEmpty(pdfImage300))
            {
                return null;
            }

            string isAvailable = ContainsContinuousWords(pdfImage300, 6);

            if (isAvailable != string.Empty)
                return isAvailable;

            return null;
        }

        public async Task<SearchResultDto> GetSuggestionAsync(KobaWebApplication.Dto.Browser.SearchRequest request)
        {
            SearchResultDto searchResultDto = new SearchResultDto();
            var TranslatedWords = await GetTranslatedWords(request.SearchTerm);

            var response = await _client.SearchAsync<object>(s => s
                                    .Index(indexes) // Query across multiple indices
                                    .From((request.PageNumber - 1) * request.PageSize)
                                    .Size(10)
                                    .Query(q => q
                                        .Bool(b => b
                                            .Must(
                                                // Exact or prefix matches for each index field
                                                m => m.Bool(bq => bq
                                                    .Should(
                                                        sh => sh.Bool(bf => bf
                                                            .Filter(f => f.Term(t => t.Field("_index").Value("elk_koba_vidvan_new")))
                                                            .Must(mf => mf.Prefix(p => p.Field("vid_Nam").Value(request.SearchTerm.ToLower())))
                                                        ),
                                                        sh => sh.Bool(bf => bf
                                                            .Filter(f => f.Term(t => t.Field("_index").Value("elk_koba_hastprat_new")))
                                                            .Must(mf => mf.Prefix(p => p.Field("hp_Nam").Value(request.SearchTerm.ToLower())))
                                                        ),
                                                        sh => sh.Bool(bf => bf
                                                            .Filter(f => f.Term(t => t.Field("_index").Value("elk_koba_kruti_new")))
                                                            .Must(mf => mf.Prefix(p => p.Field("kr_Nam").Value(request.SearchTerm.ToLower())))
                                                        ),
                                                        sh => sh.Bool(bf => bf
                                                            .Filter(f => f.Term(t => t.Field("_index").Value("elk_koba_prakashan_new")))
                                                            .Must(mf => mf.Prefix(p => p.Field("prksn_Nam").Value(request.SearchTerm.ToLower())))
                                                        )
                                                    )
                                                )
                                            )
                                            .Should(
                                                // Boost exact matches for the primary search term
                                                sh => sh.MultiMatch(mm => mm
                                                    .Query(request.SearchTerm)
                                                    .Operator(Operator.And)
                                                    .Type(TextQueryType.BestFields)
                                                    .Boost(5) // Boost exact matches higher
                                                ),

                                                // Fuzzy match for English translation
                                                sh => sh.MultiMatch(mm => mm
                                                    .Query(TranslatedWords.GetValueOrDefault("en") ?? request.SearchTerm)
                                                    .Fuzziness(Fuzziness.Auto)
                                                    .Operator(Operator.And)
                                                    .Type(TextQueryType.BestFields)
                                                    .Boost(1) // Lower boost for fuzzy matches
                                                ),

                                                // Fuzzy match for Hindi translation
                                                sh => sh.MultiMatch(mm => mm
                                                    .Query(TranslatedWords.GetValueOrDefault("hi") ?? request.SearchTerm)
                                                    .Fuzziness(Fuzziness.Auto)
                                                    .Operator(Operator.And)
                                                    .Type(TextQueryType.BestFields)
                                                    .Boost(1) // Lower boost for fuzzy matches
                                                ),

                                                // Fuzzy match for Gujarati translation
                                                sh => sh.MultiMatch(mm => mm
                                                    .Query(TranslatedWords.GetValueOrDefault("gu") ?? request.SearchTerm)
                                                    .Fuzziness(Fuzziness.Auto)
                                                    .Operator(Operator.And)
                                                    .Type(TextQueryType.BestFields)
                                                    .Boost(1) // Lower boost for fuzzy matches
                                                ),

                                                // Fallback to a wildcard "contains" query if no exact match
                                                sh => sh.Bool(bq => bq
                                                    .Should(
                                                        // Wildcard search across all fields for partial matches
                                                        sh2 => sh2.Wildcard(wc => wc
                                                            .Field("vid_Nam")
                                                            .Value($"*{request.SearchTerm.ToLower()}*")
                                                        ),
                                                        sh2 => sh2.Wildcard(wc => wc
                                                            .Field("hp_Nam")
                                                            .Value($"*{request.SearchTerm.ToLower()}*")
                                                        ),
                                                        sh2 => sh2.Wildcard(wc => wc
                                                            .Field("kr_Nam")
                                                            .Value($"*{request.SearchTerm.ToLower()}*")
                                                        ),
                                                        sh2 => sh2.Wildcard(wc => wc
                                                            .Field("prksn_Nam")
                                                            .Value($"*{request.SearchTerm.ToLower()}*")
                                                        )
                                                    )
                                                    .Boost(0.5) // Assign lower boost for wildcard results
                                                )
                                            )
                                            .MinimumShouldMatch(1)
                                        )
                                    )
                                    .Sort(s => s.Descending(SortSpecialField.Score)) // Sort by relevance score
                                );

            // Handle search results
            searchResultDto.TotalCount = response.Total;
            var searchResults = response.Hits.Select(hit => new SearchResult
            {
                Index = hit.Index.Replace("elk_koba_", "").Replace("_new", ""),
                Source = hit.Source
            }).ToList();

            searchResultDto.Results = searchResults;
            return searchResultDto;
        }

        public async Task<AdvanceFiltersDto> GetAdvanceSearchFiltersAsync(KobaWebApplication.Dto.Browser.SearchRequest request)
        {
            request.IsAdvanceSearch = false;
            var TranslatedWords = await GetTranslatedWords(request.SearchTerm);

            AdvanceFiltersDto searchResultDto = new AdvanceFiltersDto();
            if (request.SelectedIndex.ToLower() == "prakashan")
            {
                var result = await _client.SearchAsync<PublisherInformation>(s => s
                    .Index(request.IndexName.ToLower()) // Use the selected index
                    .From(0)
                    .Size(10000)
                    .Query(q => q
                        .Bool(b =>
                        {
                            b.Should(
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("en") ?? request.SearchTerm) // English or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(3) // Higher boost for English matches
                                ),
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("hi") ?? request.SearchTerm) // Hindi or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(2) // Slightly lower boost for Hindi matches
                                ),
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("gu") ?? request.SearchTerm) // Gujarati or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(1.5) // Lower boost for Gujarati matches
                                ),
                                sh => sh.Term(t => t
                                    .Field("prksn_Nam") // The field you want exact term matches on
                                    .Value(request.SearchTerm)
                                    .Boost(5) // Highest priority for exact matches
                                )
                            );

                            b.MinimumShouldMatch(1); // At least one should match

                            return b;
                        })
                    )
                    .Aggregations(a => a
                        .Terms("publisher_names", t => t
                            .Field(f => f.Pblsr_Nam.Suffix("keyword"))
                            .Size(1000)
                        )
                        .Terms("edition", t => t
                            .Field(f => f.Edition.Suffix("keyword"))
                            .Size(1000)
                        )
                        .Terms("dharma_code", t => t
                            .Field(f => f.Dharma_Code.Suffix("keyword"))
                            .Size(1000)
                        )
                        .Terms("granthmala", t => t
                            .Field(f => f.Series_Nam.Suffix("keyword"))
                            .Size(1000)
                        )
                    )
                );
                // Create a list to hold both publisher name and count
                var publisherInfoList = new List<PublisherInfoDto>();
                var editionInfoList = new List<PublisherInfoDto>();
                var dharamCodeInfoList = new List<PublisherInfoDto>();
                var granthmalaInfoList = new List<PublisherInfoDto>();

                var publisherAgg = result.Aggregations.Terms("publisher_names");
                var editionAgg = result.Aggregations.Terms("edition");
                var dharmaCodeAgg = result.Aggregations.Terms("dharma_code");
                var granthmalaAgg = result.Aggregations.Terms("granthmala");

                if (publisherAgg != null)
                {
                    foreach (var bucket in publisherAgg.Buckets)
                    {
                        publisherInfoList.Add(new PublisherInfoDto
                        {
                            Name = bucket.Key,
                            Count = bucket.DocCount.GetValueOrDefault()
                        });
                    }
                }

                if (editionAgg != null)
                {
                    foreach (var bucket in editionAgg.Buckets)
                    {
                        editionInfoList.Add(new PublisherInfoDto
                        {
                            Name = bucket.Key,
                            Count = bucket.DocCount.GetValueOrDefault()
                        });
                    }
                }

                if (dharmaCodeAgg != null)
                {
                    foreach (var bucket in dharmaCodeAgg.Buckets)
                    {
                        dharamCodeInfoList.Add(new PublisherInfoDto
                        {
                            Name = bucket.Key,
                            Count = bucket.DocCount.GetValueOrDefault()
                        });
                    }
                }

                if (granthmalaAgg != null)
                {
                    foreach (var bucket in granthmalaAgg.Buckets)
                    {
                        // Add the publisher name and its count into a single object
                        granthmalaInfoList.Add(new PublisherInfoDto
                        {
                            Name = bucket.Key,
                            Count = bucket.DocCount.GetValueOrDefault()
                        });
                    }
                }

                searchResultDto.publisherInfoDtos = publisherInfoList;
                searchResultDto.editionInfoDtos = editionInfoList;
                searchResultDto.dharmaCodeInfoDtos = dharamCodeInfoList;
                searchResultDto.granthmalaInfoDtos = granthmalaInfoList;
                return searchResultDto;
            }
            else if (request.SelectedIndex.ToLower() == "hastprat")
            {
                var result = await _client.SearchAsync<HaspratInformation>(s => s
                    .Index(request.IndexName.ToLower()) // Use the selected index
                    .From(0)
                    .Size(10000)
                    .Query(q => q
                        .Bool(b =>
                        {
                            b.Should(
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("en") ?? request.SearchTerm) // English or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(3) // Higher boost for English matches
                                ),
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("hi") ?? request.SearchTerm) // Hindi or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(2) // Slightly lower boost for Hindi matches
                                ),
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("gu") ?? request.SearchTerm) // Gujarati or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(1.5) // Lower boost for Gujarati matches
                                ),
                                sh => sh.Term(t => t
                                    .Field("hp_Nam") // The field you want exact term matches on
                                    .Value(request.SearchTerm)
                                    .Boost(5) // Give an even higher boost to exact term matches
                                )
                            );
                            b.MinimumShouldMatch(1); // At least one should match
                            return b;
                        })
                    )
                    .Aggregations(a => a
                        .Terms("bhandar_names", t => t
                            .Field(f => f.Bhandar_Short_Name.Suffix("keyword"))
                            .Size(1000)
                        )
                        .Terms("lipi_names", t => t
                            .Field(f => f.Lipi_Short_Nm.Suffix("keyword"))
                            .Size(1000)
                        )
                        .Terms("vid_nam", t => t
                            .Field(f => f.Vid_Nam.Suffix("keyword"))
                            .Size(1000)
                        )
                        .Terms("vid_Type_Short_Name", t => t
                            .Field(f => f.Vid_Type_Short_Name.Suffix("keyword"))
                            .Size(1000)
                        )
                    )
                );

                var bhandarList = new List<PublisherInfoDto>();
                var lipiList = new List<PublisherInfoDto>();
                var vidNameList = new List<PublisherInfoDto>();
                var vidTypeList = new List<PublisherInfoDto>();

                var bhandarAgg = result.Aggregations.Terms("bhandar_names");
                if (bhandarAgg != null)
                {
                    foreach (var bucket in bhandarAgg.Buckets)
                    {
                        bhandarList.Add(new PublisherInfoDto
                        {
                            Name = bucket.Key,
                            Count = bucket.DocCount.GetValueOrDefault()
                        });
                    }
                }

                var lipiAgg = result.Aggregations.Terms("lipi_names");
                if (lipiAgg != null)
                {
                    foreach (var bucket in lipiAgg.Buckets)
                    {
                        lipiList.Add(new PublisherInfoDto
                        {
                            Name = bucket.Key,
                            Count = bucket.DocCount.GetValueOrDefault()
                        });
                    }
                }

                var vidNameAgg = result.Aggregations.Terms("vid_nam");
                if (vidNameAgg != null)
                {
                    foreach (var bucket in vidNameAgg.Buckets)
                    {
                        vidNameList.Add(new PublisherInfoDto
                        {
                            Name = bucket.Key,
                            Count = bucket.DocCount.GetValueOrDefault()
                        });
                    }
                }

                var vidTypeAgg = result.Aggregations.Terms("vid_Type_Short_Name");
                if (vidTypeAgg != null)
                {
                    foreach (var bucket in vidTypeAgg.Buckets)
                    {
                        vidTypeList.Add(new PublisherInfoDto
                        {
                            Name = bucket.Key,
                            Count = bucket.DocCount.GetValueOrDefault()
                        });
                    }
                }

                // Assign results to the DTO
                searchResultDto.bhandarInfoDtos = bhandarList;
                searchResultDto.lipiInfoDtos = lipiList;
                searchResultDto.vidNameInfoDtos = vidNameList;
                searchResultDto.vidTypeShortNameInfoDtos = vidTypeList;

                return searchResultDto;
            }
            else if (request.SelectedIndex.ToLower() == "kruti")
            {
                var result = await _client.SearchAsync<KrutiInformation>(s => s
                    .Index(request.IndexName.ToLower()) // Use the selected index
                    .From(0)
                    .Size(10000)
                    .Query(q => q
                        .Bool(b =>
                        {
                            b.Should(
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("en") ?? request.SearchTerm) // English or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(3) // Higher boost for English matches
                                ),
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("hi") ?? request.SearchTerm) // Hindi or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(2) // Slightly lower boost for Hindi matches
                                ),
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("gu") ?? request.SearchTerm) // Gujarati or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(1.5) // Even lower boost for Gujarati matches
                                ),
                                sh => sh.Term(t => t
                                    .Field("kr_Nam") // The field you want exact term matches on
                                    .Value(request.SearchTerm)
                                    .Boost(5) // Give an even higher boost to exact term matches
                                )
                            );
                            b.MinimumShouldMatch(1);
                            return b;
                        })
                    )
                    // Add aggregation for language
                    .Aggregations(a => a
                        .Terms("bhasha_short_name", t => t
                            .Field(f => f.Language.Suffix("keyword"))
                            .Size(1000)
                        )
                        .Terms("publisher_name", t => t
                            .Field(f => f.Publisher_Name.Suffix("keyword"))
                            .Size(1000)
                        )
                    )
                );

                var languageAgg = result.Aggregations.Terms("bhasha_short_name");
                var vidNameAgg = result.Aggregations.Terms("publisher_name");
                var languageList = new List<PublisherInfoDto>();
                var vidNameList = new List<PublisherInfoDto>();

                if (languageAgg != null)
                {
                    foreach (var bucket in languageAgg.Buckets.Where(l => !string.IsNullOrEmpty(l.Key)))
                    {
                        languageList.Add(new PublisherInfoDto
                        {
                            Name = bucket.Key,
                            Count = bucket.DocCount.GetValueOrDefault()
                        });
                    }
                }

                if (vidNameAgg != null)
                {
                    foreach (var bucket in vidNameAgg.Buckets.Where(l => !string.IsNullOrEmpty(l.Key)))
                    {
                        vidNameList.Add(new PublisherInfoDto
                        {
                            Name = bucket.Key,
                            Count = bucket.DocCount.GetValueOrDefault()
                        });
                    }
                }

                searchResultDto.languageInfoDtos = languageList;
                searchResultDto.vidNameInfoDtos = vidNameList;
                return searchResultDto;
            }
            else if (request.SelectedIndex.ToLower() == "vidvan")
            {
                var result = await _client.SearchAsync<AuthorInformation>(s => s
                    .Index(request.IndexName.ToLower()) // Use the selected index
                    .From((request.PageNumber - 1) * request.PageSize)
                    .Size(request.PageSize)
                    .Query(q => q
                        .Bool(b =>
                        {
                            b.Should(
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("en") ?? request.SearchTerm) // English or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(3) // Higher boost for English matches
                                ),
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("hi") ?? request.SearchTerm) // Hindi or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(2) // Slightly lower boost for Hindi matches
                                ),
                                sh => sh.MultiMatch(mm => mm
                                    .Query(TranslatedWords.GetValueOrDefault("gu") ?? request.SearchTerm) // Gujarati or fallback to search term
                                    .Fuzziness(request.IsExactSearch ? null : Fuzziness.Auto)
                                    .Operator(Operator.And)
                                    .Type(TextQueryType.BestFields)
                                    .Boost(1.5) // Even lower boost for Gujarati matches
                                ),
                                sh => sh.Term(t => t
                                    .Field("vid_Nam") // Exact term match field
                                    .Value(request.SearchTerm)
                                    .Boost(5) // Higher boost for exact term matches
                                )
                            );
                            b.MinimumShouldMatch(1); // At least one should match
                            return b;
                        })
                    ).Aggregations(a => a
                        .Terms("gach_nam", t => t
                            .Field(f => f.Gach_nam.Suffix("keyword"))
                            .Size(1000)
                        )
                        .Terms("guru_name", t => t
                            .Field(f => f.Guru_Name.Suffix("keyword"))
                            .Size(1000)
                        )
                        .Terms("dada_guru_name", t => t
                            .Field(f => f.Dada_Guru_Name.Suffix("keyword"))
                            .Size(1000)
                        )
                        .Terms("genderCode", t => t
                            .Field(f => f.Male_Female_Code.Suffix("keyword"))
                            .Size(1000)
                        )
                        .Terms("gruhasth", t => t
                            .Field(f => f.Sadhu_Grihast_Code.Suffix("keyword"))
                            .Size(1000)
                        )
                    )
                );

                var gachList = new List<PublisherInfoDto>();
                var guruList = new List<PublisherInfoDto>();
                var dadaGuruList = new List<PublisherInfoDto>();
                var genderCodeList = new List<PublisherInfoDto>();
                var gruhasthList = new List<PublisherInfoDto>();

                var gachAgg = result.Aggregations.Terms("gach_nam");
                if (gachAgg != null)
                {
                    foreach (var bucket in gachAgg.Buckets)
                    {
                        gachList.Add(new PublisherInfoDto
                        {
                            Name = bucket.Key,
                            Count = bucket.DocCount.GetValueOrDefault()
                        });
                    }
                }

                var guruAgg = result.Aggregations.Terms("guru_name");
                if (guruAgg != null)
                {
                    foreach (var bucket in guruAgg.Buckets)
                    {
                        guruList.Add(new PublisherInfoDto
                        {
                            Name = bucket.Key,
                            Count = bucket.DocCount.GetValueOrDefault()
                        });
                    }
                }

                var dadaGuruAgg = result.Aggregations.Terms("dada_guru_name");
                if (dadaGuruAgg != null)
                {
                    foreach (var bucket in dadaGuruAgg.Buckets)
                    {
                        dadaGuruList.Add(new PublisherInfoDto
                        {
                            Name = bucket.Key,
                            Count = bucket.DocCount.GetValueOrDefault()
                        });
                    }
                }

                var genderCodeAgg = result.Aggregations.Terms("genderCode");
                if (genderCodeAgg != null)
                {
                    foreach (var bucket in genderCodeAgg.Buckets)
                    {
                        genderCodeList.Add(new PublisherInfoDto
                        {
                            Name = bucket.Key,
                            Count = bucket.DocCount.GetValueOrDefault()
                        });
                    }
                }

                var gruhasthAgg = result.Aggregations.Terms("gruhasth");
                if (gruhasthAgg != null)
                {
                    foreach (var bucket in gruhasthAgg.Buckets)
                    {
                        gruhasthList.Add(new PublisherInfoDto
                        {
                            Name = bucket.Key,
                            Count = bucket.DocCount.GetValueOrDefault()
                        });
                    }
                }

                searchResultDto.gachNameInfoDtos = gachList;
                searchResultDto.guruNameInfoDtos = guruList;
                searchResultDto.dadaGuruNameInfoDtos = dadaGuruList;
                searchResultDto.genderCodeInfoDtos = genderCodeList;
                searchResultDto.gruhasthInfoDtos = gruhasthList;

                return searchResultDto;
            }
            else
            {
                return null;
            }
        }

        private static Dictionary<string, string> langMap = new Dictionary<string, string>
        {
            { "hi", "hi" },  // Hindi
            { "gu", "gu" },  // Gujarati
            { "en", "en" }   // English (ITRANS equivalent in .NET can use regular 'en')
        };

        #region GetTranslatedWords

        private async Task<Dictionary<string, string>> GetTranslatedWords(string word)
        {
            string detectedLang = await DetectLanguageAsync(word);

            List<string> targetLanguages = new List<string>();

            foreach (string lang in langMap.Keys)
            {
                if (detectedLang != lang)
                    targetLanguages.Add(lang);
            }

            //Dictionary<string, string> translations = await TranslateTextGoogleAsync(word, targetLanguages);

            Dictionary<string, string> convertedWordsList = new Dictionary<string, string>();

            if (detectedLang == "en")
            {
                convertedWordsList = await ConvertTextAsync(word, targetLanguages);
                convertedWordsList["en"] = word;
            }
            else if (detectedLang == "hi")
            {
                string HindiToEng = ConvertHindiToEnglish(word, "basic"); // Hindi to Eng
                convertedWordsList = await ConvertTextAsync(HindiToEng, targetLanguages);
                convertedWordsList["hi"] = word;
            }
            else if (detectedLang == "gu")
            {
                string GujToEng = ConvUniToEng(word, "basic"); // Guj to Eng
                convertedWordsList = await ConvertTextAsync(GujToEng, targetLanguages);
                convertedWordsList["gu"] = word;
            }

            return convertedWordsList;
        }

        private async Task<Dictionary<string, string>> ConvertTextAsync(string text, List<string> targetLanguages)
        {
            Dictionary<string, string> transliterations = new Dictionary<string, string>();

            using (HttpClient client = new HttpClient())
            {
                foreach (var lang in targetLanguages)
                {
                    string url = "";
                    if (lang == "hi") // Hindi transliteration
                    {
                        url = "https://inputtools.google.com/request?itc=hi-t-i0-und&num=5";
                    }
                    else if (lang == "gu") // Gujarati transliteration
                    {
                        url = "https://inputtools.google.com/request?itc=gu-t-i0-und&num=5";
                    }
                    else if (lang == "en") // English doesn't need transliteration, use the original text
                    {
                        transliterations[lang] = text;
                        continue; // Skip the API call for English
                    }

                    if (!string.IsNullOrEmpty(url))
                    {
                        var parameters = new Dictionary<string, string>
                {
                    { "text", text }
                };

                        var content = new FormUrlEncodedContent(parameters);
                        HttpResponseMessage response = await client.PostAsync(url, content);
                        string responseString = await response.Content.ReadAsStringAsync();

                        try
                        {
                            dynamic result = JsonConvert.DeserializeObject(responseString);
                            if (result != null && result[0].ToString() == "SUCCESS" && result[1] != null && result[1].Count > 0 && result[1][0][1] != null)
                            {
                                transliterations[lang] = result[1][0][1][0].ToString();
                            }
                            else
                            {
                                transliterations[lang] = text; // Return original text if transliteration fails or structure is unexpected
                            }
                        }
                        catch (Exception ex)
                        {
                            // Handle or log the exception
                            Console.WriteLine($"Error parsing response for language {lang}: {ex.Message}");
                            transliterations[lang] = text; // Return original text on error
                        }
                    }
                }
            }
            return transliterations;
        }

        #endregion GetTranslatedWords

        #region Convert Hindi Text To Eng

        private static string ConvertHindiToEnglish(string text, string method)
        {
            string text_en = text;

            List<string> hic = new List<string> { "क", "ख", "ग", "घ", "च", "छ", "ज", "झ", "ट", "ठ", "ड", "ढ", "ण", "त", "थ", "द", "ध", "न", "प", "फ", "ब", "भ", "म", "य", "र", "ल", "व", "श", "ष", "स", "ह", "ळ", "ञ" };
            List<string> enc = method == "basic" ?
                new List<string> { "ka", "kha", "ga", "gha", "cha", "chha", "ja", "za", "ta", "__i__th__/i__a", "da", "__i__dh__/i__a", "__i__n__/i__a", "__i__t__/i__a", "tha", "__i__d__/i__a", "dha", "na", "pa", "fa", "ba", "bha", "ma", "ya", "ra", "la", "va", "sha", "sha", "sa", "ha", "__i__l__/i__a", "nya" } :
                new List<string> { "ka", "kha", "ga", "gha", "cha", "chha", "ja", "jha", "ṭa", "ṭha", "ḍa", "ḍha", "ṇa", "ta", "tha", "da", "dha", "na", "pa", "fa", "ba", "bha", "ma", "ya", "ra", "la", "va", "sha", "ṣha", "sa", "ha", "ḷa", "nya" };

            List<string> hih = new List<string> { "क्", "ख्", "ग्", "घ्", "च्", "छ्", "ज्", "झ्", "ट्", "ठ्", "ड्", "ढ्", "ण्", "त्", "थ्", "द्", "ध्", "न्", "प्", "फ्", "ब्", "भ्", "म्", "य्", "र्", "ल्", "व्", "श्", "ष्", "स्", "ह्", "ळ्", "ञ्", "ङ", "ऽ" };
            List<string> enh = method == "basic" ?
                new List<string> { "k", "kh", "g", "gh", "ch", "chh", "j", "z", "t", "__i__th__/i__", "d", "__i__dh__/i__", "__i__n__/i__", "__i__t__/i__", "th", "__i__d__/i__", "dh", "n", "p", "f", "b", "bh", "m", "y", "r", "l", "v", "sh", "sh", "s", "h", "__i__l__/i__", "ny", "n", "’" } :
                new List<string> { "k", "kh", "g", "gh", "ch", "chh", "j", "z", "ṭ", "ṭh", "ḍ", "ḍh", "ṇ", "t", "th", "d", "dh", "n", "p", "f", "b", "bh", "m", "y", "r", "l", "v", "sh", "ṣh", "s", "h", "ḷ", "ny", "n", "’" };

            List<string> hiv = new List<string> { "ओ", "औ", "आ", "इ", "ई", "उ", "ऊ", "ए", "ऐ", "ऎ", "ऒ", "ऋ", "ॐ", "अ" };
            List<string> env = method == "Basic" ?
                new List<string> { "o", "au", "aa", "i", "ee", "u", "oo", "e", "ai", "e", "au", "hru", "aum", "a" } :
                new List<string> { "o", "au", "ā", "i", "ī", "u", "ū", "e", "ai", "ĕ", "ŏ", "ṛu", "aum", "a" };

            List<string> hivs = new List<string> { "ि", "ी", "ु", "ू", "े", "ै", "ो", "ौ", "ॆ", "ॊ", "ं", "ृ", "्", "ः", "ा" };
            List<string> envs = method == "basic" ?
                new List<string> { "i", "ee", "u", "oo", "e", "ai", "o", "au", "e", "au", "an", "ru", "", "ah", "aa" } :
                new List<string> { "i", "ī", "u", "ū", "e", "ai", "o", "au", "ĕ", "ŏ", "an", "ṛu", "", "ah", "ā" };

            List<string> hin = new List<string> { "०", "१", "२", "३", "४", "५", "६", "७", "८", "९" };
            List<string> enn = new List<string> { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };

            // Transliteration rules
            for (int i = 0; i < hic.Count; i++)
            {
                for (int j = 0; j < hivs.Count; j++)
                {
                    text_en = Regex.Replace(text_en, $"{hic[i]}{hivs[j]}ः ", $"{enh[i]}{envs[j]}h{envs[j]} ");
                    text_en = Regex.Replace(text_en, $"{hic[i]}{hivs[j]}ः", $"{enh[i]}{envs[j]}h");
                }
            }

            for (int i = 0; i < hic.Count; i++)
            {
                for (int j = 0; j < hivs.Count; j++)
                {
                    text_en = Regex.Replace(text_en, $"{hic[i]}{hivs[j]}ं", $"{enh[i]}{envs[j]}n");
                }
            }

            for (int i = 0; i < hiv.Count; i++)
            {
                text_en = Regex.Replace(text_en, $"{hiv[i]}ं", $"{env[i]}n");
            }

            for (int i = 0; i < hic.Count; i++)
            {
                for (int j = 0; j < hivs.Count; j++)
                {
                    text_en = Regex.Replace(text_en, $"{hic[i]}{hivs[j]}", $"{enh[i]}{envs[j]}");
                }
            }

            text_en = ReplaceArray(hih, enh, text_en);
            text_en = ReplaceArray(hivs, envs, text_en);
            text_en = ReplaceArray(hiv, env, text_en);
            text_en = ReplaceArray(hic, enc, text_en);
            text_en = ReplaceArray(hin, enn, text_en);

            if (method == "baps")
            {
                for (int i = 0; i < enc.Count; i++)
                {
                    text_en = Regex.Replace(text_en, $"{enc[i]} ", $"{enh[i]} ");
                }

                for (int i = 0; i < enh.Count; i++)
                {
                    for (int j = 0; j < enc.Count; j++)
                    {
                        text_en = Regex.Replace(text_en, $"{enh[i]}{enh[j]} ", $"{enh[i]}{enc[j]} ");
                    }
                }

                List<string> encomb = new List<string> { "kh", "gh", "ch", "chh", "ṭh", "ḍh", "th", "dh", "bh", "sh", "ṣh", "ny" };
                for (int i = 0; i < env.Count; i++)
                {
                    for (int j = 0; j < encomb.Count; j++)
                    {
                        text_en = Regex.Replace(text_en, $"{env[i]}{encomb[j]}a ", $"{env[i]}{encomb[j]} ");
                    }
                }
            }

            // Capitalize first word in sentence
            List<string> lc = new List<string> { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
            List<string> uc = new List<string> { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
            for (int i = 0; i < lc.Count; i++)
            {
                text_en = Regex.Replace(text_en, $"(^|\\. )({lc[i]})", $"$1{uc[i]}");
            }

            return text_en;
        }

        private static string ReplaceArray(List<string> a, List<string> b, string text)
        {
            if (a.Count != b.Count)
            {
                return text;
            }

            for (int i = 0; i < a.Count; i++)
            {
                string pattern = a[i];
                text = Regex.Replace(text, pattern, b[i]);
            }

            return text;
        }

        #endregion Convert Hindi Text To Eng

        #region Convert Guj Text To Eng

        private static string ConvUniToEng(string text, string method)
        {
            string text_en = text;

            var guc = new[] { "ક", "ખ", "ગ", "ઘ", "ચ", "છ", "જ", "ઝ", "ટ", "ઠ", "ડ", "ઢ", "ણ", "ત", "થ", "દ", "ધ", "ન", "પ", "ફ", "બ", "ભ", "મ", "ય", "ર", "લ", "વ", "શ", "ષ", "સ", "હ", "ળ", "ઞ" };
            string[] enc;

            if (method == "basic")
            {
                enc = new[] { "ka", "kha", "ga", "gha", "cha", "chha", "ja", "jha", "ta", "ṭha", "da", "ḍha", "ṇa", "ta", "tha", "da", "dha", "na", "pa", "fa", "ba", "bha", "ma", "ya", "ra", "la", "va", "sha", "sha", "sa", "ha", "ḷa", "nya" };
            }
            else
            {
                enc = new[] { "ka", "kha", "ga", "gha", "cha", "chha", "ja", "jha", "ṭa", "ṭha", "ḍa", "ḍha", "ṇa", "ta", "tha", "da", "dha", "na", "pa", "fa", "ba", "bha", "ma", "ya", "ra", "la", "va", "sha", "ṣha", "sa", "ha", "ḷa", "nya" };
            }

            var guh = new[] { "ક્", "ખ્", "ગ્", "ઘ્", "ચ્", "છ્", "જ્", "ઝ્", "ટ્", "ઠ્", "ડ્", "ઢ્", "ણ્", "ત્", "થ્", "દ્", "ધ્", "ન્", "પ્", "ફ્", "બ્", "ભ્", "મ્", "ય્", "ર્", "લ્", "વ્", "શ્", "ષ્", "સ્", "હ્", "ળ્", "ઞ્" };
            string[] enh;

            if (method == "basic")
            {
                enh = new[] { "k", "kh", "g", "gh", "ch", "chh", "j", "z", "t", "ṭh", "d", "ḍh", "ṇ", "t", "th", "d", "dh", "n", "p", "f", "b", "bh", "m", "y", "r", "l", "v", "sh", "ṣh", "s", "h", "ḷ", "ny" };
            }
            else
            {
                enh = new[] { "k", "kh", "g", "gh", "ch", "chh", "j", "z", "ṭ", "ṭh", "ḍ", "ḍh", "ṇ", "t", "th", "d", "dh", "n", "p", "f", "b", "bh", "m", "y", "r", "l", "v", "sh", "ṣh", "s", "h", "ḷ", "ny" };
            }

            var guv = new[] { "ઓ", "ઔ", "આ", "ઇ", "ઈ", "ઉ", "ઊ", "એ", "ઐ", "ઍ", "ઑ", "ૠ", "અ" };
            string[] env;

            if (method == "basic")
            {
                env = new[] { "o", "au", "aa", "i", "ee", "u", "oo", "e", "ai", "e", "au", "hru", "a" };
            }
            else
            {
                env = new[] { "o", "au", "ā", "i", "ī", "u", "ū", "e", "ai", "ĕ", "ŏ", "ṛu", "a" };
            }

            var guvs = new[] { "િ", "ી", "ુ", "ૂ", "ે", "ૈ", "ો", "ૌ", "ૅ", "ૉ", "ં", "ૃ", "્", "ઃ", "ા" };
            string[] envs;

            if (method == "basic")
            {
                envs = new[] { "i", "ee", "u", "oo", "e", "ai", "o", "au", "e", "au", "an", "ru", "", "ah", "aa" };
            }
            else
            {
                envs = new[] { "i", "ī", "u", "ū", "e", "ai", "o", "au", "ĕ", "ŏ", "an", "ṛu", "", "ah", "ā" };
            }

            var gun = new[] { "૦", "૧", "૨", "૩", "૪", "૫", "૬", "૭", "૮", "૯" };
            var enn = new[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };

            // Replacing patterns
            for (int i = 0; i < guc.Length; i++)
            {
                for (int j = 0; j < guvs.Length; j++)
                {
                    var pattern = new Regex(guc[i] + guvs[j] + "ઃ ", RegexOptions.Compiled);
                    var replacement = enh[i] + envs[j] + "h" + envs[j] + " ";
                    text_en = pattern.Replace(text_en, replacement);

                    pattern = new Regex(guc[i] + guvs[j] + "ઃ", RegexOptions.Compiled);
                    replacement = enh[i] + envs[j] + "h";
                    text_en = pattern.Replace(text_en, replacement);
                }
            }

            // Replacing more patterns
            for (int i = 0; i < guc.Length; i++)
            {
                for (int j = 0; j < guvs.Length; j++)
                {
                    var pattern = new Regex(guc[i] + guvs[j] + "ં", RegexOptions.Compiled);
                    var replacement = enh[i] + envs[j] + "n";
                    text_en = pattern.Replace(text_en, replacement);
                }
            }

            for (int i = 0; i < guv.Length; i++)
            {
                var pattern = new Regex(guv[i] + "ં", RegexOptions.Compiled);
                var replacement = env[i] + "n";
                text_en = pattern.Replace(text_en, replacement);
            }

            for (int i = 0; i < guc.Length; i++)
            {
                for (int j = 0; j < guvs.Length; j++)
                {
                    var pattern = new Regex(guc[i] + guvs[j], RegexOptions.Compiled);
                    var replacement = enh[i] + envs[j];
                    text_en = pattern.Replace(text_en, replacement);
                }
            }

            // Replace arrays
            text_en = ReplaceArray(guh, enh, text_en);
            text_en = ReplaceArray(guvs, envs, text_en);
            text_en = ReplaceArray(guv, env, text_en);
            text_en = ReplaceArray(guc, enc, text_en);
            text_en = ReplaceArray(gun, enn, text_en);

            // Additional conversions based on method
            if (method == "baps")
            {
                for (int i = 0; i < enc.Length; i++)
                {
                    var pattern = new Regex(enc[i] + " ", RegexOptions.Compiled);
                    var replacement = enh[i] + " ";
                    text_en = pattern.Replace(text_en, replacement);
                }

                for (int i = 0; i < enh.Length; i++)
                {
                    for (int j = 0; j < enc.Length; j++)
                    {
                        var pattern = new Regex(enh[i] + enh[j] + " ", RegexOptions.Compiled);
                        var replacement = enh[i] + enc[j] + " ";
                        text_en = pattern.Replace(text_en, replacement);
                    }
                }

                var encomb = new[] { "kh", "gh", "ch", "chh", "ṭh", "ḍh", "th", "dh", "bh", "sh", "ṣh", "ny" };
                for (int i = 0; i < env.Length; i++)
                {
                    for (int j = 0; j < encomb.Length; j++)
                    {
                        var pattern = new Regex(env[i] + encomb[j], RegexOptions.Compiled);
                        var replacement = env[i] + enh[j];
                        text_en = pattern.Replace(text_en, replacement);
                    }
                }

                text_en = text_en.Replace("ḍ", "d").Replace("ṭ", "t").Replace("ḥ", "h").Replace("ṛ", "r").Replace("ṭ", "ṭ");
            }

            return text_en;
        }

        private static string ReplaceArray(string[] a, string[] b, string text)
        {
            if (a.Length != b.Length)
            {
                return text;
            }

            for (int i = 0; i < a.Length; i++)
            {
                var pattern = new Regex(a[i], RegexOptions.Compiled);
                text = pattern.Replace(text, b[i]);
            }

            return text;
        }

        #endregion Convert Guj Text To Eng

        private async Task<Dictionary<string, string>> TranslateTextGoogleAsync(string text, List<string> targetLanguages)
        {
            Dictionary<string, string> translations = new Dictionary<string, string>();
            string url = "https://translation.googleapis.com/language/translate/v2";

            using (HttpClient client = new HttpClient())
            {
                foreach (var lang in targetLanguages)
                {
                    var parameters = new Dictionary<string, string>
                    {
                        { "q", text },
                        //{ "source", "en" },
                        //{ "source", "auto"},
                        { "target", lang },
                        { "key", googleTranslateApiKey }
                    };

                    var content = new FormUrlEncodedContent(parameters);
                    HttpResponseMessage response = await client.PostAsync(url, content);
                    string responseString = await response.Content.ReadAsStringAsync();

                    dynamic result = JsonConvert.DeserializeObject(responseString);
                    if (result?.data?.translations != null)
                    {
                        translations[lang] = result.data.translations[0].translatedText.ToString();
                    }
                    else
                    {
                        translations[lang] = text; // Return original text if translation fails
                    }
                }
            }
            return translations;
        }

        private async Task<string> DetectLanguageAsync(string text)
        {
            if (Regex.IsMatch(text, @"^[a-zA-Z]+$"))
            {
                return "en";
            }

            foreach (char c in text)
            {
                if (c >= '\u0900' && c <= '\u097F')
                {
                    return "hi";
                }
            }

            foreach (char c in text)
            {
                if (c >= '\u0A80' && c <= '\u0AFF')
                {
                    return "gu";
                }
            }

            return "Unknown Language";
        }

        private string ContainsContinuousWords(string text, int numberOfWords)
        {
            string pattern = @"\d{6}";

            Match match = Regex.Match(text, pattern);

            if (match.Success)
            {
                return match.Value;
            }

            return string.Empty;
        }
    }
}