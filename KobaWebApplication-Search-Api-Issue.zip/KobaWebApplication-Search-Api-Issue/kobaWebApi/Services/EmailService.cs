﻿using Koba.API.Models;
using MailKit.Net.Smtp;
using Microsoft.Extensions.Options;
using MimeKit;

namespace Koba.API.Services
{
    public class EmailService : IEmailService
    {
        private readonly EmailSettings _emailSettings;

        public EmailService(IOptions<EmailSettings> emailSettings)
        {
            _emailSettings = emailSettings.Value;
        }

        public async Task SendEmailAsync(string subject, RequestToBookRequest request)
        {
            var email = new MimeMessage();
            email.From.Add(MailboxAddress.Parse(_emailSettings.FromEmail));
            email.To.Add(MailboxAddress.Parse(_emailSettings.ToEmail));
            email.Subject = subject;

            var emailBody = $@"
                            <!DOCTYPE html>
                            <html lang='en'>
                            <head>
                                <meta charset='UTF-8'>
                                <meta name='viewport' content='width=device-width, initial-scale=1.0'>                                
                            </head>
                            <body>
                                <div class='email-container'>
                                    <table style=""width:600px;margin: auto; font-family: Inter, sans-serif;padding: 30px; font-size: 16px; line-height: 1.8;"">
                                       <tr>
                                          <td>
                                             <table style=""width: 100%; border-collapse: collapse;"">
                                                <tr  style=""background-color: #e5097f; text-align: center; color: white;"">
                                                   <td style=""padding: 10px 0;"">
                                                      <div style=""display: inline-block;width: 60px;height:60px;display: inline-block;vertical-align: middle;"">
                                                         <img style=""width: 60px;height:60px;object-fit: contain;"" src=""https://kobawebapp.magnusminds.net/assets/images/logo.png"" />
                                                      </div>
                                                      <h1 style=""margin: 0 0 0 10px; font-size: 26px; font-weight: 400;display: inline-block;vertical-align: middle;"">Book Request Confirmation</h1>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td>
                                                      <div style=""width: 50%;margin: 15px auto;"">
                                                         <img src=""email.png"" alt=""Request Email"" style=""width: 100%;height: 100%;""/>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td style=""padding: 20px 10px;"">
                                                      <h2 style=""font-size: 20px; color: #000000; margin: 0 0 15px;font-weight: normal;"">Hello,</strong></h2>
                                                      <p style=""margin: 0;"">
                                                         A user has requested a book from your library website. Below are the request details:
                                                      </p>
                                                   </td>
                                                </tr>
                                             </table>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>
                                             <table style=""width: 100%; border-collapse: collapse;"">
                                                <tr>
                                                  <td style=""padding: 10px 15px; border: 1px solid #ddd; background-color: #f9f9f9; width: 200px;"">Book SrNo.:</td>
                                                  <td style=""padding: 10px 15px; border: 1px solid #ddd; font-weight: bold; color: #333;"">{request.BookSrNo}</td>
                                                </tr>
                                                <tr>
                                                   <td style=""padding: 10px 15px; border: 1px solid #ddd; background-color: #f9f9f9;width: 200px;"">Book Category:</td>
                                                   <td style=""padding: 10px 15px; border: 1px solid #ddd;font-weight: bold;color: #333;"">{request.BookCategory}</td>
                                                </tr>
                                                <tr>
                                                   <td style=""padding: 10px 15px; border: 1px solid #ddd; background-color: #f9f9f9;width: 200px;"">Book Title:</td>
                                                   <td style=""padding: 10px 15px; border: 1px solid #ddd;font-weight: bold;color: #333;"">{request.BookTitle}</td>
                                                </tr>
                                                <tr>
                                                   <td style=""padding: 10px 15px; border: 1px solid #ddd; background-color: #f9f9f9;width: 200px;"">Requested Person Mobile:</td>
                                                   <td style=""padding: 10px 15px; border: 1px solid #ddd;font-weight: bold;color: #333;"">{request.RequestedPersonMobile}</td>
                                                </tr>
                                                <tr>
                                                   <td style=""padding: 10px 15px; border: 1px solid #ddd; background-color: #f9f9f9;width: 200px;"">Requested Person City:</td>
                                                   <td style=""padding: 10px 15px; border: 1px solid #ddd;font-weight: bold;color: #333;"">{request.RequestedPersonCity}</td>
                                                </tr>
                                                <tr>
                                                   <td style=""padding: 10px 15px; border: 1px solid #ddd; background-color: #f9f9f9;width: 200px;"">Requested Person State:</td>
                                                   <td style=""padding: 10px 15px; border: 1px solid #ddd;font-weight: bold;color: #333;"">{request.RequestedPersonState}</td>
                                                </tr>
                                             </table>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>
                                             <table class=""email-footer"" style=""width:100%;background-color: #f1f1f1; padding: 10px; text-align: center; font-size: 14px; color: #888;"">
                                                <tr>
                                                   <td>
                                                      <p style=""margin: 0 0 10px;"">
                                                         Thank you for using our service! <br />Visit our
                                                         <a style=""color: #007bff; text-decoration: none;"" href=""https://kobawebapp.magnusminds.net/"">Website</a> for more
                                                         information.
                                                      </p>
                                                      <p style=""margin: 0 0 10px;"">Best regards, <br />Shree Mahavir Jain Ardhana Kendra, Koba Library</p>
                                                   </td>
                                                </tr>
                                             </table>
                                          </td>
                                       </tr>
                                    </table>
                                </div>
                            </body>
                            </html>";


            var builder = new BodyBuilder
            {
                HtmlBody = emailBody
            };

            email.Body = builder.ToMessageBody();

            using var smtp = new SmtpClient();
            try
            {
                var secureSocketOption = _emailSettings.UseSSL
               ? MailKit.Security.SecureSocketOptions.SslOnConnect
               : MailKit.Security.SecureSocketOptions.StartTls;

                await smtp.ConnectAsync(_emailSettings.SmtpServer, _emailSettings.SmtpPort, secureSocketOption);
                await smtp.AuthenticateAsync(_emailSettings.SmtpUser, _emailSettings.SmtpPass);
                await smtp.SendAsync(email);
            }
            catch (Exception e)
            {
                //throw e;
            }
            finally
            {
                await smtp.DisconnectAsync(true);
            }
        }
    }
}
