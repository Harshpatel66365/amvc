﻿using Koba.API.DBContext;
using Koba.API.Models;
using Koba.API.Repository.Interface;

namespace Koba.API.Repository
{
    public class VidvanRepository:IVidvanRepository
    {
        private readonly ApplicationDBContext _dbContext;
        private readonly ISqlRepository<Vid_Dada_GuruData_View> _vidDataGuruInfo;

        public VidvanRepository(ApplicationDBContext dBContext, ISqlRepository<Vid_Dada_GuruData_View> vidDataGuruInfo)
        {
            _dbContext = dBContext;
            _vidDataGuruInfo = vidDataGuruInfo;
        }

        public async Task<VidvanInfoDto> getDetails(string VidNo)
        {
            var Data = await _vidDataGuruInfo.Get();
            var result = Data.FirstOrDefault(x => x.Vid_No == VidNo);

            if (result == null)
            {
                return null;
            }

            var vidvanInfo = new VidvanInfoDto()
            {
                Vid_No = result.Vid_No,
                Swarup_Short_Name = result.Swarup_Short_Name,
                Vid_Nam = result.Vid_Nam,
                Name_Type_Short_Name = result.Name_Type_Short_Name,
                Gach_Key = result.Gach_Key,
                Gach_nam = result.Gach_nam,
                Year_Type_Short_Name = result.Year_Type_Short_Name,
                vir_st_duration = result.Vir_St_Duration,
                vir_end_duration = result.Vir_End_Duration,
                Dharma_Code = result.Dharma_Code,
                Sadhu_Grihast_Code = result.Sadhu_Grihast_Code,
                Male_Female_Code = result.Male_Female_Code,
                Related_Tot_Kr = result.Related_Tot_Kr,
                Related_Tot_Prksn = result.Related_Tot_Prksn,
                Related_Tot_Hp = result.Related_Tot_Hp,
                Related_Tot_Pblsr = result.Related_Tot_Pblsr,
                Related_Tot_Series = result.Related_Tot_Series,
                Related_Tot_Mag_ank = result.Related_Tot_Mag_ank,
                Related_Tot_Mag_Ank_Petank = result.Related_Tot_Mag_Ank_Petank,
                Related_Tot_Museum_Antique = result.Related_Tot_Museum_Antique,
                Related_Tot_Child = result.Related_Tot_Child,
                Vid_Duration = result.Vid_Duration,
                Guru_Name = result.Guru_Name,
                Dada_Guru_Name = result.Dada_Guru_Name,
                Dada_Guru_Vid_No = result.Dada_Guru,
                Guru_Vid_No = result.Guru,
            };

            return vidvanInfo;
        }
    }
}
