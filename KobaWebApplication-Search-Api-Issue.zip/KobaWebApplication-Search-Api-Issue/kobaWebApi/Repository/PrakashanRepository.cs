﻿using Elasticsearch.Net;
using Koba.API.DBContext;
using Koba.API.Models;
using Koba.API.Repository.Interface;
using Microsoft.AspNetCore.Components.Forms;
using System;

namespace Koba.API.Repository
{
    public class PrakashanRepository : IPrakashanRepository
    {
        private readonly ApplicationDBContext _dbContext;
        private readonly ISqlRepository<prksn_view> _prksnView;
        private readonly ISqlRepository<Prksn_Series_Lnk_View> _prksnSeriesLnkView;
        private readonly ISqlRepository<Prksn_Vid_Lnk_View> _prksnVidLnkView;
        private readonly ISqlRepository<Prksn_Info_View> _prksnInfo;

        public PrakashanRepository(ApplicationDBContext dBContext, ISqlRepository<prksn_view> prksnView, ISqlRepository<Prksn_Series_Lnk_View> prksnSeriesLnkView, 
            ISqlRepository<Prksn_Vid_Lnk_View> prksnVidLnkView, ISqlRepository<Prksn_Info_View> prksnInfo)
        {
            _dbContext = dBContext;
            _prksnView = prksnView;
            _prksnSeriesLnkView = prksnSeriesLnkView;
            _prksnVidLnkView = prksnVidLnkView;
            _prksnInfo = prksnInfo;
        }

        public async Task<PrakashanInfoDto> getDetails(string PrKey)
        {
            var prksnViewResult = await _prksnView.Get();
            var prksnViewData = prksnViewResult.FirstOrDefault(x => x.Prksn_Key == PrKey);
            if (prksnViewData == null)
            {
                return null;
            }

            var prksnSeriiesResult = await _prksnSeriesLnkView.Get();
            var prksnSeriesData = prksnSeriiesResult.FirstOrDefault(x => x.Prksn_Key == PrKey);


            var prksnVidLnkResult = await _prksnVidLnkView.Get();
            var prksnVidLnkData = prksnVidLnkResult.FirstOrDefault(x => x.Prksn_Key == PrKey);


            var prakashanInfo = new PrakashanInfoDto()
            {
                Prksn_Key = prksnViewData.Prksn_Key,
                Edition = prksnViewData.Edition,
                Reprint = prksnViewData.Reprint,
                Prksn_Year = prksnViewData.Prksn_Year,
                Year_Type_Short_Name = prksnViewData.Year_Type_Short_Name, //prksnViewData.Prksn_Year?.Split('-')[0],
                Vol_Sub_Vol = prksnViewData.Vol_Sub_Vol,
                Pages = prksnViewData.Pages,
                Isbn = prksnViewData.Isbn,
                Isbn_Set_No = prksnViewData.Isbn_Set_No,
                Purnata_short_name = prksnViewData.Purnata_short_name,
                Tot_Petank = prksnViewData.Tot_Petank,
                Prksn_Nam = prksnViewData.Prksn_Nam,
                Pblsr_Nam = prksnViewData.Pblsr_Nam,
                vir_st_duration = prksnViewData.Vir_St_Duration,
                vir_end_duration = prksnViewData.Vir_End_Duration,
                series_name = prksnSeriesData!=null ? prksnSeriesData.Series_Nam : "",
                Dharma_Code = prksnViewData.Dharma_Code,
            };

            return prakashanInfo;
        }


        public async Task<Prksn_Info_View> getByPrakashanId(string prNo)
        {
            var Data = await _prksnInfo.Get();
            return Data.FirstOrDefault(x => x.Prksn_Key == prNo);
        }
    }
}
