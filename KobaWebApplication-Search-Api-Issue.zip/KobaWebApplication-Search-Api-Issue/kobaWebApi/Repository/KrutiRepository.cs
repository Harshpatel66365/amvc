﻿using Koba.API.DBContext;
using Koba.API.Models;
using Koba.API.Repository.Interface;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Nest;
using System.ComponentModel;

namespace Koba.API.Repository
{
    public class KrutiRepository : IKrutiRepository
    {
        private readonly ApplicationDBContext _dbContext;
        private readonly ISqlRepository<Kruti_Information> _krutiInfo;

        public KrutiRepository(ApplicationDBContext dBContext, ISqlRepository<Kruti_Information> krutiInfo)
        {
            _dbContext = dBContext;
            _krutiInfo = krutiInfo;
        }

        public async Task<KrutiInfoDto> getDetails(string krKey)
        {
            var Data = await _krutiInfo.Get();

            var result = Data.FirstOrDefault(x => x.Kr_Key == krKey);

            if (result == null)
            {
                return null;
            }

            var krutiInformation = new KrutiInfoDto()
            {
                Ki_Kr_Key = result.Kr_Key,
                Ki_Kr_Nam = result.Kr_Nam,
                Vid_Nam = result.Vid_Nam,
                Prakar_Short_Name = result.Prakar_Short_Name != null ? result.Prakar_Short_Name : null, // Use null conditional operator to avoid null reference exception
                Year_Value = result.Year_Value,
                Main_Nam = result.Main_Nam,
                Swarup_Short_Name = result.Swarup_Short_Name,
                Bhasha_Short_Name = result.Bhasha_Short_Name,
                Vid_Type_Short_Name = result.Vid_Type_Short_Name,
                AdiVakya = result.AdiVakya,
                AntimVakya = result.AntimVakya,
                Vibhag_Code = result.Vibhag_Code,
                Dharma_Code = result.Dharma_Code,
                Year_Type_Short_Name = result.Year_Type_Short_Name,
                Granthagra = result.Granthagra,
                Chand_Type_short_name = result.Chand_Type_short_name,
                Adhyay_short_name = result.Adhyay_short_name,
                Chand_count = result.Chand_count,
                Adhyay_count = result.Adhyay_count,
                Related_Tot_Prksn = result.Related_Tot_Prksn,
                Related_Tot_Hp = result.Related_Tot_Hp,
                Related_Tot_Mag_Ank_Petank = result.Related_Tot_Mag_Ank_Petank,
                Related_Tot_Childs = result.Related_Tot_Childs,
                Related_Tot_Aadharit_Kr = result.Related_Tot_Aadharit_Kr,
                Related_Tot_Aadharbhut_Kr = result.Related_Tot_Aadharbhut_Kr,
                Related_Tot_Karta_Group_Vidvan = result.Related_Tot_Karta_Group_Vidvan,
                Related_Tot_Vidvan = result.Related_Tot_Vidvan,
                Related_Tot_Kr_Nam = result.Related_Tot_Kr_Nam,
                Vid_No = result.Vid_No,
                Name_Type_Short_Name = result.Name_Type_Short_Name,
                language = result.Bhasha_Short_Name,
                vir_st_duration = result.vir_st_duration,
                vir_end_duration = result.vir_end_duration
            };

            return krutiInformation;
        }

        public async Task<Kruti_Information> getByKrutiId(string krNo)
        {
            var Data = await _krutiInfo.Get();
            return Data.FirstOrDefault(x => x.Kr_Key == krNo);
        }
    }
}
