﻿using Koba.API.DBContext;
using Koba.API.Models;
using Koba.API.Repository.Interface;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace Koba.API.Repository
{
    public class RequestToBookRepository : IRequestToBookRepository
    {
        private readonly ApplicationDBContext _dbContext;

        public RequestToBookRepository(ApplicationDBContext dBContext)
        {
            _dbContext = dBContext;
        }

        public async Task<bool> RequestToBook(RequestToBookRequest request)
        {
            var Request = new RequestToBook
            {
                BookCategory = request.BookCategory,
                BookSrNo = request.BookSrNo,
                BookTitle = request.BookTitle,
                RequestedPersonMobile = request.RequestedPersonMobile,
                RequestedPersonName = request.RequestedPersonName,
                RequestedPersonCity = request.RequestedPersonCity,
                RequestedPersonState = request.RequestedPersonState,
                CreatedDate = DateTime.Now
            };

            var result = _dbContext.RequestToBook.Add(Request);
            await _dbContext.SaveChangesAsync();
            return true;
        }
    }
}
