﻿using Koba.API.DBContext;
using Koba.API.Repository.Interface;
using Nest;

namespace Koba.API.Repository
{
    public class AuthorRepository : IAuthorRepository
    {
        private readonly ISqlRepository<Vidvan_Information_View> _vidvanInformationView;
        private readonly ISqlRepository<vid_bottom_view> _vidvanDadaGuru;

        public AuthorRepository(ISqlRepository<Vidvan_Information_View> vidvanInformationView, ISqlRepository<vid_bottom_view> vidvanDadaGuru)
        {
            _vidvanInformationView = vidvanInformationView;
            _vidvanDadaGuru = vidvanDadaGuru;
        }

        public async Task<Vidvan_Information_View> GetByAuthorId(string vid_no)
        {
            var Data = await _vidvanInformationView.Get();
            return Data.FirstOrDefault(x => x.Vid_No == vid_no);
        }

        public async Task<vid_bottom_view> GetGuruNameByAuthorId(string vid_no)
        {
            var Data = await _vidvanDadaGuru.Get();
            return Data.FirstOrDefault(x => x.Vid_No == vid_no);
        }
    }
}
