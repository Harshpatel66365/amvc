﻿using Koba.API.DBContext;
using Koba.API.Models;
using Koba.API.Repository.Interface;
using Microsoft.EntityFrameworkCore;
using Nest;

namespace Koba.API.Repository
{
    public class HashpratRepository : IHashpratRepository
    {
        private readonly ApplicationDBContext _dbContext;
        private readonly ISqlRepository<Hp_Inf_View> _hpInfo;
        private readonly ISqlRepository<hp_vid_lnk_view> _vidInfo;


        public HashpratRepository(ApplicationDBContext dBContext, ISqlRepository<Hp_Inf_View> hpInfo, ISqlRepository<hp_vid_lnk_view> vidInfo)
        {
            _dbContext = dBContext;
            _hpInfo = hpInfo;
            _vidInfo = vidInfo;
        }

        public async Task<HaspratInfoDto> getDetails(string hpNo)
        {
            var hpInfomation = await _hpInfo.Get();

            var result = hpInfomation.FirstOrDefault(x => x.Hp_No == hpNo);

            if (result == null)
            {
                return null;
            }

            var vidData = await _vidInfo.Get();

            var vidInfo = vidData.FirstOrDefault(x => x.Hp_No == hpNo); // Get the first matching result

            //var bhandarName = _dbContext.Bhandar_List
            //            .Where(b => b.Bhandar_Code == result.Bhandar_Code)
            //            .Select(b => b.Bhandar_Name)
            //            .FirstOrDefault();

            var hpInformation = new HaspratInfoDto()
            {
                Hp_No = result.Hp_No,
                Hp_Nam = result.Hp_Nam,
                Bhandar_Code = result.Bhandar_Code,
                Bhandar_Name = result.Bhandar_Short_Name,
                year_value = result.year_value,
                Main_Nam = result.Main_Nam,
                Hp_Tot_Pet = result.Hp_Tot_Pet,
                Purnata_short_name = result.Purnata_short_name,
                Dasha_Short_Name = result.Dasha_Short_Name,
                Lipi_Short_Name = result.Lipi_Short_Name,
                Material_Short_Name = result.Material_Short_Name,
                Hp_Type_Short_Name = result.Hp_Type_Short_Name,
                Dharma_Code = result.Dharma_Code,
                Pgs_Net = result.Pgs_Net,
                Length_Min = result.Length_Min,
                Width_Min = result.Width_Min,
                Lines_Min = result.Lines_Min,
                Char_Min = result.Char_Min,
                Lekhan_Prakar_short_name = result.Lekhan_Prakar_short_name,
                Related_Tot_Vidvan = result.Related_Tot_Vidvan,
                Related_Tot_Kruti = result.Related_Tot_Kruti,
                Related_Tot_Laksn = result.Related_Tot_Laksn,
                Related_Tot_Dasha_Detail_Codes = result.Related_Tot_Dasha_Detail_Codes,
                Related_Tot_Nam = result.Related_Tot_Nam,
                Related_Tot_Shlok = result.Related_Tot_Shlok,
                Related_Tot_Year = result.Related_Tot_Year,
                Related_Tot_City = result.Related_Tot_City,
                Related_Tot_Internal_Issue = result.Related_Tot_Internal_Issue,
                Related_Tot_External_Issue = result.Related_Tot_External_Issue,
                Related_Tot_Xerox_Issue = result.Related_Tot_Xerox_Issue,
                year_type_short_name = result.year_type_short_name,
                Bhandar_Short_Name = result.Bhandar_Short_Name,
                Name_Type_Short_Name = result.Name_Type_Short_Name,
                vir_st_year = result.vir_st_year,
                vir_end_year = result.vir_end_year,
                vid_No = vidInfo != null ? vidInfo.Vid_No : string.Empty,
                Vid_Name = vidInfo != null ? vidInfo.Vid_Nam : string.Empty,
                Vid_Type_Short_Name = vidInfo != null ? vidInfo.Vid_Type_Short_Name : string.Empty
            };

            return hpInformation;

        }

        public async Task<Hp_Inf_View> getByHPId(string HpId)
        {
            var Data = await _hpInfo.Get();
            return Data.FirstOrDefault(x => x.Hp_No == HpId);
        }
    }
}
