﻿using Koba.API.Models;

namespace Koba.API.Repository.Interface
{
    public interface IVidvanRepository
    {
        public Task<VidvanInfoDto> getDetails(string hpNo);

    }
}
