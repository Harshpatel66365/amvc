﻿using Koba.API.DBContext;
using Koba.API.Models;

namespace Koba.API.Repository.Interface
{
    public interface IPrakashanRepository
    {
        public Task<PrakashanInfoDto> getDetails(string hpNo);
        public Task<Prksn_Info_View> getByPrakashanId(string prNo);
    }
}
