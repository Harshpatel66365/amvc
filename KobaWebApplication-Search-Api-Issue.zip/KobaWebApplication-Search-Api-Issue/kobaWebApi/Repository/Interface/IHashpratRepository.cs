﻿using Koba.API.DBContext;
using Koba.API.Models;

namespace Koba.API.Repository.Interface
{
    public interface IHashpratRepository
    {
        public Task<HaspratInfoDto> getDetails(string hpNo);

        public Task<Hp_Inf_View> getByHPId(string HpId);
    }
}
