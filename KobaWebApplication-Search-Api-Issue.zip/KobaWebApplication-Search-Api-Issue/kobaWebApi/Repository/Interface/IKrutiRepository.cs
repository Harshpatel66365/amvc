﻿using Koba.API.DBContext;
using Koba.API.Models;

namespace Koba.API.Repository.Interface
{
    public interface IKrutiRepository
    {
        public Task<KrutiInfoDto> getDetails(string hpNo);
        public Task<Kruti_Information> getByKrutiId(string krNo);
    }
}
