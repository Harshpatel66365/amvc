﻿using Koba.API.Models;
using Microsoft.AspNetCore.Mvc;

namespace Koba.API.Repository.Interface
{
    public interface IRequestToBookRepository
    {
        public Task<bool> RequestToBook(RequestToBookRequest request);
    }
}
