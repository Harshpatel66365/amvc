﻿using Koba.API.DBContext;

namespace Koba.API.Repository.Interface
{
    public interface IAuthorRepository
    {
        public Task<Vidvan_Information_View> GetByAuthorId(string Vid_No);
        public Task<vid_bottom_view> GetGuruNameByAuthorId(string vid_no);
    }
}
