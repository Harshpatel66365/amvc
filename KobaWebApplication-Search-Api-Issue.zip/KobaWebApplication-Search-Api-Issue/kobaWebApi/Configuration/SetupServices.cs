﻿using Koba.API.Repository.Interface;
using Koba.API.Repository;

namespace Koba.API.Configuration
{
    public static class SetupServices
    {
        public static void SetupDIServices(this IServiceCollection services)
        {
            services.AddScoped(typeof(ISqlRepository<>), typeof(SqlDBRepository<>));
            services.AddScoped<IAuthorRepository, AuthorRepository>();
        }
    }
}
