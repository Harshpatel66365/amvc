﻿namespace Koba.API.DBContext
{
    public class Prksn_Vid_Lnk
    {
        public string Prksn_Key { get; set; }
        public string? Prksn_Pet_Key { get; set; }
        public string Vid_No { get; set; }
        public int Vid_Nam_Seq { get; set; }
        public string Vid_Type_Short_Name { get; set; }
        public string Surname_Key { get; set; }
        public string Gach_key { get; set; }
        public int? Gach_Nam_Seq { get; set; }
        public int? Disp_Seq { get; set; }
        public string Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }
        public DateTime? Add_Date_Time { get; set; }
        public DateTime? Updt_Date_Time { get; set; }
        public DateTime? Edit_Date_Time { get; set; }
        public DateTime? Certi_Date_Time { get; set; }
    }
}
