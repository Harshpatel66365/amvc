﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace Koba.API.DBContext
{
    public class ApplicationDBContext : DbContext
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Hp_Vid_Lnk>().HasNoKey(); 
            modelBuilder.Entity<Kruti_Information>().HasNoKey(); 
            modelBuilder.Entity<Prksn_Vid_Lnk>().HasNoKey(); 
            modelBuilder.Entity<Vidvan_Information_View>().HasNoKey();
            modelBuilder.Entity<Hp_Inf_View>().HasNoKey();
            modelBuilder.Entity<Prksn_Inf>().HasNoKey();
            modelBuilder.Entity<Vid_Dada_GuruData_View>().HasNoKey();
            modelBuilder.Entity<Prksn_Info_View>().HasNoKey();
            modelBuilder.Entity<vid_bottom_view>().HasNoKey();
            modelBuilder.Entity<hp_vid_lnk_view>().HasNoKey();
            modelBuilder.Entity<Bhandar_List>().HasNoKey();
            modelBuilder.Entity<Vid_Guru_View>().HasNoKey();
            modelBuilder.Entity<prksn_pdf_lnk>().HasNoKey();
            modelBuilder.Entity<prksn_view>().HasNoKey();
            modelBuilder.Entity<Prksn_Series_Lnk_View>().HasNoKey();
            modelBuilder.Entity<Prksn_Vid_Lnk_View>().HasNoKey();
        }

        public DbSet<Kruti_Information> Kruti_Information { get; set; }
        public DbSet<Hp_Vid_Lnk> Hp_Vid_Lnk { get; set; }
        public DbSet<Prksn_Vid_Lnk> Prksn_Vid_Lnk { get; set; }
        public DbSet<Vidvan_Information_View> Vidvan_Information_View { get; set; }
        public DbSet<Hp_Inf_View> Hp_Inf_View { get; set; }
        public DbSet<Prksn_Inf> Prksn_Inf { get; set; }
        public DbSet<Vid_Dada_GuruData_View> Vid_Dada_GuruData_View { get; set; }
        public DbSet<Prksn_Info_View> Prksn_Info_View { get; set; }
        public DbSet<vid_bottom_view> vid_bottom_view { get; set; }
        public DbSet<hp_vid_lnk_view> hp_vid_lnk_view { get; set; }
        public DbSet<Bhandar_List> Bhandar_List { get; set; }
        public DbSet<Vid_Guru_View> Vid_Guru_View { get; set; }
        public DbSet<RequestToBook> RequestToBook { get; set; }
        public DbSet<prksn_pdf_lnk> prksn_pdf_lnk { get; set; }
        public DbSet<prksn_view> prksn_view { get; set; }
        public DbSet<Prksn_Series_Lnk_View> Prksn_Series_Lnk_View { get; set; }
        public DbSet<Prksn_Vid_Lnk_View> Prksn_Vid_Lnk_View { get; set; }
    }
}
