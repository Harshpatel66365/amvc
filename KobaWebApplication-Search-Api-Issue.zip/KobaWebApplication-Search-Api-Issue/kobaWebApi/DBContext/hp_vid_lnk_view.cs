﻿namespace Koba.API.DBContext
{
    public class hp_vid_lnk_view
    {
        public string? Hp_No { get; set; }
        public string? Vid_Type_Short_Name { get; set; }
        public string? Vid_No { get; set; }
        public string? Vid_Nam { get; set; }       
    }
}
