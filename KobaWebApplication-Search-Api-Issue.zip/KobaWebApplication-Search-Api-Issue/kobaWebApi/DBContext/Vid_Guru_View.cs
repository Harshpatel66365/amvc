﻿namespace Koba.API.DBContext
{
    public class Vid_Guru_View
    {
        public string Lower_Vid_No { get; set; }
        public string Lower_Sambandh_Short_Name { get; set; }
        public string Upper_Vid_No { get; set; }
        public string? Upper_Name { get; set; }
        public string? Upper_Swarup { get; set; }
    }
}
