﻿namespace Koba.API.DBContext
{
    public class Prksn_Info_View
    {
        public string? Prksn_Key { get; set; }
        public string? prksn_name { get; set; }
        public string? volume { get; set; }
        public string? alias { get; set; }
        public string? vidvan { get; set; }
        public int? Reprint { get; set; }
        public int? Jild { get; set; }
        public string? pblsr_name { get; set; }
        public string? pblsr_info { get; set; }
        public string? editon_title { get; set; }
        public int? editon { get; set; }
        public string? prksn_year { get; set; }
        public short? Vir_St_Duration { get; set; }
        public short? Vir_End_Duration { get; set; }
        public string? page_title { get; set; }
        public string? pages { get; set; }
        public string? isbn { get; set; }
        public string? isbn_set_no { get; set; }
        public string? purnata_name { get; set; }
        public string? purnata_remark { get; set; }
        public string? page_material { get; set; }
        public string? series { get; set; }
        public string? tot_petank_title { get; set; }
        public string? tot_petank { get; set; }
    }
}
