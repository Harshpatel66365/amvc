﻿namespace Koba.API.DBContext
{
    public class Hp_Inf_View
    {
        public string? Bhandar_Code { get; set; }
        public string? Hp_No { get; set; }
        public string? Form_No { get; set; }
        public string? Hp_Tot_Pet { get; set; }
        public string? Purnata_short_name { get; set; }
        public int? Purnata_Remark_Code { get; set; }
        public string? Purnata_Remark { get; set; }
        public string? Dasha_Short_Name { get; set; }
        public string? Dasha_Remark { get; set; }
        public string? Laksn_Code_String { get; set; }
        public string? Importance_Level_Code { get; set; }
        public string? Dasha_code_string { get; set; }
        public string? Hp_Vishesh { get; set; }
        public string? Prst_Pusp_Type_Short_Name { get; set; }
        public string? Prati_Pusp_Pariman_Count { get; set; }
        public string? Hp_Parampara { get; set; }
        public int? Pur_Don_Lot_No { get; set; }
        public string? Old_No { get; set; }
        public string? Lipi_Short_Name { get; set; }
        public string? Material_Short_Name { get; set; }
        public string? Hp_Type_Short_Name { get; set; }
        public string? Dharma_Code { get; set; }
        public int? Pgs_First { get; set; }
        public int? Pgs_Last { get; set; }
        public string? Pgs_Ght { get; set; }
        public int? Pgs_Ght_Tot { get; set; }
        public string? Pgs_Avst_Ght { get; set; }
        public int? Pgs_Avst_Ght_Tot { get; set; }
        public string? Pgs_Bdth { get; set; }
        public int? Pgs_Bdth_Tot { get; set; }
        public int? Pgs_Net { get; set; }
        public decimal? Length_Min { get; set; }
        public decimal? Length_Max { get; set; }
        public decimal? Width_Min { get; set; }
        public decimal? Width_Max { get; set; }
        public int? Lines_Min { get; set; }
        public int? Lines_Max { get; set; }
        public int? Char_Min { get; set; }
        public int? Char_Max { get; set; }
        public string? Lekhan_Prakar_short_name { get; set; }
        public string? Readership_Lvl { get; set; }
        public string? Catalog_No { get; set; }
        public string? Del_miss_short_name { get; set; }
        public int? Related_Tot_Vidvan { get; set; }
        public int? Related_Tot_Kruti { get; set; }
        public int? Related_Tot_Laksn { get; set; }
        public int? Related_Tot_Dasha_Detail_Codes { get; set; }
        public int? Related_Tot_Nam { get; set; }
        public int? Related_Tot_Shlok { get; set; }
        public int? Related_Tot_Year { get; set; }
        public int? Related_Tot_City { get; set; }
        public int? Related_Tot_Internal_Issue { get; set; }
        public int? Related_Tot_External_Issue { get; set; }
        public int? Related_Tot_Xerox_Issue { get; set; }
        public string? Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }
        public string? Bhandar_Short_Name { get; set; }
        public string? Remark { get; set; }
        public string? Hp_Nam { get; set; }
        public string? Hp_Nam_filtered { get; set; }
        public string? Main_Nam { get; set; }
        public string? Name_Type_Short_Name { get; set; }
        public string? year_type_short_name { get; set; }
        public string? year_value { get; set; }
        public short? vir_st_year { get; set; }
        public short? vir_end_year { get; set; }
    }

}
