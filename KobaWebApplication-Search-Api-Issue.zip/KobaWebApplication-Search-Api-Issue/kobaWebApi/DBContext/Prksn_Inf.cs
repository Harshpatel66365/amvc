﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Koba.API.DBContext
{
    public class Prksn_Inf
    {
        [Key]
        public string? Prksn_Key { get; set; }

        public int? Edition { get; set; }
        public int? Reprint { get; set; }

        public string? Year_Type_Short_Name { get; set; }

        public string? Prksn_Year { get; set; }

        public short? Vir_St_Duration { get; set; }
        public short? Vir_End_Duration { get; set; }
        public int? Jild { get; set; }

        public string? Is_Set_Complete { get; set; }

        public string? Vol_Sub_Vol { get; set; }

        public string? Pages { get; set; }

        public string? Page_No_Sides { get; set; }

        public int? Pages_Net { get; set; }

        public string? Isbn { get; set; }

        public string? Isbn_Set_No { get; set; }

        public string? Purnata_short_name { get; set; }

        public string? Purnata_Remark { get; set; }

        public string? Dharma_Code { get; set; }

        public string? Tot_Petank { get; set; }

        public string? Remark { get; set; }

        public string? Page_Material_Short_Name { get; set; }
        
        public string? Object_Size_Short_Name { get; set; }

        public decimal? Thickness { get; set; }

        public string? Readership_Lvl { get; set; }

        public string? Importance_level_Code { get; set; }

        public string? Published_type_Short_name { get; set; }

        public string? EMedia_Type_short_name { get; set; }

        public int? EMedia_Group_Seq_No { get; set; }
        public short? EMedia_Group_Seq_Tot { get; set; }

        public string? Prksn_Family_SubGroup_Parent_ID { get; set; }

        public int? Prksn_Family_member_disp_seq { get; set; }
    
        public string? Normal_Petanks_ToBe_Added { get; set; }

        public string? Normal_Petanks_Added_Level { get; set; }

        public string? Chitra_Petanks_ToBe_Added { get; set; }

        public string? Chitra_Petanks_Added_Level { get; set; }

        public string? Katha_Petanks_ToBe_Added { get; set; }

        public string? Katha_Petanks_Added_Level { get; set; }

        public int? Related_Tot_Editor_Group_Only { get; set; }
        public int? Related_Tot_All_Vidvan { get; set; }
        public int? Related_Tot_Book { get; set; }
        public int? Related_Tot_Emedia { get; set; }
        public int? Related_Tot_Image { get; set; }
        public int? Related_Tot_Nam { get; set; }
        public string? Add_Init { get; set; }

        public string? Updt_Init { get; set; }

        public string? Last_Edtr { get; set; }

        public string? Certifier { get; set; }

        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }

        public DateTime? Add_Date_Time { get; set; }
        public DateTime? Updt_Date_Time { get; set; }
        public DateTime? Edit_Date_Time { get; set; }
        public DateTime? Certi_Date_Time { get; set; }
    }
}
