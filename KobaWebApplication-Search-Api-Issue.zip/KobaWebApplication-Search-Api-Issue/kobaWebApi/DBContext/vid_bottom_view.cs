﻿namespace Koba.API.DBContext
{
    public class vid_bottom_view
    {
        public string? Vid_No { get; set; }
        public int? Vid_Nam_Seq { get; set; }
        public string? Vid_Nam { get; set; }
        public string? Vid_Nam_filtered { get; set; }
        public string? Name_Type_Short_Name { get; set; }
        public string? Dharma_Code { get; set; }
        public string? Male_Female_Code { get; set; }
        public string? Sadhu_Grihast_Code { get; set; }
        public string? Year_Doubtful { get; set; }
        public string? Surname { get; set; }
        public string? Swarup_Short_Name { get; set; }
        public string? Gach_Key { get; set; }
        public string? Gach_nam { get; set; }
        public string? Year_Type_Short_Name { get; set; }
        public string? Vid_Duration { get; set; }
        public short? Vir_St_Duration { get; set; }
        public short? Vir_End_Duration { get; set; }
        public string? Vid_Family_Lvl_No { get; set; }
        public string? Vid_Tree_No { get; set; }
        public string? Short_Remark { get; set; }
        public string? Guru { get; set; }
        public string? Guru_Name { get; set; }
        public string? Guru_Swarup { get; set; }
        public string? Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }
        public string? Sambandh_With_Guru { get; set; }
    }
}
