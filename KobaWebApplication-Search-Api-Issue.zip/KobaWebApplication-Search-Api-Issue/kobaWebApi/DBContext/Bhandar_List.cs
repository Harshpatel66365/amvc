﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace Koba.API.DBContext
{
    public class Bhandar_List
    {
        public string Bhandar_Code { get; set; }
        public string Bhandar_Name { get; set; }
        public string Bhandar_Short_Name { get; set; }
        public string Prnt_Bhandar_Code { get; set; }
        public string Readership_lvl { get; set; }
        public string? Remark { get; set; }
        public string? Short_Remark { get; set; }
        public char Hp_No { get; set; }
        public string? Hp_Form_No { get; set; }
        public string? Hp_Old_No { get; set; }
        public string? Hp_Unit_Type_Short_Name { get; set; }
        public char Book_Accession_No { get; set; }
        public char Book_Vibhagiya_No { get; set; }
        public string? Book_Unit_Type_Short_Name { get; set; }
        public string Mag_Ank_Copy_Accession_No { get; set; }
        public string Mag_Bind_No { get; set; }
        public string? Mag_Unit_Type_Short_Name { get; set; }
        public string Antique_Accession_No { get; set; }
        public string Museum_Antique_Vibhagiya_No { get; set; }
        public string? Museum_Unit_Type_Short_Name { get; set; }
        public int? Related_Tot_Book { get; set; }
        public int? Related_Tot_Emedia { get; set; }
        public int? Related_Tot_Vibhag { get; set; }
        public int? Related_Tot_Hp { get; set; }
        public int? Related_Tot_Mag_Ank_Copy { get; set; }
        public int? Related_Tot_Museum_Antique { get; set; }
        public string Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }
    }
}
