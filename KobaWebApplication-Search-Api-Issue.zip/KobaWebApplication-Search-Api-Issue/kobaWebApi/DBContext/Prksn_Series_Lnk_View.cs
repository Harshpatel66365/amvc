﻿namespace Koba.API.DBContext
{
    public class Prksn_Series_Lnk_View
    {
        public string? Series_Key { get; set; }
        public string? Series_Nam { get; set; }
        public string? Series_Nam_Filtered { get; set; }
        public int? Series_Nam_Seq { get; set; }
        public string? Series_Type_Name { get; set; }
        public string? Series_Type_Short_Name { get; set; }
        public string? Series_Seq_No { get; set; }
        public string? Series_Sub_Seq_No { get; set; }
        public int Disp_Seq { get; set; }
        public string? Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public string? Prksn_Key { get; set; }
        public int? Edition { get; set; }
        public string? Year_Type_Short_Name { get; set; }
        public string? Prksn_Year { get; set; }
        public string? Vol_Sub_Vol { get; set; }
        public string? Pages { get; set; }
        public string? Prksn_Nam { get; set; }
        public string? City_Nam { get; set; }
        public string? Pblsr_Nam { get; set; }
        public string? Remark { get; set; }
    }
}
