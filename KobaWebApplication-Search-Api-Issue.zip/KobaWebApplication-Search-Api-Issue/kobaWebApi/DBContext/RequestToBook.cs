﻿using System.ComponentModel.DataAnnotations;

namespace Koba.API.DBContext
{
    public class RequestToBook
    {
        [Key]
        public int Id { get; set; }
        public string BookSrNo { get; set; }
        public string BookCategory { get; set; }
        public string BookTitle { get; set; }
        public string RequestedPersonMobile { get; set; }
        public string RequestedPersonName { get; set; }
        public string RequestedPersonCity { get; set; }
        public string RequestedPersonState { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
