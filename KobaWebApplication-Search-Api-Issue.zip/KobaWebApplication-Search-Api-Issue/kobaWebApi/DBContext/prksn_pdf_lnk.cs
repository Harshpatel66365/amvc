﻿namespace Koba.API.DBContext
{
    public class prksn_pdf_lnk
    {
        public string? Prksn_Key { get; set; }
        public string? Pdf_File_Path { get; set; }
        public string? Pdf_Image_150 { get; set; }
        public string? Pdf_Image_300 { get; set; }
        public string? Pdf_Text_Unicode { get; set; }
        public string? Pdf_Text_ThirdParty_font { get; set; }
        public string? Index_Detail { get; set; }
        public string? Index_File_Name { get; set; }
        public string? Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }
        public DateTime? Add_Date_Time { get; set; }
        public DateTime? Updt_Date_Time { get; set; }
        public DateTime? Edit_Date_Time { get; set; }
        public DateTime? Certi_Date_Time { get; set; }
        public string? Pdf_File_Source_150 { get; set; }
        public string? Pdf_File_Source_300 { get; set; }
        public string? Pdf_File_Source_Unicode { get; set; }
        public string? Pdf_File_Source_ThirdParty_font { get; set; }
    }
}
