﻿namespace Koba.API.DBContext
{
    public class Kruti_Information
    {
        public string? Kr_Key { get; set; }
        public string? Kr_Nam { get; set; }
        public string? Swarup_Short_Name { get; set; }
        public string? Bhasha_Short_Name { get; set; }
        public string? Vid_Nam { get; set; }
        public string? AdiVakya { get; set; }
        public string? AntimVakya { get; set; }
        public int? Kr_Nam_Seq { get; set; }
        public string? Prakar_Short_Name { get; set; }
        public string? Vibhag_Code { get; set; }
        public string? Dharma_Code { get; set; }
        public string? Year_Type_Short_Name { get; set; }
        public string? Year_Value { get; set; }
        public string? Year_Sankhiya_Sabda { get; set; }
        public string? Rachna_Prst_Type_Short_Name { get; set; }
        public int? Granthagra { get; set; }
        public string? Chand_Type_short_name { get; set; }
        public string? Adhyay_short_name { get; set; }
        public string? Chand_count { get; set; }
        public string? Adhyay_count { get; set; }
        public string? kr_lvl_No { get; set; }
        public string? Subject { get; set; }
        public string? Readership_Lvl { get; set; }
        public int? Related_Tot_Prksn { get; set; }
        public int? Related_Tot_Hp { get; set; }
        public int? Related_Tot_Mag_Ank_Petank { get; set; }
        public int? Related_Tot_Childs { get; set; }
        public int? Related_Tot_Aadharit_Kr { get; set; }
        public int? Related_Tot_Aadharbhut_Kr { get; set; }
        public int? Related_Tot_Karta_Group_Vidvan { get; set; }
        public int? Related_Tot_Vidvan { get; set; }
        public int? Related_Tot_Kr_Nam { get; set; }
        public string? Main_Nam { get; set; }
        public string? Vid_Type_Short_Name { get; set; }
        public string? Vid_No { get; set; }
        public string? Name_Type_Short_Name { get; set; }
        public string? Kr_Nam_Filtered { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public int? Vid_Nam_Seq { get; set; }
        public string? Short_Remark { get; set; }
        public string? Serva_Granthagra { get; set; }
        public string? Long_Remark { get; set; }
        public string? City_Nam { get; set; }
        public string? Research_Remark { get; set; }
        public short? vir_st_duration { get; set; }
        public short? vir_end_duration { get; set; }
        public string? Filtered_Reverse_Antimvakya { get; set; }
        public string? Rev_Antimvakya { get; set; }
        public string? add_init { get; set; }
        public string? Updt_init { get; set; }
    }
}
