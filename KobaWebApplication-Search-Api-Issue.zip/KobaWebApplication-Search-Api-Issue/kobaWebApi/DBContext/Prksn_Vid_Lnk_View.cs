﻿namespace Koba.API.DBContext
{
    public class Prksn_Vid_Lnk_View
    {
        public string? Vid_No { get; set; }
        public string? Vid_Nam { get; set; }
        public int? Vid_Nam_Seq { get; set; }
        public string? Swarup_Short_Name { get; set; }
        public string? Surname_Key { get; set; }
        public string? Vid_Type_Short_Name { get; set; }
        public string? Dharma_Code { get; set; }
        public string? Male_Female_Code { get; set; }
        public string? Sadhu_Grihast_Code { get; set; }
        public string? Vid_Tree_No { get; set; }
        public string? Vid_Family_Lvl_No { get; set; }
        public string? Year_Type_Short_Name { get; set; }
        public string? Vid_Duration { get; set; }
        public short? Vir_St_Duration { get; set; }
        public short? Vir_End_Duration { get; set; }
        public string? Year_Doubtful { get; set; }
        public int? Disp_Seq { get; set; }
        public string? Gach_Key { get; set; }
        public string? Gach_nam { get; set; }
        public int? Gach_Nam_Seq { get; set; }
        public string? Guru { get; set; }
        public string? Guru_Name { get; set; }
        public string? Guru_Swarup { get; set; }
        public string? Dada_Guru { get; set; }
        public string? Dada_Guru_Name { get; set; }
        public string? Dada_Guru_Swarup { get; set; }
        public string? Vid_Nam_filtered { get; set; }
        public string? Name_Type_Short_Name { get; set; }
        public string? Prksn_Key { get; set; }
        public string? Prksn_Pet_Key { get; set; }
        public string? Short_Remark { get; set; }
        public string? Long_Remark { get; set; }
        public int? Related_Tot_Kr { get; set; }
        public int? Related_Tot_Prksn { get; set; }
        public int? Related_Tot_Hp { get; set; }
        public int? Related_Tot_Pblsr { get; set; }
        public int? Related_Tot_Series { get; set; }
        public int? Related_Tot_Mag_ank { get; set; }
        public int? Related_Tot_Mag_Ank_Petank { get; set; }
        public int? Related_Tot_Museum_Antique { get; set; }
        public int? Related_Tot_Child { get; set; }
        public string? Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
    }
}
