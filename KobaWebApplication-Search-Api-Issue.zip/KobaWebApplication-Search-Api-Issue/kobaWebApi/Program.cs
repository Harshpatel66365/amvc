using Koba.API.Configuration;
using Koba.API.DBContext;
using Koba.API.Models;
using Koba.API.Repository;
using Koba.API.Repository.Interface;
using Koba.API.Services;
using kobaWebApi.Models;
using kobaWebApi.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();

//Assign ConnectionString to ApplicationDbContext
builder.Services.AddDbContext<ApplicationDBContext>(options =>
        options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Register ElasticsearchService
builder.Services.Configure<ElasticsearchSettings>(builder.Configuration.GetSection("Elasticsearch"));
builder.Services.AddScoped<ElasticsearchService>();
builder.Services.AddScoped<IHashpratRepository, HashpratRepository>();
builder.Services.AddScoped<IKrutiRepository, KrutiRepository>();
builder.Services.AddScoped<IPrakashanRepository, PrakashanRepository>();
builder.Services.AddScoped<IVidvanRepository, VidvanRepository>();
builder.Services.AddScoped<IRequestToBookRepository, RequestToBookRepository>();

//Register Email Service
builder.Services.Configure<EmailSettings>(builder.Configuration.GetSection("EmailSettings"));
builder.Services.AddTransient<IEmailService, EmailService>();

// Add Swagger/OpenAPI support
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Allow Cors
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigin",
        builder =>
        {
            builder.AllowAnyOrigin()
                   .AllowAnyMethod()
                   .AllowAnyHeader();
        });
});

//Register Services
builder.Services.SetupDIServices();

var app = builder.Build();

//// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
    app.UseSwagger();
    app.UseSwaggerUI();
//}

//Use CROS Origin Policy in Your Application
app.UseCors("AllowSpecificOrigin");

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
