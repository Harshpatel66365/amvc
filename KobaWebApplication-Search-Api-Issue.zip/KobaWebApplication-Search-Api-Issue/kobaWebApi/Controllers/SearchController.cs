﻿using AutoWrapper.Wrappers;
using Koba.API.Models;
using Koba.API.Repository.Interface;
using Koba.API.Services;
using kobaWebApi.Models;
using kobaWebApi.Services;
using KobaWebApplication.Dto.Browser;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace kobaWebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SearchController : ControllerBase
    {
        private readonly ElasticsearchService _elasticsearchService;
        private readonly IHashpratRepository _hashpratRepository;
        private readonly IKrutiRepository _krutiRepository;
        private readonly IVidvanRepository _vidvanRepository;
        private readonly IPrakashanRepository _prakashanRepository;
        private readonly IRequestToBookRepository _requestToBookRepository;
        private readonly IEmailService _emailService;

        public SearchController(ElasticsearchService elasticsearchService, IHashpratRepository hashpratRepository, IKrutiRepository krutiRepository,
            IPrakashanRepository prakashanRepository, IVidvanRepository vidvanRepository, IRequestToBookRepository requestToBookRepository, IEmailService emailService)
        {
            _elasticsearchService = elasticsearchService;
            _hashpratRepository = hashpratRepository;
            _krutiRepository = krutiRepository;
            _vidvanRepository = vidvanRepository;
            _prakashanRepository = prakashanRepository;
            _requestToBookRepository = requestToBookRepository;
            _emailService = emailService;
        }

        [HttpPost]
        public async Task<IActionResult> Search([FromBody] SearchRequest request)
        {
            var stopwatch = Stopwatch.StartNew();

            var searchResponse = await _elasticsearchService.SearchAsync(request);

            stopwatch.Stop();

            var elapsedMilliseconds = stopwatch.ElapsedMilliseconds;

            if (searchResponse != null)
            {
                var result = new SearchResponseDto
                {
                    Results = searchResponse.Results,
                    SearchTime = elapsedMilliseconds,
                    TotalResults = searchResponse.TotalCount,
                    PageNumber = request.PageNumber,
                    PageSize = request.PageSize,
                    SelectedIndex = request.SelectedIndex,
                    SearchTerm = request.SearchTerm
                };

                return Ok(result);
            }
            else
            {
                return StatusCode(500, "Error searching for documents: ");
            }
        }

        [HttpGet("Count/{searchTerm}")]
        public async Task<ApiResponse> GetCount(string searchTerm, bool IsExactSearch)
        {
            var data = await _elasticsearchService.GetCount(searchTerm, IsExactSearch);
            if (data == null)
            {
                return new ApiResponse(message: "Data Not Found", result: data, statusCode: 404);
            }
            return new ApiResponse(message: "", result: data, statusCode: 200);
        }

        [HttpGet("Detail/{searchType}/{searchTerm}")]
        public async Task<ApiResponse> GetData(string searchType, string searchTerm)
        {
            object data = null;

            if (searchType.ToLower() == "kruti")
            {
                data = await _krutiRepository.getDetails(searchTerm);
            }
            else if (searchType.ToLower() == "hastprat")
            {
                data = await _hashpratRepository.getDetails(searchTerm);
            }
            if (searchType.ToLower() == "prakashan")
            {
                data = await _prakashanRepository.getDetails(searchTerm);
            }
            else if (searchType.ToLower() == "vidvan")
            {
                data = await _vidvanRepository.getDetails(searchTerm);
            }

            if (data == null)
            {
                return new ApiResponse(message: "Data Not Found", result: data, statusCode: 404);
            }
            return new ApiResponse(message: "", result: data, statusCode: 200);
        }

        [HttpPost("Book/")]
        public async Task<IActionResult> RequestToBook([FromBody] RequestToBookRequest request)
        {
            if (ModelState.IsValid)
            {
                var result = await _requestToBookRepository.RequestToBook(request);

                if (result == null)
                {
                    return BadRequest("Enter Valid Data.");
                }
                else
                {
                    await _emailService.SendEmailAsync("Book Request Received", request);
                    return Ok(result);
                }
            }
            return null;
        }

        [HttpGet("Book/IsParakashanAvailableInLibrary")]
        public async Task<IActionResult> IsParakashanAvailableInLibrary(string prksnNo)
        {
            string result = await _elasticsearchService.IsParakashanAvailableInLibrary(prksnNo);

            if (!string.IsNullOrEmpty(result))
            {
                return await Task.FromResult<IActionResult>(Ok(new ApiResponse(message: "", result: new { IsAvailabel = true, Url = $"http://jainelibrary.org/book-detail/?srno={result}" }, statusCode: 200)));
            }

            return await Task.FromResult<IActionResult>(Ok(new ApiResponse(message: "", result: new
            {
                IsAvailabel = false,
                Message = "The requested book is not available.",
                Url = "",
                StatusCode = 200
            }, statusCode: 200)));
        }

        [HttpGet("Suggestion/{searchTerm}")]
        public async Task<ApiResponse> GetSuggestion(string searchTerm)
        {
            SearchRequest request = new SearchRequest();
            request.SearchTerm = searchTerm;

            request.IsExactSearch = false;
            var data = await _elasticsearchService.GetSuggestionAsync(request);
            if (data == null)
            {
                return new ApiResponse(message: "Data Not Found", result: data, statusCode: 404);
            }
            return new ApiResponse(message: "", result: data, statusCode: 200);
        }

        [HttpPost("GetAdvanceSearchFilters/")]
        public async Task<IActionResult> GetAdvanceSearchFilters([FromBody] SearchRequest request)
        {
            var searchResponse = await _elasticsearchService.GetAdvanceSearchFiltersAsync(request);

            if (searchResponse != null)
            {
                return Ok(searchResponse);
            }
            else
            {
                return StatusCode(500, "Error searching for documents: ");
            }
        }
    }
}