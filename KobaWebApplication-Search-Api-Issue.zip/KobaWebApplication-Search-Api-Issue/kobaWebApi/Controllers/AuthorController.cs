﻿using AutoWrapper.Wrappers;
using Koba.API.DBContext;
using Koba.API.Repository.Interface;
using Microsoft.AspNetCore.Mvc;

namespace Koba.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AuthorController : Controller
    {
        private IAuthorRepository _authorRepository;
        private ApplicationDBContext _applicationDBContext;
        public AuthorController(IAuthorRepository authorRepository, ApplicationDBContext applicationDBContext)
        {
            _authorRepository = authorRepository;
            _applicationDBContext = applicationDBContext;
        }

        [HttpGet("GetByAuthorId/{Id}")]
        public async Task<ApiResponse> GetByAuthorId(string Id)
        {
            var data = await _authorRepository.GetByAuthorId(Id);
            if (data == null)
            {
                return new ApiResponse(message: "Data Not Found", result: data, statusCode: 404);
            }
            return new ApiResponse(message: "Author Found", result: data, statusCode: 200);
        }
    }
}
