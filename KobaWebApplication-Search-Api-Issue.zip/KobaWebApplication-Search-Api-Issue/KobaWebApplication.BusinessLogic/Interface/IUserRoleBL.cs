﻿using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.DataGrid;
using KobaWebApplication.Dto.Role;
using KobaWebApplication.Dto.RolePermission;

namespace KobaWebApplication.BusinessLogic.Interface
{
    public interface IUserRoleBL
    {
        public Task<IEnumerable<Role>> GetUserRolesAsync(long userId);
        public Task AssignRoleToUserAsync(long userId, int roleId);
    }
}