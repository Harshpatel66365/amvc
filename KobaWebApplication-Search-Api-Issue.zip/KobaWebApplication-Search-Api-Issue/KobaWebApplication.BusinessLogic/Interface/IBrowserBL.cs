﻿using AutoWrapper.Models;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Browser;

namespace KobaWebApplication.BusinessLogic.Interface
{
    public interface IBrowserBL
    {
        public Task<SearchResponseDto?> PerformSearchAsync(SearchRequest request);
        public Task<SearchCountResponseDto> GetSearchCountsAsync(string searchTerm, bool isExactSearch);
        public Task<AdvanceFiltersDto> GetAdvanceSearchFilterAsync(SearchRequest request);
        public Task<ApiResponse> IsParakashanAvailableInLibrary(string prksnNo);
        public Task<bool> RequestToBook(BookRequestModel request);       
    }
}