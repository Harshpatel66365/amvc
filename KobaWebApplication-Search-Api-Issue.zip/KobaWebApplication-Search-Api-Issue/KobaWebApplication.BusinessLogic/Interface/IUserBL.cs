﻿using KobaWebApplication.Dto.Account;
using KobaWebApplication.Dto.Common;
using KobaWebApplication.Dto.DataGrid;
using KobaWebApplication.Dto.User;

namespace KobaWebApplication.BusinessLogic.Interface
{
    public interface IUserBL
    {
        public Task<List<UserDetailsDto>> GetAllUsers();

        public Task<JsonRepsonse<UserDetailsDto>> GetUserDataTable(UserFilterDto dataTableFilterDto);
        public Task<UserDetailsDto> GetUsersById(int UserId);
        public Task<CommonResponse> ChangeUserPassword(ChangePasswordReq passwordReq, int UserId);
        public Task<CommonResponse> UpdateUser(UserDetailsDto user);
    }
}