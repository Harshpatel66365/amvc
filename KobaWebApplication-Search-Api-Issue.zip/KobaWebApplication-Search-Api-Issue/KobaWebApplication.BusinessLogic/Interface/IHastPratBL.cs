﻿using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.AdvanceSearch;
using KobaWebApplication.Dto.Browser;
using KobaWebApplication.Dto.DataGrid;

namespace KobaWebApplication.BusinessLogic.Interface
{
    public interface IHastPratBL
    {
        Task<bool> AddHastPratInfo(AddHastpratInfoRequest_Dto? request);
        public Task<List<City_State_Country_View_Dto>> GetCitiesList();

        public Task<List<L_Dasha_Code_Dto>> GetDashaCodeList();

        public Task<List<L_Purnata_Code_Dto>> GetPurnataCodeList();

        public Task<List<L_Purnata_Remark_Code_Dto>> GetPurnataRemarkCodeList();

        public Task<JsonRepsonse<Hp_Inf_View>> GetHpInfoList(Hastprat_Search_Grid_Request_Dto model);
        public Task<List<L_Dharma_Code_Dto>> GetDharmaCodeList();
        public Task<string> BuildHastpratSearchQuery(Hastprat_Search_Request_Dto model);
        public Task<IQueryable<Hp_Inf_View>> GetFilteredHpInfViewAsync(Hastprat_Search_Request_Dto searchDto);
    }
}