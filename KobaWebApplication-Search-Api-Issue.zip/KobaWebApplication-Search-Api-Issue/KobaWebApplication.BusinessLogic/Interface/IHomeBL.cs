﻿using KobaWebApplication.DataEntities.Result;
using KobaWebApplication.Dto.DataGrid;
using KobaWebApplication.Dto.Home;
using KobaWebApplication.Dto.Home.BookOverDueDto;
using KobaWebApplication.Dto.Home.EditRequestsDto;
using KobaWebApplication.Dto.Home.Hp_Internal_Issue;
using KobaWebApplication.Dto.Home.L_DailyViewDto;
using KobaWebApplication.Dto.Home.PendingTaskDto;
using KobaWebApplication.Dto.Home.RemarkManagementDto;
using KobaWebApplication.Dto.Home.RoutinWorkDto;
using KobaWebApplication.Dto.Home.Unique_SuggestionDto;
using KobaWebApplication.Dto.Home.User_Error_Suggestion;
using KobaWebApplication.Dto.Home.User_Score_Board;

namespace KobaWebApplication.BusinessLogic.Interface
{
    public interface IHomeBL
    {
        public Task<JsonRepsonse<L_Gmandir_Messages_ResDto>> GetHomePageData(L_Gmandir_Edit_Request_FilterDto dataTableFilterDto);

        public Task<JsonRepsonse<Kr_Edit_Request_ResDto>> GetKr_Edit_ReqByUser(Kr_Edit_Request_FilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<Hp_Edit_ResponseDto>> GetHp_Edit_ReqByUser(Hp_Edit_Request_FilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<Vid_Edit_ResponseDto>> GetVid_Edit_ReqByUser(Vid_Edit_Request_FilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<Vid_Gach_Edit_Req_ResponseDto>> GetVid_Gach_Edit_ReqByUser(Vid_Gach_Edit_Request_FilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<Mag_Edit_Req_ResponseDto>> GetMag_Edit_ReqByUser(Mag_Edit_Request_FilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<Prksn_Edit_Request_ResDto>> GetPrksn_Edit_ReqByUser(Prksn_Edit_Request_FilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<Pblsr_Edit_Request_ResDto>> GetPblsr_Edit_ReqByUser(Pblsr_Edit_Request_FilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<Mag_Bind_Edit_Request_ResDto>> GetMag_Bind_Edit_ReqByUser(Mag_Bind_Edit_Request_FilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<Kr_Unique_Suggestion_ResponseDto>> GetKr_Unique_SuggestionByUser(Kr_Unique_Suggestion_FilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<Vid_Unique_Suggestion_ResponseDto>> GetVid_Unique_SuggestionByUser(Vid_Unique_Suggestion_FilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<Vid_Gach_Unique_Suggestion_ResponseDto>> GetVid_Gach_Unique_SuggestionByUser(Vid_Gach_Unique_Suggestion_FilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<Pblsr_Unique_Suggestion_ResponseDto>> GetPblsr_Unique_SuggestionByUser(Pblsr_Unique_Suggestion_FilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<Prksn_Unique_Suggestion_ResponseDto>> GetPrksn_Unique_SuggestionByUser(Prksn_Unique_Suggestion_FilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<GPendingWorkViewResDto>> GetGPendingWorkByUser(GPendingWorkViewFilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<RoutineWorkViewResDto>> GetRoutineWorkByUser(RoutineWorkViewFilterDto dataTableFilterDto, string username);

        public Task<L_Remark_Master_ResDto> GetRemarkDataByUser(bool isRemarkAsMainUser, string username);

        public Task<JsonRepsonse<BookIssueDetailResDto>> GetBookOverdueViewDataByUser(BookIssueFilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<ErrorDetailResDto>> GetErrorDetailsViewData(ErrorDetailFilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<Hp_Internal_Issue_ResDto>> GetHp_Internal_IssueByUser(Hp_Internal_Issue_FilterDto dataTableFilterDto, string username);

        public Task<JsonRepsonse<UserScoreBoardResponseDto>> GetUserScoreBoardFromSP(UserScoreBoardFilterDto dataTableFilterDto, CancellationToken cancellationToken);

        public Task<JsonRepsonse<DailyViewResDto>> GetDailyViewDataByUser(DailyViewFilterDto dataTableFilterDto, string username);

        public Task<DashboardCounts> GetDashboardCountsFromSP(string username, CancellationToken cancellationToken);
    }
}