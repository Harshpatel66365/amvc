﻿using KobaWebApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KobaWebApplication.BusinessLogic.Interface
{
    public interface ILoginOptionBL
    {
        public Task<List<BhandarViewModel>> GetBhandarList(string userInt);
        public Task<List<BhandarGroupViewModel>> LoadBhandarGroupListAsync(string userInitial);
        public Task<List<LanguageViewModel>> GetLanguageList();
        public string GetMessage(string errorCode, int languageId);
    }
}
