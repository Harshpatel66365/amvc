﻿using KobaWebApplication.BusinessLogic.Interface;
using KobaWebApplication.DataAccess.UnitOfWork;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System.Net.Http.Json;
using KobaWebApplication.Dto.Browser;
using Newtonsoft.Json;
using AutoWrapper.Models;
using Microsoft.VisualBasic;
using LinqKit;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using KobaWebApplication.DataEntities.Models;

namespace KobaWebApplication.BusinessLogic.Repositories
{
    public class BrowserBL : IBrowserBL
    {
        private readonly IUnitOfWorkDA _unitOfWorkDA;
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly IConfiguration _configuration;
        private readonly HttpClient _httpClient;
        private readonly string _apiUrl;

        public BrowserBL(IUnitOfWorkDA unitOfWorkDA, IWebHostEnvironment hostingEnvironment, IConfiguration configuration, HttpClient httpClient)
        {
            _unitOfWorkDA = unitOfWorkDA;
            _hostingEnvironment = hostingEnvironment;
            _configuration = configuration;
            _httpClient = httpClient;
            _apiUrl = _configuration.GetSection("ElasticSearch:KobaApiURL").Get<string>()!;
        }

        public async Task<SearchResponseDto?> PerformSearchAsync(SearchRequest request)
        {
            try
            {
                var apiEndpoint = $"{_apiUrl}/Search";  // Assuming your endpoint is "/search"

                var response = await _httpClient.PostAsJsonAsync(apiEndpoint, request);

                if (response.IsSuccessStatusCode)
                {
                    var searchResult = await response.Content.ReadFromJsonAsync<SearchResponseDto>();
                    return searchResult;
                }
                return null;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<SearchCountResponseDto> GetSearchCountsAsync(string searchTerm, bool isExactSearch)
        {
            var response = await _httpClient.GetAsync($"{_apiUrl}/Search/Count/{searchTerm}?IsExactSearch={isExactSearch}");

            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<ApiResponse>(json);
                return JsonConvert.DeserializeObject<SearchCountResponseDto>(result.Result.ToString());
            }

            return null;
        }

        public async Task<AdvanceFiltersDto> GetAdvanceSearchFilterAsync(SearchRequest request)
        {
            var apiEndpoint = $"{_apiUrl}/Search/GetAdvanceSearchFilters";  // Assuming your endpoint is "/search"

            var response = await _httpClient.PostAsJsonAsync(apiEndpoint, request);

            if (response.IsSuccessStatusCode)
            {
                var searchResult = await response.Content.ReadFromJsonAsync<AdvanceFiltersDto>();
                return searchResult;
            }
            return null;
        }

        public async Task<ApiResponse> IsParakashanAvailableInLibrary(string prksnNo)
        {
            var response = await _httpClient.GetAsync($"{_apiUrl}/Search/Book/IsParakashanAvailableInLibrary?prksnNo={prksnNo}");

            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<ApiResponse>(json);
                return result;
            }
            else
            {
                var json = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<ApiResponse>(json);
                return result;
            }

            return null;
        }

        public async Task<bool> RequestToBook(BookRequestModel request)
        {
            var apiEndpoint = $"{_apiUrl}/Search/Book";  // Assuming your endpoint is "/search"

            var response = await _httpClient.PostAsJsonAsync(apiEndpoint, request);

            if (response.IsSuccessStatusCode)
            {
                var searchResult = await response.Content.ReadFromJsonAsync<bool>();
                return searchResult;
            }
            return false;
        }

    }
}