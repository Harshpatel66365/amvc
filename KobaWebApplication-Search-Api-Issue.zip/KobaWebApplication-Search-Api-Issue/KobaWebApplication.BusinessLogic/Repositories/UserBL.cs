﻿using AutoMapper;
using KobaWebApplication.BusinessLogic.Interface;
using KobaWebApplication.DataAccess.UnitOfWork;
using KobaWebApplication.Dto.User;
using KobaWebApplication.Dto.DataGrid;
using System.Linq.Dynamic.Core;
using KobaWebApplication.Dto.Account;
using KobaWebApplication.Dto.Common;
using KobaWebApplication.Core.Common;

namespace KobaWebApplication.BusinessLogic.Repositories
{
    public class UserBL : IUserBL
    {
        private readonly IUnitOfWorkDA _unitOfWorkDA;
        private readonly IMapper _mapper;

        public UserBL(IUnitOfWorkDA unitOfWorkDA, IMapper mapper)
        {
            _unitOfWorkDA = unitOfWorkDA;
            _mapper = mapper;
        }

        public async Task<List<UserDetailsDto>> GetAllUsers()
        {
            var users = await _unitOfWorkDA.UserDA.GetAllUsers();
            return _mapper.Map<List<UserDetailsDto>>(users).ToList();
        }

        public async Task<UserDetailsDto> GetUsersById(int UserId)
        {
            var users = await _unitOfWorkDA.UserDA.GetUsersById(UserId);
            return _mapper.Map<UserDetailsDto>(users);
        }


        public async Task<JsonRepsonse<UserDetailsDto>> GetUserDataTable(UserFilterDto dataTableFilterDto)
        {
            try
            {
                var resultData = await _unitOfWorkDA.UserDA.GetAllUsers(dataTableFilterDto.WorkingType);

                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        x.Usr_Name.Contains(searchTerm) ||
                        x.Usr_Init.Contains(searchTerm) ||
                        x.Designation.Contains(searchTerm) ||
                        (!string.IsNullOrEmpty(x.Main_Work) && x.Main_Work.ToLower().Contains(searchTerm)) ||
                    x.Permanent_Address.ToLower().Contains(searchTerm));
                }

                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                resultData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                var totalRecords = resultData.Count();

                var paginatedData = resultData
                .Skip(dataTableFilterDto.Start)
                .Take(dataTableFilterDto.PageSize)
                .ToList();

                var usersData = _mapper.Map<List<UserDetailsDto>>(paginatedData);

                return new JsonRepsonse<UserDetailsDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, usersData);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<UserDetailsDto>(dataTableFilterDto.Draw, 0, 0, new List<UserDetailsDto>());
            }

        }
        public async Task<CommonResponse> ChangeUserPassword(ChangePasswordReq passwordReq, int userId)
        {
            var currentUser = await _unitOfWorkDA.UserDA.GetUsersById(userId);
            var commonResponse = new CommonResponse();
            try
            {
                if (currentUser == null)
                {
                    commonResponse.Status = "failed";
                    commonResponse.Message = "User not found.";
                    return commonResponse;
                }
                else if (currentUser.Pwd != MagnusMindsCommon.g_Pwd_Encrypt(passwordReq.OldPassword))
                {
                    commonResponse.Status = "failed";
                    commonResponse.Message = "Old password is incorrect.";
                    return commonResponse;
                }
                else if (currentUser.Pwd == MagnusMindsCommon.g_Pwd_Encrypt(passwordReq.NewPassword))
                {
                    commonResponse.Status = "failed";
                    commonResponse.Message = "New password must be different from the old password.";
                    return commonResponse;
                }
                else
                {
                    currentUser.Pwd = MagnusMindsCommon.g_Pwd_Encrypt(passwordReq.NewPassword);
                    int updated = _unitOfWorkDA.UserDA.ChangeUserPassword(currentUser);
                    if(updated > 0)
                    {
                        commonResponse.Status = "Success";
                        commonResponse.Message = "User Password Updated Successfully.";
                    }
                }
                return commonResponse;
            }
            catch (Exception ex)
            {
                return new CommonResponse();
            }
        }
        public async Task<CommonResponse> UpdateUser(UserDetailsDto user)
        {
            var currentUser = await _unitOfWorkDA.UserDA.GetUsersById(user.Id);
            var commonResponse = new CommonResponse();
            try
            {
                if (currentUser == null)
                {
                    commonResponse.Status = "failed";
                    commonResponse.Message = "User not found.";
                    return commonResponse;
                }
                else
                {
                    currentUser.Permanent_Address = user.Permanent_Address;
                    currentUser.Usr_Name = user.Usr_Name;
                    int updated = _unitOfWorkDA.UserDA.UpdateUser(currentUser);
                    if (updated > 0)
                    {
                        commonResponse.Status = "Success";
                        commonResponse.Message = "User updated successfully !";
                    }
                }
                return commonResponse;
            }
            catch (Exception ex)
            {
                return new CommonResponse();
            }
        }
    }
}