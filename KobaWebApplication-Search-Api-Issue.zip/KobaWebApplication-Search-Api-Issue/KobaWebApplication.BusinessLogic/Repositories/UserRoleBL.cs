﻿using KobaWebApplication.BusinessLogic.Interface;
using KobaWebApplication.DataAccess.UnitOfWork;
using KobaWebApplication.DataEntities.Models;

namespace KobaWebApplication.BusinessLogic.Repositories
{
    public class UserRoleBL : IUserRoleBL
    {
        private readonly IUnitOfWorkDA _unitOfWorkDA;

        public UserRoleBL(IUnitOfWorkDA unitOfWorkDA)
        {
            _unitOfWorkDA = unitOfWorkDA;
        }

        public async Task<IEnumerable<Role>> GetUserRolesAsync(long userId)
        {
            return await _unitOfWorkDA.UserRoleDA.GetUserRolesAsync(userId);
        }

        public async Task AssignRoleToUserAsync(long userId, int roleId)
        {
            await _unitOfWorkDA.UserRoleDA.AssignRoleToUserAsync(userId, roleId);
        }

    }
}