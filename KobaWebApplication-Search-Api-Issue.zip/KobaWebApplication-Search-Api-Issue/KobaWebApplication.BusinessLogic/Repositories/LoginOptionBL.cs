﻿using KobaWebApplication.BusinessLogic.Interface;
using KobaWebApplication.DataAccess.UnitOfWork;
using KobaWebApplication.Models;
using Microsoft.Extensions.Caching.Memory;

namespace KobaWebApplication.BusinessLogic.Repositories
{
    public class LoginOptionBL : ILoginOptionBL
    {
        private readonly IUnitOfWorkDA _unitOfWorkDA;
        private readonly IMemoryCache _cache;

        public LoginOptionBL(IUnitOfWorkDA unitOfWorkDA, IMemoryCache memoryCache)
        {
            _unitOfWorkDA = unitOfWorkDA;
            _cache = memoryCache;
        }

        public async Task<List<BhandarViewModel>> GetBhandarList(string userInt)
        {
            var cacheBhandar = _cache.Get<List<BhandarViewModel>>("bhandar_Cache");
            if (cacheBhandar != null && cacheBhandar.Count > 0)
            {
                return cacheBhandar;
            }
            else
            {
                var lstBhandar = await _unitOfWorkDA.LoginOptionDA.GetBhandarListByUser(userInt);
                _cache.Set<List<BhandarViewModel>>("bhandar_Cache", lstBhandar, DateTime.Now.AddDays(7));
                return lstBhandar;
            }
        }

        public async Task<List<BhandarGroupViewModel>> LoadBhandarGroupListAsync(string userInitial)
        {
            var cacheBhandarGroup = _cache.Get<List<BhandarGroupViewModel>>("bhandarGroup_Cache");
            if (cacheBhandarGroup != null && cacheBhandarGroup.Count > 0)
            {
                return cacheBhandarGroup;
            }
            else
            {
                var bhandarGroups = await _unitOfWorkDA.LoginOptionDA.GetBhandarGroupsAsync(userInitial);
                _cache.Set<List<BhandarGroupViewModel>>("bhandarGroup_Cache", bhandarGroups, DateTime.Now.AddDays(7));
                return bhandarGroups;
            }
        }

        public async Task<List<LanguageViewModel>> GetLanguageList()
        {
            var cacheLanguages = _cache.Get<List<LanguageViewModel>>("language_Cache");
            if (cacheLanguages != null && cacheLanguages.Count > 0)
            {
                return cacheLanguages;
            }
            else
            {
                var languages = await _unitOfWorkDA.LoginOptionDA.GetLanguages();
                _cache.Set<List<LanguageViewModel>>("language_Cache", languages, DateTime.Now.AddDays(7));
                return languages;
            }
        }

        public string GetMessage(string errorCode, int languageId)
        {
            try
            {
                var messages = _unitOfWorkDA.LoginOptionDA.GetMessages(errorCode, languageId);

                return string.Join("\r\n", messages.Select(m => m.Message));
            }
            catch (Exception ex)
            {
                // Handle exception
                return ex.Message;
            }
        }
    }
}