﻿using AutoMapper;
using KobaWebApplication.BusinessLogic.Interface;
using KobaWebApplication.DataAccess.UnitOfWork;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.AdvanceSearch;
using KobaWebApplication.Dto.Browser;
using KobaWebApplication.Dto.DataGrid;
using Newtonsoft.Json;
using System.Text;

namespace KobaWebApplication.BusinessLogic.Repositories
{
    public class HastPratBL : IHastPratBL
    {
        private readonly IUnitOfWorkDA _unitOfWorkDA;
        private readonly IMapper _mapper;

        public HastPratBL(IUnitOfWorkDA unitOfWorkDA, IMapper mapper)
        {
            _unitOfWorkDA = unitOfWorkDA;
            _mapper = mapper;
        }

        public async Task<bool> AddHastPratInfo(AddHastpratInfoRequest_Dto? request)
        {
            _unitOfWorkDA.HastPratDA.AddHastPratInfo(request);
            return true;
        }

        public async Task<List<City_State_Country_View_Dto>> GetCitiesList()
        {
            var G_CityList = await _unitOfWorkDA.HastPratDA.GetCitiesList();
            return _mapper.Map<List<City_State_Country_View_Dto>>(G_CityList).ToList();
        }

        public async Task<List<L_Dasha_Code_Dto>> GetDashaCodeList()
        {
            var dasha_Codes = await _unitOfWorkDA.HastPratDA.GetdashaCodeList();
            return _mapper.Map<List<L_Dasha_Code_Dto>>(dasha_Codes).ToList();
        }

        public async Task<List<L_Purnata_Code_Dto>> GetPurnataCodeList()
        {
            var purnata_codes = await _unitOfWorkDA.HastPratDA.GetPurnataCodeList();
            return _mapper.Map<List<L_Purnata_Code_Dto>>(purnata_codes).ToList();
        }

        public async Task<List<L_Purnata_Remark_Code_Dto>> GetPurnataRemarkCodeList()
        {
            var purnata_codes = await _unitOfWorkDA.HastPratDA.GetLPurnataRemarkCodeList();
            return _mapper.Map<List<L_Purnata_Remark_Code_Dto>>(purnata_codes).ToList();
        }
        public async Task<List<L_Dharma_Code_Dto>> GetDharmaCodeList()
        {
            var dharma_codes = await _unitOfWorkDA.HastPratDA.GetLDharmaCodeList();
            return _mapper.Map<List<L_Dharma_Code_Dto>>(dharma_codes).ToList();
        }

        public async Task<JsonRepsonse<Hp_Inf_View>> GetHpInfoList(Hastprat_Search_Grid_Request_Dto model)
        {
            try
            {
                IEnumerable<Hp_Inf_View> resultData;
                if (!string.IsNullOrEmpty(model.SearchModel))
                {
                    var searchDto = JsonConvert.DeserializeObject<Hastprat_Search_Request_Dto>(model.SearchModel);
                    var query = await _unitOfWorkDA.HastPratDA.GetHaspPratDataList();

                    // Bhandar_code filter
                    if (!string.IsNullOrEmpty(searchDto.AtxtBhandar))
                    {
                        query = query.Where(hp => hp.Bhandar_Code.Contains(searchDto.AtxtBhandar));
                    }

                    // Hp_Nam_filtered AND / OR condition
                    if (!string.IsNullOrEmpty(searchDto.AtxtHpNam))
                    {
                        if (!string.IsNullOrEmpty(searchDto.cmbHpByType) && searchDto.cmbHpByType == "2")
                        {
                            query = query.Where(x => x.Main_Nam.ToLower() == "y");
                        }
                        if (searchDto.ChkHpFilter == true)
                        {
                            searchDto.AtxtHpNam = RemoveWhiteSpace(AntiAnuswar(searchDto.AtxtHpNam));
                            switch (searchDto.cmbHpPosition)
                            {
                                case "1":
                                    query = query.Where(x =>
                                    //!string.IsNullOrEmpty(x.Hp_Nam_filtered) ? 
                                    x.Hp_Nam_filtered.ToLower().Contains(searchDto.AtxtHpNam.ToLower()));
                                    break;
                                case "2":
                                    query = query.Where(x => x.Hp_Nam_filtered.ToLower() == searchDto.AtxtHpNam.ToLower());
                                    break;
                                case "3":
                                    query = query.Where(x => x.Hp_Nam_filtered.ToLower().EndsWith(searchDto.AtxtHpNam.ToLower()));
                                    break;
                                case "4":
                                    query = query.Where(x => x.Hp_Nam_filtered.ToLower().StartsWith(searchDto.AtxtHpNam.ToLower()));
                                    break;
                            }

                            searchDto.AtxtHpNam = GetFilteredNameBuildQuery(searchDto.AtxtHpNam);
                        }
                        else
                        {
                            searchDto.AtxtHpNam = AntiAnuswar(searchDto.AtxtHpNam);
                            switch (searchDto.cmbHpPosition)
                            {
                                case "1":
                                    query = query.Where(x =>
                                    //!string.IsNullOrEmpty(x.Hp_Nam_filtered) ? 
                                    x.Hp_Nam.ToLower().Contains(searchDto.AtxtHpNam.ToLower()));
                                    break;
                                case "2":
                                    query = query.Where(x => x.Hp_Nam.ToLower() == searchDto.AtxtHpNam.ToLower());
                                    break;
                                case "3":
                                    query = query.Where(x => x.Hp_Nam.ToLower().EndsWith(searchDto.AtxtHpNam.ToLower()));
                                    break;
                                case "4":
                                    query = query.Where(x => x.Hp_Nam.ToLower().StartsWith(searchDto.AtxtHpNam.ToLower()));
                                    break;
                            }
                        }
                    }

                    // EXISTS (Hp_Petank_View) subquery with AND / OR condition

                    if (!string.IsNullOrEmpty(searchDto.AtxtPetaAnk))
                    {
                        var petaAnkData = await _unitOfWorkDA.HastPratDA.GetPetaAnkDataList();
                        if (petaAnkData != null)
                        {
                            switch (searchDto.cmbPetaAnkPosition)
                            {
                                case "1":
                                    query = query.Where(hp => petaAnkData
                                         .Any(p => p.Hp_Pet_Key != null
                                              && p.Hp_Nam.Contains(searchDto.AtxtPetaAnk.ToLower())
                                              && p.Bhandar_Code == hp.Bhandar_Code
                                              && p.Hp_No == hp.Hp_No));
                                    break;
                                case "2":
                                    query = query.Where(hp => petaAnkData
                                         .Any(p => p.Hp_Pet_Key != null
                                              && p.Hp_Nam.ToLower() == searchDto.AtxtPetaAnk.ToLower()
                                              && p.Bhandar_Code == hp.Bhandar_Code
                                              && p.Hp_No == hp.Hp_No));
                                    break;

                                case "3":
                                    query = query.Where(hp => petaAnkData
                                         .Any(p => p.Hp_Pet_Key != null
                                             && p.Hp_Nam.ToLower().EndsWith(searchDto.AtxtPetaAnk.ToLower())
                                             && p.Bhandar_Code == hp.Bhandar_Code
                                             && p.Hp_No == hp.Hp_No));
                                    break;

                                case "4":
                                    query = query.Where(hp => petaAnkData
                                          .Any(p => p.Hp_Pet_Key != null
                                                     && p.Hp_Nam.ToLower().StartsWith(searchDto.AtxtPetaAnk.ToLower())
                                                     && p.Bhandar_Code == hp.Bhandar_Code
                                                     && p.Hp_No == hp.Hp_No));
                                    break;
                            }
                        }
                    }

                    // Prat No condition with AND / OR logic
                    if (!string.IsNullOrEmpty(searchDto.AtxtPratNoStart))
                    {
                        switch (searchDto.cmbPratNoCondn)
                        {
                            case "1": // Equal
                                query = query.Where(x => x.Hp_No == searchDto.AtxtPratNoStart);
                                break;
                            case "2": // Not Equal
                                query = query.Where(x => x.Hp_No != searchDto.AtxtPratNoStart);
                                break;
                            case "3": // Greater Than
                                query = query.Where(x => x.Hp_No.CompareTo(searchDto.AtxtPratNoStart) > 0);
                                break;
                            case "4": // Less Than
                                query = query.Where(x => x.Hp_No.CompareTo(searchDto.AtxtPratNoEnd) < 0);
                                break;
                            case "5": // Not Between
                                query = query.Where(x => !(x.Hp_No.CompareTo(searchDto.AtxtPratNoStart) >= 0 &&
                                                           x.Hp_No.CompareTo(searchDto.AtxtPratNoEnd) <= 0));
                                break;
                            default:
                                break;
                        }

                    }

                    if (!string.IsNullOrEmpty(searchDto.AtxtSholk))
                    {
                        var shlokDataList = await _unitOfWorkDA.HastPratDA.GetHpShlokLnkDataList();
                        if (shlokDataList != null)
                        {
                            switch (searchDto.cmbPetaAnkPosition)
                            {
                                case "1":
                                    query = query.Where(hp => shlokDataList
                                         .Any(p => p.Hp_Pet_Key != null
                                              && p.Shlok.Contains(searchDto.AtxtSholk.ToLower())
                                              && p.Bhandar_Code == hp.Bhandar_Code
                                              && p.Hp_No == hp.Hp_No));
                                    break;
                                case "2":
                                    query = query.Where(hp => shlokDataList
                                         .Any(p => p.Hp_Pet_Key != null
                                              && p.Shlok.ToLower() == searchDto.AtxtSholk.ToLower()
                                              && p.Bhandar_Code == hp.Bhandar_Code
                                              && p.Hp_No == hp.Hp_No));
                                    break;

                                case "3":
                                    query = query.Where(hp => shlokDataList
                                         .Any(p => p.Hp_Pet_Key != null
                                             && p.Shlok.ToLower().EndsWith(searchDto.AtxtSholk.ToLower())
                                             && p.Bhandar_Code == hp.Bhandar_Code
                                             && p.Hp_No == hp.Hp_No));
                                    break;

                                case "4":
                                    query = query.Where(hp => shlokDataList
                                          .Any(p => p.Hp_Pet_Key != null
                                                     && p.Shlok.ToLower().StartsWith(searchDto.AtxtSholk.ToLower())
                                                     && p.Bhandar_Code == hp.Bhandar_Code
                                                     && p.Hp_No == hp.Hp_No));
                                    break;
                            }
                        }
                    }
                    // EXISTS (Hp_City_Lnk) subquery with AND / OR condition
                    if (!string.IsNullOrEmpty(searchDto.AtxtSthal))
                    {
                        var cityData = await _unitOfWorkDA.HastPratDA.GetCitiesList();
                        query = searchDto.cmbSthalAndOr == "1" // AND condition
                            ? query.Where(hp => cityData
                                .Any(c => searchDto.AtxtSthal.Contains(c.City_Key)))
                            : query.Where(hp => cityData
                                .Any(c => searchDto.AtxtSthal.Contains(c.City_Key)));
                    }

                    // Direct Filters with AND / OR logic on Dasha, Purnata, and Purnata Remark Codes
                    if (!string.IsNullOrEmpty(searchDto.AtxtDashaCode))
                    {
                        query = !searchDto.chkDashaCodeIsNot
                            ? query.Where(hp => hp.Dasha_Short_Name != searchDto.AtxtDashaCode)
                            : query.Where(hp => hp.Dasha_Short_Name == searchDto.AtxtDashaCode);
                    }

                    if (!string.IsNullOrEmpty(searchDto.AtxtPurnataCode))
                    {
                        query = !searchDto.chkPurnataCodeIsNot
                            ? query.Where(hp => hp.Purnata_short_name != searchDto.AtxtPurnataCode)
                            : query.Where(hp => hp.Purnata_short_name == searchDto.AtxtPurnataCode);
                    }

                    if (!string.IsNullOrEmpty(searchDto.AtxtPRCode))
                    {
                        query = !searchDto.chkPRCodeIsNot
                            ? query.Where(hp => hp.Purnata_Remark_Code != Convert.ToInt32(searchDto.AtxtPRCode))
                            : query.Where(hp => hp.Purnata_Remark_Code == Convert.ToInt32(searchDto.AtxtPRCode));
                    }
                    // Dharma Code with AND / OR logic
                    if (!string.IsNullOrEmpty(searchDto.AtxtDharmaCode))
                    {
                        switch (searchDto.cmbHpDharmaPosition)
                        {
                            case "1":
                                query = query.Where(x =>
                                x.Dharma_Code.ToLower().Contains(searchDto.AtxtDharmaCode.ToLower()));
                                break;
                            case "2":
                                query = query.Where(x => x.Dharma_Code.ToLower() == searchDto.AtxtDharmaCode.ToLower());
                                break;
                            case "3":
                                query = query.Where(x => x.Dharma_Code.ToLower().EndsWith(searchDto.AtxtDharmaCode.ToLower()));
                                break;
                            case "4":
                                query = query.Where(x => x.Dharma_Code.ToLower().StartsWith(searchDto.AtxtDharmaCode.ToLower()));
                                break;
                        }
                    }
                    else if (!string.IsNullOrEmpty(searchDto.cmbDharmaCodeEqualTxt))
                    {
                        if (searchDto.chkHpDharmaCodeIsNot)
                        {
                            query = query.Where(x => x.Dharma_Code.ToLower() == searchDto.cmbDharmaCodeEqualTxt.ToLower());
                        }
                        else
                        {
                            query = query.Where(x => x.Dharma_Code.ToLower() != searchDto.cmbDharmaCodeEqualTxt.ToLower() && !string.IsNullOrEmpty(x.Dharma_Code));
                        }
                    }


                    if (!string.IsNullOrEmpty(searchDto.AtxtTotPetaAnkStart))
                    {
                        switch (searchDto.cmbTotPetaAnkOperator)
                        {
                            case "1": // Equal
                                query = query.Where(x => Convert.ToInt32(x.Hp_Tot_Pet) == Convert.ToInt32(searchDto.AtxtTotPetaAnkStart));
                                break;
                            case "2": // Not Equal
                                query = query.Where(x => Convert.ToInt32(x.Hp_Tot_Pet) != Convert.ToInt32(searchDto.AtxtTotPetaAnkStart));
                                break;
                            case "3": // Greater Than
                                query = query.Where(x => Convert.ToInt32(x.Hp_Tot_Pet).CompareTo(Convert.ToInt32(searchDto.AtxtTotPetaAnkStart)) > 0);
                                break;
                            case "4": // Less Than
                                query = query.Where(x => Convert.ToInt32(x.Hp_Tot_Pet).CompareTo(Convert.ToInt32(searchDto.AtxtTotPetaAnkEnd)) < 0);
                                break;
                            case "5": // Is Null
                                query = query.Where(x => x.Hp_Tot_Pet == null);
                                break;
                            default:
                                break;
                        }
                    }

                    // Apply Ordering
                    query = query.OrderBy(hp => hp.Bhandar_Code)
                                 .ThenBy(hp => hp.Hp_No);
                    resultData = query;
                }
                else
                {
                    resultData = await _unitOfWorkDA.HastPratDA.GetHaspPratDataList();
                }
                if (resultData == null)
                {
                    return new JsonRepsonse<Hp_Inf_View>(model.Draw, 0, 0, new List<Hp_Inf_View>());
                }
                // Apply sorting
                var sortBy = model.MapOrderBy(model.Order[0].column);
                var sortOrder = model.Order[0].dir;
                //var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                // Total record count before pagination
                var totalRecords = resultData.Count();

                var paginatedData = resultData
                    .Skip(model.Start)
                    .Take(model.PageSize)
                    .ToList();
                var hp_info_data = _mapper.Map<List<Hp_Inf_View>>(paginatedData);

                return new JsonRepsonse<Hp_Inf_View>(model.Draw, totalRecords, totalRecords, hp_info_data);
            }
            catch (Exception e)
            {
                return null;
            }
        }

        public async Task<string> BuildHastpratSearchQuery(Hastprat_Search_Request_Dto model)
        {
            int vI = 0;
            string vStr = null;
            string vKrCondition = "";
            string vVidCondition = "";
            string vVCond = null;
            string vKrCond = "";
            string vExistsCond = "";
            string vHpKrLnkCond = ""; //added by keyur 28022014
            string vPetankCond = "";
            string vQry = "";
            string vCondition = null;
            //ConditionControls vConditionControls;
            const string cHpView = "Hp_Inf_View";

            vKrCondition = " EXISTS ( " +
                   " SELECT Bhandar_Code, Hp_No FROM Hp_Kr_Lnk WHERE Kr_Key IN ( " +
                   " SELECT Kr_Key FROM Kruti_Information WHERE ";
            vVidCondition = " EXISTS ( " + " SELECT Bhandar_Code, Hp_No FROM Hp_Vid_Lnk WHERE Vid_No IN ( " + " SELECT Vid_No FROM Vid_Dada_GuruData_View WHERE ";

            //vExistsCond = " AND UPPER(HPV.Bhandar_Code) = UPPER(Bhandar_Code) AND UPPER(HPV.Hp_No) = UPPER(Hp_No) ) "
            vExistsCond = " AND HPV.Bhandar_Code = Bhandar_Code AND HPV.Hp_No = Hp_No) ";

            vQry = "SELECT * FROM " + cHpView + " AS HPV WHERE ";
            vCondition = null;
            vHpKrLnkCond = null;
            vPetankCond = null;


            return vQry;
        }

        public async Task<IQueryable<Hp_Inf_View>> GetFilteredHpInfViewAsync(Hastprat_Search_Request_Dto searchDto)
        {
            var query = await _unitOfWorkDA.HastPratDA.GetHaspPratDataList();

            // Bhandar_code filter
            if (!string.IsNullOrEmpty(searchDto.AtxtBhandar))
            {
                query = query.Where(hp => hp.Bhandar_Code.Contains(searchDto.AtxtBhandar));
            }

            // Hp_Nam_filtered AND / OR condition
            if (!string.IsNullOrEmpty(searchDto.AtxtHpNam))
            {
                if (searchDto.cmbHpAndOr == "1") // AND condition
                {
                    query = query.Where(hp => hp.Hp_Nam.StartsWith(searchDto.AtxtHpNam));
                }
                else if (searchDto.cmbHpAndOr == "2") // OR condition
                {
                    query = query.Where(hp => hp.Hp_Nam.StartsWith(searchDto.AtxtHpNam) || hp.Hp_Nam.Contains(searchDto.AtxtHpNam));
                }
            }

            // EXISTS (Hp_Petank_View) subquery with AND / OR condition
            if (!string.IsNullOrEmpty(searchDto.AtxtPetaAnk))
            {
                var petaAnkData = await _unitOfWorkDA.HastPratDA.GetPetaAnkDataList();
                if (petaAnkData != null)
                {
                    query = searchDto.cmbPetaAnkAndOr == "1" // AND condition
                        ? query.Where(hp => petaAnkData
                            .Any(p => p.Hp_Pet_Key != null
                                      && p.Hp_Nam.StartsWith(searchDto.AtxtPetaAnk)
                                      && p.Bhandar_Code == hp.Bhandar_Code
                                      && p.Hp_No == hp.Hp_No))
                        : query.Where(hp => petaAnkData
                            .Any(p => p.Hp_Pet_Key != null
                                      && p.Hp_Nam.Contains(searchDto.AtxtPetaAnk)
                                      && p.Bhandar_Code == hp.Bhandar_Code
                                      && p.Hp_No == hp.Hp_No));
                }
            }

            // Prat No condition with AND / OR logic
            if (!string.IsNullOrEmpty(searchDto.AtxtPratNoStart))
            {
                query = searchDto.cmbPratNoAndOr == "1" // AND condition
                    ? query.Where(hp => string.Compare(hp.Hp_No, searchDto.AtxtPratNoStart) > 0)
                    : query.Where(hp => string.Compare(hp.Hp_No, searchDto.AtxtPratNoStart) > 0 || string.Compare(hp.Hp_No, searchDto.AtxtPratNoEnd) > 0);
            }

            // EXISTS (Hp_Shlok_Lnk_View) subquery with AND / OR condition
            if (!string.IsNullOrEmpty(searchDto.AtxtSholk))
            {
                var shlokDataList = await _unitOfWorkDA.HastPratDA.GetHpShlokLnkDataList();
                query = searchDto.cmbSholkAndOr == "1" // AND condition
                    ? query.Where(hp => shlokDataList
                        .Any(s => s.Shlok.StartsWith(searchDto.AtxtSholk)
                                  && s.Bhandar_Code == hp.Bhandar_Code
                                  && s.Hp_No == hp.Hp_No))
                    : query.Where(hp => shlokDataList
                        .Any(s => s.Shlok.Contains(searchDto.AtxtSholk)
                                  && s.Bhandar_Code == hp.Bhandar_Code
                                  && s.Hp_No == hp.Hp_No));
            }

            // EXISTS (Hp_City_Lnk) subquery with AND / OR condition
            if (!string.IsNullOrEmpty(searchDto.AtxtSthal))
            {
                var cityData = await _unitOfWorkDA.HastPratDA.GetCitiesList();
                query = searchDto.cmbSthalAndOr == "1" // AND condition
                    ? query.Where(hp => cityData
                        .Any(c => searchDto.AtxtSthal.Contains(c.City_Key)))
                    : query.Where(hp => cityData
                        .Any(c => searchDto.AtxtSthal.Contains(c.City_Key)));
            }

            // Direct Filters with AND / OR logic on Dasha, Purnata, and Purnata Remark Codes
            if (!string.IsNullOrEmpty(searchDto.AtxtDashaCode))
            {
                query = searchDto.cmbDashaCodeAndOr == "1"
                    ? query.Where(hp => hp.Dasha_Short_Name == searchDto.AtxtDashaCode)
                    : query.Where(hp => hp.Dasha_Short_Name == searchDto.AtxtDashaCode || hp.Dasha_Short_Name.Contains(searchDto.AtxtDashaCode));
            }

            if (!string.IsNullOrEmpty(searchDto.AtxtPurnataCode))
            {
                query = searchDto.cmbPurnataCodeAndOr == "1"
                    ? query.Where(hp => hp.Purnata_short_name == searchDto.AtxtPurnataCode)
                    : query.Where(hp => hp.Purnata_short_name == searchDto.AtxtPurnataCode || hp.Purnata_short_name.Contains(searchDto.AtxtPurnataCode));
            }

            if (!string.IsNullOrEmpty(searchDto.AtxtPRCode))
            {
                query = searchDto.cmbPRCodeAndOr == "1"
                    ? query.Where(hp => hp.Purnata_Remark_Code == Convert.ToInt32(searchDto.AtxtPRCode))
                    : query.Where(hp => hp.Purnata_Remark_Code == Convert.ToInt32(searchDto.AtxtPRCode) || Convert.ToString(hp.Purnata_Remark_Code).Contains(searchDto.AtxtPRCode));

                // Dharma Code with AND / OR logic
                if (!string.IsNullOrEmpty(searchDto.cmbHpByType))
                {
                    query = searchDto.cmbHpAndOr == "1"
                        ? query.Where(hp => hp.Dharma_Code.StartsWith(searchDto.cmbHpByType))
                        : query.Where(hp => hp.Dharma_Code.Contains(searchDto.cmbHpByType));
                }

                // Total Peta Ank with integer filtering logic
                if (!string.IsNullOrEmpty(searchDto.AtxtTotPetaAnkStart))
                {
                    if (int.TryParse(searchDto.AtxtTotPetaAnkStart, out int totPetaAnk))
                    {
                        query = searchDto.cmbTotPetaAnkAndOr == "1"
                            ? query.Where(hp => Convert.ToInt32(hp.Hp_Tot_Pet) == totPetaAnk)
                            : query.Where(hp => Convert.ToInt32(hp.Hp_Tot_Pet) == totPetaAnk || Convert.ToInt32(hp.Hp_Tot_Pet) > totPetaAnk);
                    }
                }

                // Apply Ordering
                query = query.OrderBy(hp => hp.Bhandar_Code)
                             .ThenBy(hp => hp.Hp_No);

                return query;
            }

            return query;
        }

        #region Private methods
        private static string GetFilteredNameBuildQuery(string vStringData)
        {
            char[] vFilterCharacter = new char[] { '-', ' ', ':', ';', '[', ']', '{', '}', '<', '>', '~', '*', '|', '.', '%', '$', '#', '@', ',', '?', '`', '&', '^', '।', '॥', '०', '॰', '\u0022' };
            int vintLength = vStringData.IndexOfAny(vFilterCharacter);

            // Remove each unwanted character found in the input string
            while (vintLength >= 0)
            {
                vStringData = vStringData.Remove(vintLength, 1);
                vintLength = vStringData.IndexOfAny(vFilterCharacter);
            }

            // Check for specific conditions with parentheses and conditional operators
            if (vStringData.Contains("("))
            {
                char[] vConditionalOperator = { '+', '/', '\'' };
                char[] vSBraces = { '(' };
                char[] vEBraces = { ')' };
                vintLength = vStringData.IndexOfAny(vSBraces);

                while (vintLength > 0)
                {
                    if (Convert.ToBoolean(vStringData.Substring(vintLength - 1, 1).IndexOfAny(vConditionalOperator)))
                    {
                        vStringData = vStringData.Remove(vintLength, 1);
                        vintLength = vStringData.LastIndexOfAny(vEBraces);
                        vStringData = vStringData.Remove(vintLength, 1);
                        vintLength = vStringData.LastIndexOfAny(vSBraces);
                    }
                    else
                    {
                        vintLength = vStringData.LastIndexOfAny(vEBraces);
                        if (vStringData.Length - 1 > vintLength)
                        {
                            if (Convert.ToBoolean(vStringData.Substring(vintLength + 1, 1).IndexOfAny(vConditionalOperator)))
                            {
                                vStringData = vStringData.Remove(vintLength, 1);
                                vintLength = vStringData.IndexOfAny(vSBraces);
                                vStringData = vStringData.Remove(vintLength, 1);
                                vintLength = vStringData.IndexOfAny(vSBraces);
                            }
                            else
                            {
                                return vStringData;
                            }
                        }
                        else
                        {
                            return vStringData;
                        }
                    }
                }
            }
            return vStringData;
        }

        private static string AntiAnuswar(string strdata)
        {
            string strNoAnuswar = "";
            strNoAnuswar = strdata;
            strNoAnuswar = strNoAnuswar.Replace("ङ्क", "ंक");
            strNoAnuswar = strNoAnuswar.Replace("ङ्ख", "ंख");
            strNoAnuswar = strNoAnuswar.Replace("ङ्ग", "ंग");
            strNoAnuswar = strNoAnuswar.Replace("ङ्घ", "ंघ");
            strNoAnuswar = strNoAnuswar.Replace("ञ्च", "ंच");
            strNoAnuswar = strNoAnuswar.Replace("ञ्छ", "ंछ");
            strNoAnuswar = strNoAnuswar.Replace("ञ्ज", "ंज");
            strNoAnuswar = strNoAnuswar.Replace("ञ्झ", "ंझ");
            strNoAnuswar = strNoAnuswar.Replace("ण्ट", "ंट");
            strNoAnuswar = strNoAnuswar.Replace("ण्ठ", "ंठ");
            strNoAnuswar = strNoAnuswar.Replace("ण्ड", "ंड");
            strNoAnuswar = strNoAnuswar.Replace("ण्ढ", "ंढ");
            strNoAnuswar = strNoAnuswar.Replace("न्त", "ंत");
            strNoAnuswar = strNoAnuswar.Replace("न्थ", "ंथ");
            strNoAnuswar = strNoAnuswar.Replace("न्द", "ंद");
            strNoAnuswar = strNoAnuswar.Replace("न्ग", "ंग");
            strNoAnuswar = strNoAnuswar.Replace("न्ध", "ंध");
            strNoAnuswar = strNoAnuswar.Replace("म्प", "ंप");
            strNoAnuswar = strNoAnuswar.Replace("म्फ", "ंफ");
            strNoAnuswar = strNoAnuswar.Replace("म्ब", "ंब");
            strNoAnuswar = strNoAnuswar.Replace("म्भ", "ंभ");
            return strNoAnuswar;
        }
        private static string RemoveWhiteSpace(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return string.Empty;

            StringBuilder result = new StringBuilder();

            foreach (char c in name)
            {
                if (!char.IsWhiteSpace(c))
                {
                    result.Append(c);
                }
            }

            return result.ToString();
        }
        #endregion
    }
}