﻿using AutoMapper;
using KobaWebApplication.BusinessLogic.Interface;
using KobaWebApplication.Core.Common;
using KobaWebApplication.DataAccess.UnitOfWork;
using KobaWebApplication.DataEntities.Result;
using KobaWebApplication.Dto.DataGrid;
using KobaWebApplication.Dto.Home;
using KobaWebApplication.Dto.Home.BookOverDueDto;
using KobaWebApplication.Dto.Home.EditRequestsDto;
using KobaWebApplication.Dto.Home.Hp_Internal_Issue;
using KobaWebApplication.Dto.Home.L_DailyViewDto;
using KobaWebApplication.Dto.Home.PendingTaskDto;
using KobaWebApplication.Dto.Home.RemarkManagementDto;
using KobaWebApplication.Dto.Home.RoutinWorkDto;
using KobaWebApplication.Dto.Home.Unique_SuggestionDto;
using KobaWebApplication.Dto.Home.User_Error_Suggestion;
using KobaWebApplication.Dto.Home.User_Score_Board;
using System.Linq.Dynamic.Core;

namespace KobaWebApplication.BusinessLogic.Repositories
{
    public class HomeBL : IHomeBL
    {
        private readonly IUnitOfWorkDA _unitOfWorkDA;
        private readonly IMapper _mapper;

        public HomeBL(IUnitOfWorkDA unitOfWorkDA, IMapper mapper)
        {
            _unitOfWorkDA = unitOfWorkDA;
            _mapper = mapper;
        }

        #region Main Home Page Method

        public async Task<JsonRepsonse<L_Gmandir_Messages_ResDto>> GetHomePageData(L_Gmandir_Edit_Request_FilterDto dataTableFilterDto)
        {
            try
            {
                var resultData = await _unitOfWorkDA.HomeDA.GetHomePageData();
                if (resultData == null)
                {
                    return new JsonRepsonse<L_Gmandir_Messages_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<L_Gmandir_Messages_ResDto>());
                }

                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                var totalRecords = orderedData.Count();

                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                var home_Page_Data = _mapper.Map<List<L_Gmandir_Messages_ResDto>>(paginatedData);

                return new JsonRepsonse<L_Gmandir_Messages_ResDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, home_Page_Data);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<L_Gmandir_Messages_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<L_Gmandir_Messages_ResDto>());
            }
        }

        #endregion Main Home Page Method

        #region Edit Request Methods

        public async Task<JsonRepsonse<Kr_Edit_Request_ResDto>> GetKr_Edit_ReqByUser(Kr_Edit_Request_FilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<Kr_Edit_Request_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<Kr_Edit_Request_ResDto>());
                }

                var resultData = await _unitOfWorkDA.HomeDA.GetKr_Edit_ReqByUser(username, dataTableFilterDto.IsEditReqToYou);
                if (resultData == null)
                {
                    return new JsonRepsonse<Kr_Edit_Request_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<Kr_Edit_Request_ResDto>());
                }

                // Apply search if search term is provided
                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        (!string.IsNullOrEmpty(x.Msg_No.ToString()) && x.Msg_No.ToString().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Sender_Init) && x.Sender_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Kr_key) && x.Kr_key.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Sender_Msg) && x.Sender_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_init) && x.Receiver_init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_Reply) && x.Receiver_Reply.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Urgency_Type_Short_name) && x.Urgency_Type_Short_name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Status_Short_Name) && x.Status_Short_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Add_Init) && x.Add_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Updt_Init) && x.Updt_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Last_Edtr) && x.Last_Edtr.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Certifier) && x.Certifier.ToLower().Contains(searchTerm))
                    );
                }

                // Apply sorting
                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                // Total record count before pagination
                var totalRecords = orderedData.Count();

                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                // Map to DTO and queryable
                var kr_Edit_Data = _mapper.Map<List<Kr_Edit_Request_ResDto>>(paginatedData);

                return new JsonRepsonse<Kr_Edit_Request_ResDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, kr_Edit_Data);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<Kr_Edit_Request_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<Kr_Edit_Request_ResDto>());
            }
        }

        public async Task<JsonRepsonse<Hp_Edit_ResponseDto>> GetHp_Edit_ReqByUser(Hp_Edit_Request_FilterDto dataTableFilterDto, string username)
        {
            try
            {
                // Validate username
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<Hp_Edit_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Hp_Edit_ResponseDto>());
                }

                // Fetch data
                var resultData = await _unitOfWorkDA.HomeDA.GetHp_Edit_ReqByUser(username, dataTableFilterDto.IsEditReqToYou);
                if (resultData == null)
                {
                    return new JsonRepsonse<Hp_Edit_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Hp_Edit_ResponseDto>());
                }

                // Apply search if search term is provided
                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        (!string.IsNullOrEmpty(x.Msg_No.ToString()) && x.Msg_No.ToString().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Bhandar_Code) && x.Bhandar_Code.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Hp_No) && x.Hp_No.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Hp_pet_key) && x.Hp_pet_key.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Sender_Init) && x.Sender_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Sender_Msg) && x.Sender_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_init) && x.Receiver_init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_Reply) && x.Receiver_Reply.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Urgency_Type_Short_name) && x.Urgency_Type_Short_name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Status_Short_name) && x.Status_Short_name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Add_Init) && x.Add_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Updt_Init) && x.Updt_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Last_Edtr) && x.Last_Edtr.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Certifier) && x.Certifier.ToLower().Contains(searchTerm))
                    );
                }

                // Apply sorting
                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                // Total record count before pagination
                var totalRecords = orderedData.Count();

                // Apply pagination
                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                // Map to DTO
                var hp_Edit_Data = _mapper.Map<List<Hp_Edit_ResponseDto>>(paginatedData);

                return new JsonRepsonse<Hp_Edit_ResponseDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, hp_Edit_Data);
            }
            catch (Exception ex)
            {
                // Log exception if needed and return empty response
                return new JsonRepsonse<Hp_Edit_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Hp_Edit_ResponseDto>());
            }
        }

        public async Task<JsonRepsonse<Vid_Edit_ResponseDto>> GetVid_Edit_ReqByUser(Vid_Edit_Request_FilterDto dataTableFilterDto, string username)
        {
            try
            {
                // Validate username
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<Vid_Edit_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Vid_Edit_ResponseDto>());
                }

                // Fetch data
                var resultData = await _unitOfWorkDA.HomeDA.GetVid_Edit_ReqByUser(username, dataTableFilterDto.IsEditReqToYou);
                if (resultData == null)
                {
                    return new JsonRepsonse<Vid_Edit_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Vid_Edit_ResponseDto>());
                }

                // Apply search if search term is provided
                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        (!string.IsNullOrEmpty(x.Msg_No.ToString()) && x.Msg_No.ToString().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Vid_no) && x.Vid_no.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Sender_Init) && x.Sender_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Sender_Msg) && x.Sender_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_init) && x.Receiver_init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_Reply) && x.Receiver_Reply.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Urgency_Type_Short_name) && x.Urgency_Type_Short_name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Status_Short_name) && x.Status_Short_name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Add_Init) && x.Add_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Updt_Init) && x.Updt_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Last_Edtr) && x.Last_Edtr.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Certifier) && x.Certifier.ToLower().Contains(searchTerm))
                    );
                }

                // Apply sorting
                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                // Total record count before pagination
                var totalRecords = orderedData.Count();

                // Apply pagination
                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                // Map to DTO
                var vid_Edit_Data = _mapper.Map<List<Vid_Edit_ResponseDto>>(paginatedData);

                return new JsonRepsonse<Vid_Edit_ResponseDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, vid_Edit_Data);
            }
            catch (Exception ex)
            {
                // Log exception if needed and return empty response
                return new JsonRepsonse<Vid_Edit_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Vid_Edit_ResponseDto>());
            }
        }

        public async Task<JsonRepsonse<Vid_Gach_Edit_Req_ResponseDto>> GetVid_Gach_Edit_ReqByUser(Vid_Gach_Edit_Request_FilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<Vid_Gach_Edit_Req_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Vid_Gach_Edit_Req_ResponseDto>());
                }

                var resultData = await _unitOfWorkDA.HomeDA.GetVid_Gach_Edit_ReqByUser(username, dataTableFilterDto.IsEditReqToYou);
                if (resultData == null)
                {
                    return new JsonRepsonse<Vid_Gach_Edit_Req_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Vid_Gach_Edit_Req_ResponseDto>());
                }

                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        (!string.IsNullOrEmpty(x.Msg_No.ToString()) && x.Msg_No.ToString().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Gach_Key) && x.Gach_Key.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Sender_Init) && x.Sender_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Sender_Msg) && x.Sender_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_Init) && x.Receiver_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_Reply) && x.Receiver_Reply.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Urgency_Type_Short_name) && x.Urgency_Type_Short_name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Status_Short_Name) && x.Status_Short_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Add_Init) && x.Add_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Updt_Init) && x.Updt_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Last_Edtr) && x.Last_Edtr.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Certifier) && x.Certifier.ToLower().Contains(searchTerm))
                    );
                }

                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                var totalRecords = orderedData.Count();

                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                var vid_Gach_Edit_Data = _mapper.Map<List<Vid_Gach_Edit_Req_ResponseDto>>(paginatedData);

                return new JsonRepsonse<Vid_Gach_Edit_Req_ResponseDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, vid_Gach_Edit_Data);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<Vid_Gach_Edit_Req_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Vid_Gach_Edit_Req_ResponseDto>());
            }
        }

        public async Task<JsonRepsonse<Mag_Edit_Req_ResponseDto>> GetMag_Edit_ReqByUser(Mag_Edit_Request_FilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<Mag_Edit_Req_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Mag_Edit_Req_ResponseDto>());
                }

                var resultData = await _unitOfWorkDA.HomeDA.GetMag_Edit_ReqByUser(username, dataTableFilterDto.IsEditReqToYou);
                if (resultData == null)
                {
                    return new JsonRepsonse<Mag_Edit_Req_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Mag_Edit_Req_ResponseDto>());
                }

                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        (!string.IsNullOrEmpty(x.Msg_No.ToString()) && x.Msg_No.ToString().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Mag_No) && x.Mag_No.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Ank_No) && x.Ank_No.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Ank_Pet_Key) && x.Ank_Pet_Key.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Sender_Init) && x.Sender_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Sender_Msg) && x.Sender_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_init) && x.Receiver_init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_Reply) && x.Receiver_Reply.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Urgency_Type_Short_name) && x.Urgency_Type_Short_name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Status_Short_Name) && x.Status_Short_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Add_Init) && x.Add_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Updt_Init) && x.Updt_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Last_Edtr) && x.Last_Edtr.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Certifier) && x.Certifier.ToLower().Contains(searchTerm))
                    );
                }

                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                var totalRecords = orderedData.Count();

                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                var mag_Edit_Data = _mapper.Map<List<Mag_Edit_Req_ResponseDto>>(paginatedData);

                return new JsonRepsonse<Mag_Edit_Req_ResponseDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, mag_Edit_Data);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<Mag_Edit_Req_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Mag_Edit_Req_ResponseDto>());
            }
        }

        public async Task<JsonRepsonse<Prksn_Edit_Request_ResDto>> GetPrksn_Edit_ReqByUser(Prksn_Edit_Request_FilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<Prksn_Edit_Request_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<Prksn_Edit_Request_ResDto>());
                }

                var resultData = await _unitOfWorkDA.HomeDA.GetPrksn_Edit_ReqByUser(username, dataTableFilterDto.IsEditReqToYou);
                if (resultData == null)
                {
                    return new JsonRepsonse<Prksn_Edit_Request_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<Prksn_Edit_Request_ResDto>());
                }

                // Apply search if search term is provided
                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        (!string.IsNullOrEmpty(x.Msg_No.ToString()) && x.Msg_No.ToString().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Sender_Init) && x.Sender_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Prksn_key) && x.Prksn_key.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Sender_Msg) && x.Sender_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_init) && x.Receiver_init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_Reply) && x.Receiver_Reply.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Urgency_Type_Short_name) && x.Urgency_Type_Short_name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Status_Short_name) && x.Status_Short_name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Add_Init) && x.Add_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Updt_Init) && x.Updt_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Last_Edtr) && x.Last_Edtr.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Certifier) && x.Certifier.ToLower().Contains(searchTerm))
                    );
                }

                // Apply sorting
                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                // Total record count before pagination
                var totalRecords = orderedData.Count();

                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                var prksn_Edit_Data = _mapper.Map<List<Prksn_Edit_Request_ResDto>>(paginatedData);

                return new JsonRepsonse<Prksn_Edit_Request_ResDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, prksn_Edit_Data);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<Prksn_Edit_Request_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<Prksn_Edit_Request_ResDto>());
            }
        }

        public async Task<JsonRepsonse<Pblsr_Edit_Request_ResDto>> GetPblsr_Edit_ReqByUser(Pblsr_Edit_Request_FilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<Pblsr_Edit_Request_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<Pblsr_Edit_Request_ResDto>());
                }

                var resultData = await _unitOfWorkDA.HomeDA.GetPblsr_Edit_ReqByUser(username, dataTableFilterDto.IsEditReqToYou);
                if (resultData == null)
                {
                    return new JsonRepsonse<Pblsr_Edit_Request_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<Pblsr_Edit_Request_ResDto>());
                }

                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        (!string.IsNullOrEmpty(x.Msg_No.ToString()) && x.Msg_No.ToString().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Sender_Init) && x.Sender_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Pblsr_Key) && x.Pblsr_Key.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Sender_Msg) && x.Sender_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_init) && x.Receiver_init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_Reply) && x.Receiver_Reply.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Urgency_Type_Short_name) && x.Urgency_Type_Short_name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Status_Short_Name) && x.Status_Short_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Add_Init) && x.Add_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Updt_Init) && x.Updt_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Last_Edtr) && x.Last_Edtr.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Certifier) && x.Certifier.ToLower().Contains(searchTerm))
                    );
                }

                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                var totalRecords = orderedData.Count();

                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                var pblsr_Edit_Data = _mapper.Map<List<Pblsr_Edit_Request_ResDto>>(paginatedData);

                return new JsonRepsonse<Pblsr_Edit_Request_ResDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, pblsr_Edit_Data);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<Pblsr_Edit_Request_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<Pblsr_Edit_Request_ResDto>());
            }
        }

        public async Task<JsonRepsonse<Mag_Bind_Edit_Request_ResDto>> GetMag_Bind_Edit_ReqByUser(Mag_Bind_Edit_Request_FilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<Mag_Bind_Edit_Request_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<Mag_Bind_Edit_Request_ResDto>());
                }

                var resultData = await _unitOfWorkDA.HomeDA.GetMag_EditBind_ReqByUser(username, dataTableFilterDto.IsEditReqToYou);
                if (resultData == null)
                {
                    return new JsonRepsonse<Mag_Bind_Edit_Request_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<Mag_Bind_Edit_Request_ResDto>());
                }

                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        (!string.IsNullOrEmpty(x.Msg_No.ToString()) && x.Msg_No.ToString().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Sender_Init) && x.Sender_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Bhandar_Code) && x.Bhandar_Code.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Bind_No) && x.Bind_No.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Ank_Copy_Accession_No) && x.Ank_Copy_Accession_No.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Sender_Msg) && x.Sender_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_init) && x.Receiver_init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_Reply) && x.Receiver_Reply.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Urgency_Type_Short_name) && x.Urgency_Type_Short_name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Status_Short_Name) && x.Status_Short_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Add_Init) && x.Add_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Updt_Init) && x.Updt_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Last_Edtr) && x.Last_Edtr.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Certifier) && x.Certifier.ToLower().Contains(searchTerm))
                    );
                }

                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                var totalRecords = orderedData.Count();

                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                var mag_Bind_Edit_Data = _mapper.Map<List<Mag_Bind_Edit_Request_ResDto>>(paginatedData);

                return new JsonRepsonse<Mag_Bind_Edit_Request_ResDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, mag_Bind_Edit_Data);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<Mag_Bind_Edit_Request_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<Mag_Bind_Edit_Request_ResDto>());
            }
        }

        #endregion Edit Request Methods

        #region Unique Suggestions Methods

        public async Task<JsonRepsonse<Kr_Unique_Suggestion_ResponseDto>> GetKr_Unique_SuggestionByUser(Kr_Unique_Suggestion_FilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<Kr_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Kr_Unique_Suggestion_ResponseDto>());
                }

                var resultData = await _unitOfWorkDA.HomeDA.GetKr_Unique_SuggestionsByUser(username, dataTableFilterDto.IsSuggestionToYou);
                if (resultData == null)
                {
                    return new JsonRepsonse<Kr_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Kr_Unique_Suggestion_ResponseDto>());
                }

                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        (!string.IsNullOrEmpty(x.Unique_Suggestion_Id.ToString()) && x.Unique_Suggestion_Id.ToString().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Destination_Kr_Key) && x.Destination_Kr_Key.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Source_Kr_Key) && x.Source_Kr_Key.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Unique_Type_Short_Name) && x.Unique_Type_Short_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Send_Msg) && x.Send_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_Init) && x.Receiver_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Reply_Msg) && x.Reply_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Status_Short_Name) && x.Status_Short_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Remark) && x.Remark.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Add_Init) && x.Add_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Updt_Init) && x.Updt_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Last_Edtr) && x.Last_Edtr.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Certifier) && x.Certifier.ToLower().Contains(searchTerm))
                    );
                }

                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                var totalRecords = orderedData.Count();

                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                var suggestions = _mapper.Map<List<Kr_Unique_Suggestion_ResponseDto>>(paginatedData);

                return new JsonRepsonse<Kr_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, suggestions);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<Kr_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Kr_Unique_Suggestion_ResponseDto>());
            }
        }

        public async Task<JsonRepsonse<Vid_Unique_Suggestion_ResponseDto>> GetVid_Unique_SuggestionByUser(Vid_Unique_Suggestion_FilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<Vid_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Vid_Unique_Suggestion_ResponseDto>());
                }

                var resultData = await _unitOfWorkDA.HomeDA.GetVid_Unique_SuggestionsByUser(username, dataTableFilterDto.IsSuggestionToYou);
                if (resultData == null)
                {
                    return new JsonRepsonse<Vid_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Vid_Unique_Suggestion_ResponseDto>());
                }

                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        x.Unique_Suggestion_Id.ToString().Contains(searchTerm) ||
                        x.Destination_vid_No.ToLower().Contains(searchTerm) ||
                        x.Source_vid_No.ToLower().Contains(searchTerm) ||
                        x.Unique_Type_Short_Name.ToLower().Contains(searchTerm) ||
                        x.Send_Msg.ToLower().Contains(searchTerm) ||
                        x.Receiver_Init.ToLower().Contains(searchTerm) ||
                        (x.Reply_Msg != null && x.Reply_Msg.ToLower().Contains(searchTerm)) ||
                        (x.Status_Short_Name != null && x.Status_Short_Name.ToLower().Contains(searchTerm)) ||
                        (x.Remark != null && x.Remark.ToLower().Contains(searchTerm)) ||
                        x.Add_Init.ToLower().Contains(searchTerm) ||
                        (x.Updt_Init != null && x.Updt_Init.ToLower().Contains(searchTerm)) ||
                        (x.Last_Edtr != null && x.Last_Edtr.ToLower().Contains(searchTerm)) ||
                        (x.Certifier != null && x.Certifier.ToLower().Contains(searchTerm))
                    );
                }

                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                var totalRecords = orderedData.Count();

                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                var suggestions = _mapper.Map<List<Vid_Unique_Suggestion_ResponseDto>>(paginatedData);

                return new JsonRepsonse<Vid_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, suggestions);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<Vid_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Vid_Unique_Suggestion_ResponseDto>());
            }
        }

        public async Task<JsonRepsonse<Vid_Gach_Unique_Suggestion_ResponseDto>> GetVid_Gach_Unique_SuggestionByUser(Vid_Gach_Unique_Suggestion_FilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<Vid_Gach_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Vid_Gach_Unique_Suggestion_ResponseDto>());
                }

                var resultData = await _unitOfWorkDA.HomeDA.GetVid_Gach_Unique_SuggestionsByUser(username, dataTableFilterDto.IsSuggestionToYou);
                if (resultData == null)
                {
                    return new JsonRepsonse<Vid_Gach_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Vid_Gach_Unique_Suggestion_ResponseDto>());
                }

                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        x.Unique_Suggestion_Id.ToString().Contains(searchTerm) ||
                        (!string.IsNullOrEmpty(x.Destination_Gach_Key) && x.Destination_Gach_Key.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Source_Gach_Key) && x.Source_Gach_Key.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Unique_Type_Short_Name) && x.Unique_Type_Short_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Send_Msg) && x.Send_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_Init) && x.Receiver_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Reply_Msg) && x.Reply_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Status_Short_Name) && x.Status_Short_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Remark) && x.Remark.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Add_Init) && x.Add_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Updt_Init) && x.Updt_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Last_Edtr) && x.Last_Edtr.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Certifier) && x.Certifier.ToLower().Contains(searchTerm))
                    );
                }

                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                var totalRecords = orderedData.Count();

                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                var suggestions = _mapper.Map<List<Vid_Gach_Unique_Suggestion_ResponseDto>>(paginatedData);

                return new JsonRepsonse<Vid_Gach_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, suggestions);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<Vid_Gach_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Vid_Gach_Unique_Suggestion_ResponseDto>());
            }
        }

        public async Task<JsonRepsonse<Pblsr_Unique_Suggestion_ResponseDto>> GetPblsr_Unique_SuggestionByUser(Pblsr_Unique_Suggestion_FilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<Pblsr_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Pblsr_Unique_Suggestion_ResponseDto>());
                }

                var resultData = await _unitOfWorkDA.HomeDA.GetPblsr_Unique_SuggestionsByUser(username, dataTableFilterDto.IsSuggestionToYou);
                if (resultData == null)
                {
                    return new JsonRepsonse<Pblsr_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Pblsr_Unique_Suggestion_ResponseDto>());
                }

                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        x.Unique_Suggestion_Id.ToString().Contains(searchTerm) ||
                        (!string.IsNullOrEmpty(x.Destination_Pblsr_Key) && x.Destination_Pblsr_Key.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Source_Pblsr_Key) && x.Source_Pblsr_Key.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Unique_Type_Short_Name) && x.Unique_Type_Short_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Send_Msg) && x.Send_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_Init) && x.Receiver_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Reply_Msg) && x.Reply_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Status_Short_Name) && x.Status_Short_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Remark) && x.Remark.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Add_Init) && x.Add_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Updt_Init) && x.Updt_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Last_Edtr) && x.Last_Edtr.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Certifier) && x.Certifier.ToLower().Contains(searchTerm))
                    );
                }

                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                var totalRecords = orderedData.Count();

                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                var suggestions = _mapper.Map<List<Pblsr_Unique_Suggestion_ResponseDto>>(paginatedData);

                return new JsonRepsonse<Pblsr_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, suggestions);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<Pblsr_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Pblsr_Unique_Suggestion_ResponseDto>());
            }
        }

        public async Task<JsonRepsonse<Prksn_Unique_Suggestion_ResponseDto>> GetPrksn_Unique_SuggestionByUser(Prksn_Unique_Suggestion_FilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<Prksn_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Prksn_Unique_Suggestion_ResponseDto>());
                }

                var resultData = await _unitOfWorkDA.HomeDA.GetPrksn_Unique_SuggestionsByUser(username, dataTableFilterDto.IsSuggestionToYou);
                if (resultData == null)
                {
                    return new JsonRepsonse<Prksn_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Prksn_Unique_Suggestion_ResponseDto>());
                }

                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        x.Unique_Suggestion_Id.ToString().Contains(searchTerm) ||
                        (!string.IsNullOrEmpty(x.Destination_Prksn_Key) && x.Destination_Prksn_Key.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Source_Prksn_Key) && x.Source_Prksn_Key.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Unique_Type_Short_Name) && x.Unique_Type_Short_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Send_Msg) && x.Send_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Receiver_Init) && x.Receiver_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Reply_Msg) && x.Reply_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Status_Short_Name) && x.Status_Short_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Remark) && x.Remark.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Add_Init) && x.Add_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Updt_Init) && x.Updt_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Last_Edtr) && x.Last_Edtr.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Certifier) && x.Certifier.ToLower().Contains(searchTerm))
                    );
                }

                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                var totalRecords = orderedData.Count();

                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                var suggestions = _mapper.Map<List<Prksn_Unique_Suggestion_ResponseDto>>(paginatedData);

                return new JsonRepsonse<Prksn_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, suggestions);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<Prksn_Unique_Suggestion_ResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<Prksn_Unique_Suggestion_ResponseDto>());
            }
        }

        #endregion Unique Suggestions Methods

        #region Pending Task Method From View

        public async Task<JsonRepsonse<GPendingWorkViewResDto>> GetGPendingWorkByUser(GPendingWorkViewFilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<GPendingWorkViewResDto>(dataTableFilterDto.Draw, 0, 0, new List<GPendingWorkViewResDto>());
                }

                // Fetch data from the data access method
                var resultData = await _unitOfWorkDA.HomeDA.GetGPendingWorkFromView(username);
                if (resultData == null)
                {
                    return new JsonRepsonse<GPendingWorkViewResDto>(dataTableFilterDto.Draw, 0, 0, new List<GPendingWorkViewResDto>());
                }

                // Search functionality
                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        (!string.IsNullOrEmpty(x.Pending_Work) && x.Pending_Work.ToLower().Contains(searchTerm)) ||
                        x.P_Date.ToString().Contains(searchTerm) ||
                        x.Deadline_dt.ToString().Contains(searchTerm) ||
                        (!string.IsNullOrEmpty(x.For_Whom) && x.For_Whom.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Remark) && x.Remark.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Main_Attending_Person) && x.Main_Attending_Person.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Alternate_Attending_Person) && x.Alternate_Attending_Person.ToLower().Contains(searchTerm)) ||
                        x.Reminder_St_Dt.ToString().Contains(searchTerm) ||
                        (!string.IsNullOrEmpty(x.Attending_User_Group_Short_Name) && x.Attending_User_Group_Short_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Add_Init) && x.Add_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Updt_Init) && x.Updt_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Last_Edtr) && x.Last_Edtr.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Certifier) && x.Certifier.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Section_Short_Name) && x.Section_Short_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Section_Name) && x.Section_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Urgency_Type_name) && x.Urgency_Type_name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Urgency_Type_Short_name) && x.Urgency_Type_Short_name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Status_name) && x.Status_name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Status_Short_name) && x.Status_Short_name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.User_Group_Name) && x.User_Group_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.User_Group_Short_Name) && x.User_Group_Short_Name.ToLower().Contains(searchTerm))
                    );
                }

                // Sorting functionality
                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                // Count total records after filtering and sorting
                var totalRecords = orderedData.Count();

                // Pagination
                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                // Map the data to the response DTO
                var pendingWorks = _mapper.Map<List<GPendingWorkViewResDto>>(paginatedData);

                // Return the JSON response with the filtered, sorted, and paginated data
                return new JsonRepsonse<GPendingWorkViewResDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, pendingWorks);
            }
            catch (Exception ex)
            {
                // Handle exceptions and return an empty response
                return new JsonRepsonse<GPendingWorkViewResDto>(dataTableFilterDto.Draw, 0, 0, new List<GPendingWorkViewResDto>());
            }
        }

        #endregion Pending Task Method From View

        #region Routin Work Method From View

        public async Task<JsonRepsonse<RoutineWorkViewResDto>> GetRoutineWorkByUser(RoutineWorkViewFilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<RoutineWorkViewResDto>(dataTableFilterDto.Draw, 0, 0, new List<RoutineWorkViewResDto>());
                }

                // Fetch data from the data access method
                var resultData = await _unitOfWorkDA.HomeDA.GetGRoutinWorkFromView(username);
                if (resultData == null)
                {
                    return new JsonRepsonse<RoutineWorkViewResDto>(dataTableFilterDto.Draw, 0, 0, new List<RoutineWorkViewResDto>());
                }

                // Search functionality
                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        (!string.IsNullOrEmpty(x.Title) && x.Title.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Custom_Msg) && x.Custom_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.User_Group_Short_Name) && x.User_Group_Short_Name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Main_Attending_Person) && x.Main_Attending_Person.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Alternate_Attending_Person) && x.Alternate_Attending_Person.ToLower().Contains(searchTerm)) ||
                        x.Msg_Dt.ToString().Contains(searchTerm) ||
                        (!string.IsNullOrEmpty(x.Start_Remind_Duration_Day) && x.Start_Remind_Duration_Day.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Duration_Short_name) && x.Duration_Short_name.ToLower().Contains(searchTerm)) ||
                        x.Duration_Deadline_Dt.ToString().Contains(searchTerm) ||
                        (!string.IsNullOrEmpty(x.Show_Msg) && x.Show_Msg.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.DoneBy_Init) && x.DoneBy_Init.ToLower().Contains(searchTerm)) ||
                        x.DoneOn_Dt.ToString().Contains(searchTerm) ||
                        (!string.IsNullOrEmpty(x.Add_init) && x.Add_init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Updt_Init) && x.Updt_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Last_Edtr) && x.Last_Edtr.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Certifier) && x.Certifier.ToLower().Contains(searchTerm)) ||
                        (x.Updt_Authority_Level.HasValue && x.Updt_Authority_Level.ToString().Contains(searchTerm)) ||
                        (x.Certifier_Authority_Level.HasValue && x.Certifier_Authority_Level.ToString().Contains(searchTerm))
                    );
                }

                // Sorting functionality
                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                // Count total records after filtering and sorting
                var totalRecords = orderedData.Count();

                // Pagination
                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                // Map the data to the response DTO
                var routineWorks = _mapper.Map<List<RoutineWorkViewResDto>>(paginatedData);

                // Return the JSON response with the filtered, sorted, and paginated data
                return new JsonRepsonse<RoutineWorkViewResDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, routineWorks);
            }
            catch (Exception ex)
            {
                // Handle exceptions and return an empty response
                return new JsonRepsonse<RoutineWorkViewResDto>(dataTableFilterDto.Draw, 0, 0, new List<RoutineWorkViewResDto>());
            }
        }

        #endregion Routin Work Method From View

        #region Remark Management Method

        public async Task<L_Remark_Master_ResDto> GetRemarkDataByUser(bool isRemarkAsMainUser, string username)
        {
            try
            {
                L_Remark_Master_ResDto l_Remark_Response = new L_Remark_Master_ResDto();

                if (string.IsNullOrEmpty(username))
                {
                    return new L_Remark_Master_ResDto();
                }

                if (isRemarkAsMainUser)
                {
                    var remarkMainData = _unitOfWorkDA.HomeDA.GetL_Remark_MasterByUser(username, true);

                    l_Remark_Response.MainUserReplyD = remarkMainData.Where(x => x.Remark_User_Reply_Date != null).Count();
                    l_Remark_Response.MainUserReplyN = remarkMainData.Where(x => x.Remark_User_Reply_Date == null).Count();
                    l_Remark_Response.MainHeadReplyD = remarkMainData.Where(x => x.Remark_Sec_Head_Reply_Date != null).Count();
                    l_Remark_Response.MainHeadReplyN = remarkMainData.Where(x => x.Remark_Sec_Head_Reply_Date == null).Count();
                }
                else
                {
                    var remarkOtherData = _unitOfWorkDA.HomeDA.GetL_Remark_MasterByUser(username, false);

                    l_Remark_Response.OtherUserReplyD = remarkOtherData.Where(x => x.Remark_User_Reply_Date != null).Count();
                    l_Remark_Response.OtherUserReplyN = remarkOtherData.Where(x => x.Remark_User_Reply_Date == null).Count();
                    l_Remark_Response.OtherHeadReplyD = remarkOtherData.Where(x => x.Remark_Sec_Head_Reply_Date != null).Count();
                    l_Remark_Response.OtherHeadReplyN = remarkOtherData.Where(x => x.Remark_Sec_Head_Reply_Date == null).Count();
                }

                return l_Remark_Response;
            }
            catch (Exception ex)
            {
                return new L_Remark_Master_ResDto();
            }
        }

        #endregion Remark Management Method

        #region Book OverDue Method

        public async Task<JsonRepsonse<BookIssueDetailResDto>> GetBookOverdueViewDataByUser(BookIssueFilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<BookIssueDetailResDto>(dataTableFilterDto.Draw, 0, 0, new List<BookIssueDetailResDto>());
                }

                var today = DateTime.Now;
                var data = await _unitOfWorkDA.HomeDA.GetBookOverDueFromView();

                if (data == null)
                {
                    return new JsonRepsonse<BookIssueDetailResDto>(dataTableFilterDto.Draw, 0, 0, new List<BookIssueDetailResDto>());
                }
                else
                {
                    switch (dataTableFilterDto.BookTypeFlag)
                    {
                        case (int)BookOverDueType.DailyOverdue:
                            data = data.Where(x => x.Receipt_Dt == null && x.Expected_date < today && x.Expected_date > today.AddDays(-1));
                            break;

                        case (int)BookOverDueType.WeeklyOverdue:
                            data = data.Where(x => x.Receipt_Dt == null && x.Expected_date < today && x.Expected_date > today.AddDays(-8));
                            break;

                        case (int)BookOverDueType.MonthlyOverdue:
                            data = data.Where(x => x.Receipt_Dt == null && x.Expected_date < today && x.Expected_date > today.AddDays(-30));
                            break;

                        case (int)BookOverDueType.OldOverdue:
                            data = data.Where(x => x.Receipt_Dt == null && x.Expected_date < today.AddDays(-30));
                            break;

                        case (int)BookOverDueType.FollowupPendingOverdue:
                            var followupData = await _unitOfWorkDA.HomeDA.GetFollowUpBookDue();
                            List<string> lstReaderNo = followupData.Where(f => f.Overdue_Followup_Status != "D" && (f.Date_Suggested < DateTime.Now.AddDays(-1) || f.Date_Suggested == null)).Select(x => x.Reader_No).ToList();
                            data = data.Where(x => x.Receipt_Dt == null && x.Expected_date < today.AddDays(-1) && (!string.IsNullOrEmpty(x.Reader_No) && lstReaderNo.Contains(x.Reader_No)));
                            break;

                        default:
                            throw new ArgumentException("Invalid book type.");
                    }
                }

                // Search functionality
                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    data = data.Where(x =>
                        (!string.IsNullOrEmpty(x.Bhandar_Code) && x.Bhandar_Code.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Book_No) && x.Book_No.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Is_Lost) && x.Is_Lost.ToLower().Contains(searchTerm)) ||
                        x.Issue_Tran_No.ToString().Contains(searchTerm) ||
                        (x.Issue_date.HasValue && x.Issue_date.Value.ToString().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Issue_init) && x.Issue_init.ToLower().Contains(searchTerm)) ||
                        (x.Expected_date.HasValue && x.Expected_date.Value.ToString().Contains(searchTerm)) ||
                        (x.Receipt_Dt.HasValue && x.Receipt_Dt.Value.ToString().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Reciever_Init) && x.Reciever_Init.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Prksn_Nam) && x.Prksn_Nam.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Vol_Sub_Vol) && x.Vol_Sub_Vol.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Reader_No) && x.Reader_No.ToLower().Contains(searchTerm)) ||
                        (x.Receipt_Tran_No.HasValue && x.Receipt_Tran_No.Value.ToString().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Book_Remark) && x.Book_Remark.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.L_Ext_Iss_Gatepass_Remark) && x.L_Ext_Iss_Gatepass_Remark.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.L_Ext_Iss_Detail_Remark) && x.L_Ext_Iss_Detail_Remark.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Prksn_Key) && x.Prksn_Key.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Certifier) && x.Certifier.ToLower().Contains(searchTerm))
                    );
                }

                // Sorting functionality
                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? data.OrderBy(sortBy) : data.OrderBy($"{sortBy} descending");

                // Count total records after filtering and sorting
                var totalRecords = orderedData.Count();

                // Pagination
                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                var resultData = _mapper.Map<List<BookIssueDetailResDto>>(paginatedData);

                // Return the JSON response with the filtered, sorted, and paginated data
                return new JsonRepsonse<BookIssueDetailResDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, resultData);
            }
            catch (Exception ex)
            {
                // Handle exceptions and return an empty response
                return new JsonRepsonse<BookIssueDetailResDto>(dataTableFilterDto.Draw, 0, 0, new List<BookIssueDetailResDto>());
            }
        }

        #endregion Book OverDue Method

        #region User Error Suggestion Score Board Method

        public async Task<JsonRepsonse<ErrorDetailResDto>> GetErrorDetailsViewData(ErrorDetailFilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<ErrorDetailResDto>(dataTableFilterDto.Draw, 0, 0, new List<ErrorDetailResDto>());
                }

                var data = await _unitOfWorkDA.HomeDA.GetErrorDetailsFromView(username);

                if (data == null)
                {
                    return new JsonRepsonse<ErrorDetailResDto>(dataTableFilterDto.Draw, 0, 0, new List<ErrorDetailResDto>());
                }
                else
                {
                    switch (dataTableFilterDto.ErrorType)
                    {
                        case (int)ErrorType.ErrorsPosted:
                            // Default Values if type is Errors Posted
                            break;

                        case (int)ErrorType.ErrorsSolved:
                            data = data.Where(x => !string.IsNullOrEmpty(x.Error_Status_Description) && x.Error_Status_Description.ToLower() == "done");
                            break;

                        case (int)ErrorType.ErrorsPending:
                            data = data.Where(x => !string.IsNullOrEmpty(x.Error_Status_Description) && x.Error_Status_Description.ToLower() != "done");
                            break;

                        case (int)ErrorType.ErrorsExplainationNeeded:
                            data = data.Where(x => !string.IsNullOrEmpty(x.Error_Status_Description) && x.Error_Status_Description.ToLower() == "explanation needed");
                            break;

                        case (int)ErrorType.ErrorsCompletedByProgrammer:
                            data = data.Where(x => !string.IsNullOrEmpty(x.Error_Status_Description) && x.Error_Status_Description.ToLower() == "completed");
                            break;

                        case (int)ErrorType.Suggestion_Posted:
                            data = data.Where(x => !string.IsNullOrEmpty(x.TypeOfError) && x.TypeOfError.ToLower() == "s");
                            break;

                        default:
                            throw new ArgumentException("Invalid Error Type.");
                    }
                }

                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    data = data.Where(x =>
                        x.ErrorID.ToString().Contains(searchTerm) ||
                        (!string.IsNullOrEmpty(x.Error_Description) && x.Error_Description.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Error_Status_Description) && x.Error_Status_Description.ToLower().Contains(searchTerm)) ||
                        (x.Error_PostDate.HasValue && x.Error_PostDate.Value.ToString().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Programmer_Remark) && x.Programmer_Remark.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.TypeOfError) && x.TypeOfError.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Urgency_Type_Short_name) && x.Urgency_Type_Short_name.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.User_Reply) && x.User_Reply.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Entity) && x.Entity.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Entity_Field) && x.Entity_Field.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Programmer_Init) && x.Programmer_Init.ToLower().Contains(searchTerm)) ||
                        (x.Error_Solved_Date.HasValue && x.Error_Solved_Date.Value.ToString().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.Error_Image_Path) && x.Error_Image_Path.ToLower().Contains(searchTerm)) ||
                        (!string.IsNullOrEmpty(x.User_Init) && x.User_Init.ToLower().Contains(searchTerm))
                    );
                }

                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? data.OrderBy(sortBy) : data.OrderBy($"{sortBy} descending");

                var totalRecords = orderedData.Count();

                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                var resultData = _mapper.Map<List<ErrorDetailResDto>>(paginatedData);

                return new JsonRepsonse<ErrorDetailResDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, resultData);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<ErrorDetailResDto>(dataTableFilterDto.Draw, 0, 0, new List<ErrorDetailResDto>());
            }
        }

        #endregion User Error Suggestion Score Board Method

        #region Hp Internal Issue Method

        public async Task<JsonRepsonse<Hp_Internal_Issue_ResDto>> GetHp_Internal_IssueByUser(Hp_Internal_Issue_FilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<Hp_Internal_Issue_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<Hp_Internal_Issue_ResDto>());
                }

                var resultData = await _unitOfWorkDA.HomeDA.GetHpInternalIssueByUser(username, dataTableFilterDto.Hp_IssueType);
                if (resultData == null)
                {
                    return new JsonRepsonse<Hp_Internal_Issue_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<Hp_Internal_Issue_ResDto>());
                }

                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        x.Tran_No.ToString().Contains(searchTerm) ||
                        x.Bhandar_Code.ToLower().Contains(searchTerm) ||
                        x.Hp_No.ToLower().Contains(searchTerm) ||
                        x.To_Whom.ToLower().Contains(searchTerm) ||
                        (x.Issue_Init != null && x.Issue_Init.ToLower().Contains(searchTerm)) ||
                        (x.Receiver_Init != null && x.Receiver_Init.ToLower().Contains(searchTerm)) ||
                        (x.Issue_Type_Short_name != null && x.Issue_Type_Short_name.ToLower().Contains(searchTerm)) ||
                        x.Add_Init.ToLower().Contains(searchTerm) ||
                        (x.Updt_Init != null && x.Updt_Init.ToLower().Contains(searchTerm))
                    );
                }

                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                var totalRecords = orderedData.Count();

                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                var hp_Internal_Issue_Data = _mapper.Map<List<Hp_Internal_Issue_ResDto>>(paginatedData);

                return new JsonRepsonse<Hp_Internal_Issue_ResDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, hp_Internal_Issue_Data);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<Hp_Internal_Issue_ResDto>(dataTableFilterDto.Draw, 0, 0, new List<Hp_Internal_Issue_ResDto>());
            }
        }

        #endregion Hp Internal Issue Method

        #region User Add/Update Score Board Method

        public async Task<JsonRepsonse<UserScoreBoardResponseDto>> GetUserScoreBoardFromSP(UserScoreBoardFilterDto dataTableFilterDto, CancellationToken cancellationToken)
        {
            try
            {
                var spResult = _unitOfWorkDA.HomeDA.GetUserScoreBoardFromSP(dataTableFilterDto, cancellationToken).Result;
                if (spResult == null)
                {
                    return new JsonRepsonse<UserScoreBoardResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<UserScoreBoardResponseDto>());
                }

                var resultData = _mapper.Map<List<UserScoreBoardResponseDto>>(spResult);
                return new JsonRepsonse<UserScoreBoardResponseDto>(dataTableFilterDto.Draw, 0, 0, resultData);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<UserScoreBoardResponseDto>(dataTableFilterDto.Draw, 0, 0, new List<UserScoreBoardResponseDto>());
            }
        }

        #endregion User Add/Update Score Board Method

        #region Daily Work Logs Method

        public async Task<JsonRepsonse<DailyViewResDto>> GetDailyViewDataByUser(DailyViewFilterDto dataTableFilterDto, string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new JsonRepsonse<DailyViewResDto>(dataTableFilterDto.Draw, 0, 0, new List<DailyViewResDto>());
                }

                var data = await _unitOfWorkDA.HomeDA.GetDailyWorkLogsFromView(username);

                if (data == null)
                {
                    return new JsonRepsonse<DailyViewResDto>(dataTableFilterDto.Draw, 0, 0, new List<DailyViewResDto>());
                }

                if (dataTableFilterDto.FromDate != DateTime.MinValue && dataTableFilterDto.ToDate != DateTime.MinValue)
                {
                    data = data.Where(x => x.Sess_datetime >= dataTableFilterDto.FromDate && x.Sess_datetime <= dataTableFilterDto.ToDate);
                }

                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    data = data.Where(x =>
                        x.Daily_Id.ToString().Contains(searchTerm) ||
                        x.Sess_datetime.ToString().Contains(searchTerm) ||
                        x.Leave.ToLower().Contains(searchTerm) ||
                        x.Half_Day.ToLower().Contains(searchTerm) ||
                        x.Dutyleave.ToLower().Contains(searchTerm) ||
                        (x.Arrival != null && x.Arrival.ToLower().Contains(searchTerm)) ||
                        (x.Departure != null && x.Departure.ToLower().Contains(searchTerm)) ||
                        (x.Recess != null && x.Recess.ToLower().Contains(searchTerm)) ||
                        (x.Tea_break != null && x.Tea_break.ToLower().Contains(searchTerm)) ||
                        (x.Main_Work != null && x.Main_Work.ToLower().Contains(searchTerm)) ||
                        (x.Main_Desc != null && x.Main_Desc.ToLower().Contains(searchTerm)) ||
                        (x.Work_Output != null && x.Work_Output.ToLower().Contains(searchTerm)) ||
                        (x.M_Rel_Work != null && x.M_Rel_Work.ToLower().Contains(searchTerm)) ||
                        (x.M_Rel_Desc != null && x.M_Rel_Desc.ToLower().Contains(searchTerm)) ||
                        (x.M_Rel_Output != null && x.M_Rel_Output.ToLower().Contains(searchTerm)) ||
                        (x.Other_Work != null && x.Other_Work.ToLower().Contains(searchTerm)) ||
                        (x.Other_Desc != null && x.Other_Desc.ToLower().Contains(searchTerm)) ||
                        (x.Other_Output != null && x.Other_Output.ToLower().Contains(searchTerm)) ||
                        (x.Disturb != null && x.Disturb.ToLower().Contains(searchTerm)) ||
                        (x.Disturb_Desc != null && x.Disturb_Desc.ToLower().Contains(searchTerm)) ||
                        (x.Remark != null && x.Remark.ToLower().Contains(searchTerm)) ||
                        (x.Supervisor_Remark != null && x.Supervisor_Remark.ToLower().Contains(searchTerm)) ||
                        (x.Supervisor_Remark_Dt != null && x.Supervisor_Remark_Dt.ToString().Contains(searchTerm)) ||
                        (x.User_Reply != null && x.User_Reply.ToLower().Contains(searchTerm)) ||
                        (x.User_Reply_Dt != null && x.User_Reply_Dt.ToString().Contains(searchTerm)) ||
                        (x.Supervisor_Remark_Status_Code != null && x.Supervisor_Remark_Status_Code.ToLower().Contains(searchTerm)) ||
                        (x.Add_Init != null && x.Add_Init.ToLower().Contains(searchTerm)) ||
                        (x.Updt_Init != null && x.Updt_Init.ToLower().Contains(searchTerm)) ||
                        (x.Last_Edtr != null && x.Last_Edtr.ToLower().Contains(searchTerm)) ||
                        (x.Certifier != null && x.Certifier.ToLower().Contains(searchTerm)) ||
                        x.Updt_Authority_Level.ToString().Contains(searchTerm) ||
                        x.Certifier_Authority_Level.ToString().Contains(searchTerm) ||
                        (x.Status_Short_name != null && x.Status_Short_name.ToLower().Contains(searchTerm)) ||
                        (x.UserName != null && x.UserName.ToLower().Contains(searchTerm)) ||
                        (x.Usr_Init != null && x.Usr_Init.ToLower().Contains(searchTerm))
                    );
                }

                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                var orderedData = sortOrder == "asc"
                    ? data.OrderBy(sortBy)
                    : data.OrderBy($"{sortBy} descending");

                var totalRecords = orderedData.Count();

                var paginatedData = orderedData
                    .Skip(dataTableFilterDto.Start)
                    .Take(dataTableFilterDto.PageSize)
                    .ToList();

                var resultData = _mapper.Map<List<DailyViewResDto>>(paginatedData);

                return new JsonRepsonse<DailyViewResDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, resultData);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<DailyViewResDto>(dataTableFilterDto.Draw, 0, 0, new List<DailyViewResDto>());
            }
        }

        #endregion Daily Work Logs Method

        #region Get Dashboard Counts

        public async Task<DashboardCounts> GetDashboardCountsFromSP(string username, CancellationToken cancellationToken)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    return new DashboardCounts();
                }

                var spResult = await _unitOfWorkDA.HomeDA.GetDashboardCountsFromSP(username, cancellationToken);

                return spResult;
            }
            catch (Exception ex)
            {
                return new DashboardCounts();
            }
        }

        #endregion Get Dashboard Counts
    }
}