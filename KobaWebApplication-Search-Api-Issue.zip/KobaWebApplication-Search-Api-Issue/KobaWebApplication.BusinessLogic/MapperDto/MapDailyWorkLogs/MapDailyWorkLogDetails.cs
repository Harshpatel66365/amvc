﻿using AutoMapper;
using KobaWebApplication.DataEntities.Result;
using KobaWebApplication.Dto.Home.L_DailyViewDto;
using KobaWebApplication.Dto.Home.User_Score_Board;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapDailyWorkLogs
{
    public class MapDailyWorkLogDetails : Profile
    {
        public MapDailyWorkLogDetails()
        {
            CreateMap<L_DailyView, DailyViewResDto>().ReverseMap();
        }
    }

    public class MapUserScoreDetails : Profile
    {
        public MapUserScoreDetails()
        {
            CreateMap<UserAddUpdateScoreBoard_Response, UserScoreBoardResponseDto>().ReverseMap();
        }
    }
}