﻿using AutoMapper;
using KobaWebApplication.DataEntities.Result;
using KobaWebApplication.Dto.Home.RoutinWorkDto;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapRoutinWork
{
    public class MapRoutinWork : Profile
    {
        public MapRoutinWork()
        {
            CreateMap<RoutineWorkView, RoutineWorkViewResDto>().ReverseMap();
        }
    }
}
