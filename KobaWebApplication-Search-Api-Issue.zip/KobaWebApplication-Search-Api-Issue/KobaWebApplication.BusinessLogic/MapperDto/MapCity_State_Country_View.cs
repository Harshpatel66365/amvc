﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.AdvanceSearch;
using KobaWebApplication.Dto.User;

namespace KobaWebApplication.BusinessLogic.MapperDto
{
    public class MapCity_State_Country_View : Profile
    {
        public MapCity_State_Country_View()
        {
            CreateMap<City_State_Country_View, City_State_Country_View_Dto>().ReverseMap();
        }
    }
}