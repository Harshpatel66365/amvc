﻿using AutoMapper;
using KobaWebApplication.DataEntities.Result;
using KobaWebApplication.Dto.Home.PendingTaskDto;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapPendingTask
{
    public class MapPendingTask : Profile
    {
        public MapPendingTask()
        {
            CreateMap<GPendingWorkView, GPendingWorkViewResDto>().ReverseMap();
        }
    }
}
