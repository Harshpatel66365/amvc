﻿using AutoMapper;
using KobaWebApplication.DataEntities.Result;
using KobaWebApplication.Dto.Home.User_Error_Suggestion;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapUserErrorScoreBoard
{
    public class MapErrorDetailsView : Profile
    {
        public MapErrorDetailsView()
        {
            CreateMap<ErrorDetailView, ErrorDetailResDto>().ReverseMap();
        }
    }
}
