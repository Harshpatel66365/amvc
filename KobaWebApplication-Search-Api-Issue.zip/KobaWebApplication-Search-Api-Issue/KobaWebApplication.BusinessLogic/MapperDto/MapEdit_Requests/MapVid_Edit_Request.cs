﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Home.EditRequestsDto;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapEdit_Requests
{
    public class MapVid_Edit_Request : Profile
    {
        public MapVid_Edit_Request()
        {
            CreateMap<Vid_Edit_Request, Vid_Edit_ResponseDto>().ReverseMap();
        }
    }
}
