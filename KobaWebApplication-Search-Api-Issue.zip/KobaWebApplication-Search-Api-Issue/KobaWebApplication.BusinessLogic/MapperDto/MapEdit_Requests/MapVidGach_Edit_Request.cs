﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Home.EditRequestsDto;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapEdit_Requests
{
    public class MapVidGach_Edit_Request : Profile
    {
        public MapVidGach_Edit_Request()
        {
            CreateMap<Vid_Gach_Edit_Request, Vid_Gach_Edit_Req_ResponseDto>().ReverseMap();
        }
    }
}
