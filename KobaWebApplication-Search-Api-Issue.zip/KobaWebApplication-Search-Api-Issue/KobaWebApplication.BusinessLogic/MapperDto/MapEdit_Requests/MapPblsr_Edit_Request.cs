﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Home.EditRequestsDto;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapEdit_Requests
{
    public class MapPblsr_Edit_Request : Profile
    {
        public MapPblsr_Edit_Request()
        {
            CreateMap<Pblsr_Edit_Request, Pblsr_Edit_Request_ResDto>().ReverseMap();
        }
    }
}
