﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Home.EditRequestsDto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapEdit_Requests
{
    public class MapKr_Edit_Request : Profile
    {
        public MapKr_Edit_Request()
        {
            CreateMap<Kr_Edit_Request, Kr_Edit_Request_ResDto>().ReverseMap();
        }
    }
}
