﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Home.EditRequestsDto;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapEdit_Requests
{
    internal class MapMagBind_Edit_Request : Profile
    {
        public MapMagBind_Edit_Request()
        {
            CreateMap<Mag_Bind_Edit_Request, Mag_Bind_Edit_Request_ResDto>().ReverseMap();
        }
    }
}
