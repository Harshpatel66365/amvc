﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Home.EditRequestsDto;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapEdit_Requests
{
    public class MapHp_Edit_Request : Profile
    {
        public MapHp_Edit_Request()
        {
            CreateMap<Hp_Edit_Request, Hp_Edit_ResponseDto>().ReverseMap();
        }
    }
}
