﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Home.EditRequestsDto;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapEdit_Requests
{
    public class MapMag_Edit_Request : Profile
    {
        public MapMag_Edit_Request()
        {
            CreateMap<Mag_Edit_Request, Mag_Edit_Req_ResponseDto>().ReverseMap();
        }
    }
}
