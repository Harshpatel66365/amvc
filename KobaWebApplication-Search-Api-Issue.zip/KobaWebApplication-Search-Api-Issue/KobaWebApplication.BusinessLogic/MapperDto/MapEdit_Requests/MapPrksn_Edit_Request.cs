﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Home.EditRequestsDto;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapEdit_Requests
{
    public class MapPrksn_Edit_Request : Profile
    {
        public MapPrksn_Edit_Request()
        {
            CreateMap<Prksn_Edit_Request, Prksn_Edit_Request_ResDto>().ReverseMap();
        }
    }
}
