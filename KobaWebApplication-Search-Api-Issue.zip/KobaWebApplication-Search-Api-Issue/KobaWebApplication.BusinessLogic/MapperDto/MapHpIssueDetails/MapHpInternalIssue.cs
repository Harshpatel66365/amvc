﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Home.Hp_Internal_Issue;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapHpIssueDetails
{
    public class MapHpInternalIssue : Profile
    {
        public MapHpInternalIssue()
        {
            CreateMap<Hp_Internal_Issue, Hp_Internal_Issue_ResDto>().ReverseMap();
        }
    }
}
