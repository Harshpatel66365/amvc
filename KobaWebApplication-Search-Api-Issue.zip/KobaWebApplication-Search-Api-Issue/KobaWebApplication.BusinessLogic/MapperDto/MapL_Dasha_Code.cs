﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.AdvanceSearch;
using KobaWebApplication.Dto.User;

namespace KobaWebApplication.BusinessLogic.MapperDto
{
    public class MapL_Dasha_Code : Profile
    {
        public MapL_Dasha_Code()
        {
            CreateMap<L_Dasha_Code, L_Dasha_Code_Dto>().ReverseMap();
        } 
    }  
    public class MapL_Purnata_Code : Profile
    {
        public MapL_Purnata_Code()
        {
            CreateMap<L_Purnata_Code, L_Purnata_Code_Dto>().ReverseMap();
        }
    } 
    public class MapL_Purnata_Remark_Code : Profile
    {
        public MapL_Purnata_Remark_Code()
        {
            CreateMap<L_Purnata_Remark_Code, L_Purnata_Remark_Code_Dto>().ReverseMap();
        }
    }
    public class MapLDharma_Code : Profile
    {
        public MapLDharma_Code()
        {
            CreateMap<L_Dharma_Code, L_Dharma_Code_Dto>().ReverseMap();
        }
    }
}