﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Home.Unique_SuggestionDto;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapUnique_Suggestions
{
    public class MapPblsr_Unique_Suggestion : Profile
    {

        public MapPblsr_Unique_Suggestion()
        {
            CreateMap<Pblsr_Unique_Suggestion, Pblsr_Unique_Suggestion_ResponseDto>().ReverseMap();
        }
    }
}
