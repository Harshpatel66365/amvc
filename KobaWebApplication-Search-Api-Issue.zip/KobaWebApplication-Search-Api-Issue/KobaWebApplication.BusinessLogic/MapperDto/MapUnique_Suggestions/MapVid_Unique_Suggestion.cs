﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Home.Unique_SuggestionDto;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapUnique_Suggestions
{
    public class MapVid_Unique_Suggestion : Profile
    {
        public MapVid_Unique_Suggestion()
        {
            CreateMap<Vid_Unique_Suggestion, Vid_Unique_Suggestion_ResponseDto>().ReverseMap();
        }
    }
}
