﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Home.Unique_SuggestionDto;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapUnique_Suggestions
{
    public class MapGach_Unique_Suggestion : Profile
    {
        public MapGach_Unique_Suggestion()
        {
            CreateMap<Vid_Gach_Unique_Suggestion, Vid_Gach_Unique_Suggestion_ResponseDto>().ReverseMap();
        }
    }
}
