﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Home.Unique_SuggestionDto;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapUnique_Suggestions
{
    public class MapPrksn_Unique_Suggestion : Profile
    {
        public MapPrksn_Unique_Suggestion()
        {
            CreateMap<Prksn_Unique_Suggestion, Prksn_Unique_Suggestion_ResponseDto>().ReverseMap();
        }
    }
}
