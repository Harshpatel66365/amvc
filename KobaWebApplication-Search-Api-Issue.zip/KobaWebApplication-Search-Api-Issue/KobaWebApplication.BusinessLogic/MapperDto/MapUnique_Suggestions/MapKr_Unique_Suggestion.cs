﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Home.Unique_SuggestionDto;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapUnique_Suggestions
{
    public class MapKr_Unique_Suggestion : Profile
    {
        public MapKr_Unique_Suggestion()
        {
            CreateMap<Kr_Unique_Suggestion, Kr_Unique_Suggestion_ResponseDto>().ReverseMap();
        }
    }
}
