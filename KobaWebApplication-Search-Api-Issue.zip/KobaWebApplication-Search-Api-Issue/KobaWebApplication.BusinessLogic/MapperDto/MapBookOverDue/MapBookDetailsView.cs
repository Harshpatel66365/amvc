﻿using AutoMapper;
using KobaWebApplication.DataEntities.Result;
using KobaWebApplication.Dto.Home.BookOverDueDto;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapBookOverDue
{
    public class MapBookDetailsView : Profile
    {
        public MapBookDetailsView()
        {
            CreateMap<BookIssueDetailView, BookIssueDetailResDto>().ReverseMap();
        }
    }
}
