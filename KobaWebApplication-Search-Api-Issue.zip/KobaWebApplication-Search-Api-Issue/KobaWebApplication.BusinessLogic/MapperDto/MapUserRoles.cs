﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Role;

namespace KobaWebApplication.BusinessLogic.MapperDto
{
    public class MapUserRoles : Profile
    {
        public MapUserRoles()
        {
            CreateMap<Role, RolesDetailsDto>().ReverseMap();
        }
    }
}
