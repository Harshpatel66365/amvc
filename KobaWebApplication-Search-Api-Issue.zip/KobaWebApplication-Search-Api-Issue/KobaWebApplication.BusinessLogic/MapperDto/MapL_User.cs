﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.User;

namespace KobaWebApplication.BusinessLogic.MapperDto
{
    public class MapL_User : Profile
    {
        public MapL_User()
        {
            CreateMap<L_User, UserDetailsDto>().ReverseMap();
        }
    }
}