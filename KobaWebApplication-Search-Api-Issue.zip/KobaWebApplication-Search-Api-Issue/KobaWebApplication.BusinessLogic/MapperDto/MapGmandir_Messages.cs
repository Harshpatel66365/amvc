﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Home;

namespace KobaWebApplication.BusinessLogic.MapperDto
{
    public class MapGmandir_Messages : Profile
    {
        public MapGmandir_Messages()
        {
            CreateMap<L_Gmandir_Messages, L_Gmandir_Messages_ResDto>().ReverseMap();
        }
    }
}
