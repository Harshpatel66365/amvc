﻿using AutoMapper;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Home.RemarkManagementDto;

namespace KobaWebApplication.BusinessLogic.MapperDto.MapRemarkMaster
{
    public class MapL_Remark_Master : Profile
    {
        public MapL_Remark_Master()
        {
            CreateMap<L_Remark_Master, L_Remark_Master_ResDto>().ReverseMap();
        }
    }
}
