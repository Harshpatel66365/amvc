﻿using KobaWebApplication.DataAccess.Interface;
using KobaWebApplication.DataEntities;
using KobaWebApplication.DataEntities.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq.Dynamic.Core;

namespace KobaWebApplication.DataAccess.Repositories
{
    public class CommonDA : ICommonDA
    {
        private readonly ApplicationDbContext _dbContext;

        public CommonDA(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public void InsertUserTechnicalData(string userId, string machineName, string ProcType, string ActionType)
        {
            var techData = new User_Technical_Data_Detail
            {
                User_Init = userId,
                Rec_Type = ActionType,
                Date_Time = DateTime.Now,
                Prakar_type_short_name = machineName,
                Proc_Type = ProcType
                // Set other properties with default or null values as needed
            };

            _dbContext.User_Technical_Data_Detail.Add(techData);
            _dbContext.SaveChanges();
        } 
    }
}