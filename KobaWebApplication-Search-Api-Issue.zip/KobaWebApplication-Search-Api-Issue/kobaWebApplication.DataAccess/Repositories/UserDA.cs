﻿using KobaWebApplication.DataAccess.Interface;
using KobaWebApplication.DataEntities.Models;
using Microsoft.EntityFrameworkCore;
using KobaWebApplication.DataEntities;

namespace KobaWebApplication.DataAccess.Repositories
{
    public class UserDA : IUserDA
    {
        private readonly ApplicationDbContext _dbContext;

        public UserDA(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
            //this._userManager = userManager;
        }

		public async Task<IQueryable<L_User>> GetAllUsers(string working_type = "c")
		{
			return _dbContext.L_User
				.Where(x => x.Working_Type.ToLower() == working_type.ToLower());
		}
		public async Task<L_User> GetUsersById(int UserId)
        {
            return await _dbContext.L_User.Where(x => x.Id == UserId).FirstOrDefaultAsync();
        }
        public int ChangeUserPassword(L_User updatedUser)
        {
            try
            {
                var newUser = this._dbContext.L_User.Where(x => x.Id == updatedUser.Id).FirstOrDefault();
                newUser.Pwd = updatedUser.Pwd;
                this._dbContext.L_User.Update(newUser);
                return this._dbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
        public int UpdateUser(L_User user)
        {
            try
            {
                var newUser = this._dbContext.L_User.Where(x => x.Id == user.Id).FirstOrDefault();
                newUser.Permanent_Address = user.Permanent_Address;
                newUser.Usr_Name = user.Usr_Name;
                this._dbContext.L_User.Update(newUser);
                return this._dbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
    }
}