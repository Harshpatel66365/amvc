﻿using KobaWebApplication.DataAccess.Generic;
using KobaWebApplication.DataAccess.Interface;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.DataEntities;
using KobaWebApplication.DataEntities.Result;
using KobaWebApplication.Core.Common;
using Microsoft.Data.SqlClient;
using KobaWebApplication.Dto.Home.User_Score_Board;

namespace KobaWebApplication.DataAccess.Repositories
{
    public class HomeDA : IHomeDA
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly ISqlRepository<UserAddUpdateScoreBoard_Response> _userScoreBoard;
        private readonly ISqlRepository<DashboardCounts> _dashboardCounts;

        public HomeDA(ApplicationDbContext dbContext, ISqlRepository<UserAddUpdateScoreBoard_Response> userScoreBoard, ISqlRepository<DashboardCounts> dashboardCounts)
        {
            this._dbContext = dbContext;
            _userScoreBoard = userScoreBoard;
            _dashboardCounts = dashboardCounts;
        }

        public async Task<IQueryable<Kr_Edit_Request>> GetKr_Edit_ReqByUser(string username, bool isReceiver)
        {
            if (isReceiver)
            {
                return this._dbContext.Kr_Edit_Request.Where(x => x.Receiver_init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
            else
            {
                return this._dbContext.Kr_Edit_Request.Where(x => x.Sender_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
        }

        public async Task<IQueryable<Hp_Edit_Request>> GetHp_Edit_ReqByUser(string username, bool isReceiver)
        {
            if (isReceiver)
            {
                return this._dbContext.Hp_Edit_Request.Where(x => x.Receiver_init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_name.Trim().ToUpper() == "CN" || x.Status_Short_name.Trim().ToUpper() == "DN" || x.Status_Short_name.Trim().ToUpper() == "PN"));
            }
            else
            {
                return this._dbContext.Hp_Edit_Request.Where(x => x.Sender_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_name.Trim().ToUpper() == "CN" || x.Status_Short_name.Trim().ToUpper() == "DN" || x.Status_Short_name.Trim().ToUpper() == "PN"));
            }
        }

        public async Task<IQueryable<Vid_Edit_Request>> GetVid_Edit_ReqByUser(string username, bool isReceiver)
        {
            if (isReceiver)
            {
                return this._dbContext.Vid_Edit_Request.Where(x => x.Receiver_init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_name.Trim().ToUpper() == "CN" || x.Status_Short_name.Trim().ToUpper() == "DN" || x.Status_Short_name.Trim().ToUpper() == "PN"));
            }
            else
            {
                return this._dbContext.Vid_Edit_Request.Where(x => x.Sender_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_name.Trim().ToUpper() == "CN" || x.Status_Short_name.Trim().ToUpper() == "DN" || x.Status_Short_name.Trim().ToUpper() == "PN"));
            }
        }

        public async Task<IQueryable<Vid_Gach_Edit_Request>> GetVid_Gach_Edit_ReqByUser(string username, bool isReceiver)
        {
            if (isReceiver)
            {
                return this._dbContext.Vid_Gach_Edit_Request.Where(x => x.Receiver_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
            else
            {
                return this._dbContext.Vid_Gach_Edit_Request.Where(x => x.Sender_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
        }

        public async Task<IQueryable<Mag_Edit_Request>> GetMag_Edit_ReqByUser(string username, bool isReceiver)
        {
            if (isReceiver)
            {
                return this._dbContext.Mag_Edit_Request.Where(x => x.Receiver_init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
            else
            {
                return this._dbContext.Mag_Edit_Request.Where(x => x.Sender_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
        }

        public async Task<IQueryable<Prksn_Edit_Request>> GetPrksn_Edit_ReqByUser(string username, bool isReceiver)
        {
            if (isReceiver)
            {
                return this._dbContext.Prksn_Edit_Request.Where(x => x.Receiver_init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_name.Trim().ToUpper() == "CN" || x.Status_Short_name.Trim().ToUpper() == "DN" || x.Status_Short_name.Trim().ToUpper() == "PN"));
            }
            else
            {
                return this._dbContext.Prksn_Edit_Request.Where(x => x.Sender_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_name.Trim().ToUpper() == "CN" || x.Status_Short_name.Trim().ToUpper() == "DN" || x.Status_Short_name.Trim().ToUpper() == "PN"));
            }
        }

        public async Task<IQueryable<Pblsr_Edit_Request>> GetPblsr_Edit_ReqByUser(string username, bool isReceiver)
        {
            if (isReceiver)
            {
                return this._dbContext.Pblsr_Edit_Request.Where(x => x.Receiver_init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
            else
            {
                return this._dbContext.Pblsr_Edit_Request.Where(x => x.Sender_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
        }

        public async Task<IQueryable<Mag_Bind_Edit_Request>> GetMag_EditBind_ReqByUser(string username, bool isReceiver)
        {
            if (isReceiver)
            {
                return this._dbContext.Mag_Bind_Edit_Request.Where(x => x.Receiver_init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
            else
            {
                return this._dbContext.Mag_Bind_Edit_Request.Where(x => x.Sender_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
        }

        public async Task<IQueryable<Kr_Unique_Suggestion>> GetKr_Unique_SuggestionsByUser(string username, bool isReceiver)
        {
            if (isReceiver)
            {
                return this._dbContext.Kr_Unique_Suggestion.Where(x => x.Receiver_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
            else
            {
                return this._dbContext.Kr_Unique_Suggestion.Where(x => x.Add_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
        }

        public async Task<IQueryable<Vid_Unique_Suggestion>> GetVid_Unique_SuggestionsByUser(string username, bool isReceiver)
        {
            if (isReceiver)
            {
                return this._dbContext.Vid_Unique_Suggestion.Where(x => x.Receiver_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
            else
            {
                return this._dbContext.Vid_Unique_Suggestion.Where(x => x.Add_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
        }

        public async Task<IQueryable<Vid_Gach_Unique_Suggestion>> GetVid_Gach_Unique_SuggestionsByUser(string username, bool isReceiver)
        {
            if (isReceiver)
            {
                return this._dbContext.Vid_Gach_Unique_Suggestion.Where(x => x.Receiver_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
            else
            {
                return this._dbContext.Vid_Gach_Unique_Suggestion.Where(x => x.Add_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
        }

        public async Task<IQueryable<Pblsr_Unique_Suggestion>> GetPblsr_Unique_SuggestionsByUser(string username, bool isReceiver)
        {
            if (isReceiver)
            {
                return this._dbContext.Pblsr_Unique_Suggestion.Where(x => x.Receiver_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
            else
            {
                return this._dbContext.Pblsr_Unique_Suggestion.Where(x => x.Add_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
        }

        public async Task<IQueryable<Prksn_Unique_Suggestion>> GetPrksn_Unique_SuggestionsByUser(string username, bool isReceiver)
        {
            if (isReceiver)
            {
                return this._dbContext.Prksn_Unique_Suggestion.Where(x => x.Receiver_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
            else
            {
                return this._dbContext.Prksn_Unique_Suggestion.Where(x => x.Add_Init.Trim().ToLower() == username.Trim().ToLower() && (x.Status_Short_Name.Trim().ToUpper() == "CN" || x.Status_Short_Name.Trim().ToUpper() == "DN" || x.Status_Short_Name.Trim().ToUpper() == "PN"));
            }
        }

        public async Task<IQueryable<GPendingWorkView>> GetGPendingWorkFromView(string username)
        {
            List<string> statusShortNames = new List<string>
            {
                "PN",
                "CN"
            };

            return this._dbContext.GPendingWorkView
                .Where(x =>
                    (x.Main_Attending_Person.ToLower() == username.ToLower() ||
                     x.Alternate_Attending_Person.ToLower() == username.ToLower())
                    && statusShortNames.Contains(x.Status_Short_name.ToUpper())
                )
                ;
        }

        public async Task<IQueryable<RoutineWorkView>> GetGRoutinWorkFromView(string username)
        {
            return this._dbContext.RoutineWorkView;
        }

        public IQueryable<L_Remark_Master> GetL_Remark_MasterByUser(string username, bool isMain)
        {
            if (isMain)
            {
                return this._dbContext.L_Remark_Master.Where(x => x.Main_Sec_User_Init.Trim().ToUpper() == username.Trim().ToUpper());
            }
            else
            {
                return this._dbContext.L_Remark_Master.Where(x => x.Other_Sec_User_Init.Trim().ToUpper() == username.Trim().ToUpper() || x.Other_Sec_User_Init.StartsWith(username + ",") || x.Other_Sec_User_Init.EndsWith("," + username));
            }
        }

        public async Task<IQueryable<BookIssueDetailView>> GetBookOverDueFromView()
        {
            return this._dbContext.Book_Issue_Detail_View;
        }

        public async Task<IQueryable<OverdueBookFollowupDetail>> GetFollowUpBookDue()
        {
            return this._dbContext.OverdueBookFollowupDetail;
        }

        public async Task<IQueryable<ErrorDetailView>> GetErrorDetailsFromView(string username)
        {
            return this._dbContext.ErrorDetailView.Where(x => x.User_Init.Trim().ToLower() == username.Trim().ToLower());
        }

        public async Task<IQueryable<Hp_Internal_Issue>> GetHpInternalIssueByUser(string username, int hpIssueType)
        {
            switch (hpIssueType)
            {
                case (int)HpInternalIssueType.Hp_InternalIssue_Detail:
                    return this._dbContext.Hp_Internal_Issue.Where(x => x.To_Whom.Trim().ToLower() == username.Trim().ToLower());

                case (int)HpInternalIssueType.Hp_Internal_Issue_Pending_Detail:
                    return this._dbContext.Hp_Internal_Issue.Where(x => x.To_Whom.Trim().ToLower() == username.Trim().ToLower() &&
                    x.Issue_Dt == null && x.Received_By_User_Dt == null && x.Returned_By_User_Dt == null);

                case (int)HpInternalIssueType.Hp_Internal_Issued_But_Not_Returned_Detail:
                    return this._dbContext.Hp_Internal_Issue.Where(x => x.To_Whom.Trim().ToLower() == username.Trim().ToLower() &&
                x.Issue_Dt != null && x.Received_By_User_Dt != null && x.Returned_By_User_Dt == null);

                default:
                    return null;
            }
        }

        public async Task<IQueryable<UserAddUpdateScoreBoard_Response>> GetUserScoreBoardFromSP(UserScoreBoardFilterDto dataTableFilterDto, CancellationToken cancellationToken)
        {
            var query = "EXEC dbo.UserAddUpdateScoreBoard @User_Init, @StartDate, @EndDate";
            var result = _userScoreBoard.GetWithRawSql(query,
                                              cancellationToken,
                                              new SqlParameter("@User_Init", dataTableFilterDto.Username),
                                              new SqlParameter("@StartDate", dataTableFilterDto.StartDate),
                                              new SqlParameter("@EndDate", dataTableFilterDto.EndDate));
            return result;
        }

        public async Task<IQueryable<L_DailyView>> GetDailyWorkLogsFromView(string username)
        {
            return this._dbContext.L_DailyView.Where(x => x.Usr_Init.Trim().ToLower() == username.Trim().ToLower());
        }

        public async Task<DashboardCounts> GetDashboardCountsFromSP(string username, CancellationToken cancellationToken)
        {
            try
            {
                var query = "EXEC dbo.GetDashboardCounts @User_Init";
                var result = _dashboardCounts.GetWithRawSql(query,
                                                  cancellationToken,
                                                  new SqlParameter("@User_Init", username)).ToList();
                return result.FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<IQueryable<L_Gmandir_Messages>> GetHomePageData()
        {
            return this._dbContext.L_Gmandir_Messages.OrderByDescending(x => x.Message_id);
        }
    }
}