﻿using Microsoft.AspNetCore.Identity;
using KobaWebApplication.Core.UserDefinedException;
using KobaWebApplication.DataAccess.Generic;
using KobaWebApplication.DataAccess.Interface;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto;
using Microsoft.EntityFrameworkCore;
using KobaWebApplication.DataEntities;

namespace KobaWebApplication.DataAccess.Repositories
{
    public class RoleDA : IRoleDA
    {
        private readonly ApplicationDbContext _context;

        public RoleDA(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Role> CreateRoleAsync(string roleName)
        {
            var role = new Role { Name = roleName, IsDeleted = false };
            _context.Roles.Add(role);
            await _context.SaveChangesAsync();
            return role;
        }

        public async Task<Role?> GetRoleByIdAsync(int roleId)
        {
            return await _context.Roles.FindAsync(roleId);
        }

        public async Task<IQueryable<Role>> GetAllRolesAsync()
        {
            return _context.Roles.Where(r => !r.IsDeleted);
        }

        public async Task DeleteRoleAsync(int roleId)
        {
            var role = await GetRoleByIdAsync(roleId);
            if (role != null)
            {
                role.IsDeleted = true;
                await _context.SaveChangesAsync();
            }
        }
    }
}