﻿using KobaWebApplication.DataAccess.Interface;
using KobaWebApplication.DataEntities.Models;
using Microsoft.EntityFrameworkCore;
using KobaWebApplication.DataEntities;

namespace KobaWebApplication.DataAccess.Repositories
{
    public class RolePermissionDA : IRolePermissionDA
    {
        ApplicationDbContext _context;
        public RolePermissionDA(ApplicationDbContext context)
        {
            _context = context;
        }


        public async Task AddClaimToRoleAsync(int roleId, string claimType, string claimValue)
        {
            var roleClaim = new RoleClaim
            {
                RoleId = roleId,
                ClaimType = claimType,
                ClaimValue = claimValue
            };
            _context.RoleClaims.Add(roleClaim);
            await _context.SaveChangesAsync();
        }
        public async Task RemoveClaimToRoleAsync(int roleId, string claimType, string claimValue)
        {
            var ExistingPermission =  _context.RoleClaims.Where(x => x.RoleId == roleId && x.ClaimType== claimType && x.ClaimValue == claimValue).FirstOrDefault();
            if (ExistingPermission != null)
            {
             _context.RoleClaims.Remove(ExistingPermission);
            }
            await _context.SaveChangesAsync();
        }

        public async Task<List<RoleClaim>> GetClaimsForRoleAsync(int roleId)
        {
            return await _context.RoleClaims
                .Where(rc => rc.RoleId == roleId)
                .ToListAsync();
        }
    }
}