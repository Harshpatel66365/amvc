﻿using KobaWebApplication.DataAccess.Interface;
using KobaWebApplication.DataEntities;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Login;

namespace KobaWebApplication.DataAccess.Repositories
{
    public class LoginDA : ILoginDA
    {
        private readonly ApplicationDbContext _dbContext;

        public LoginDA(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public L_User GetUserByEncryptedCredentials(string username, string encryptedPassword)
        {
            return _dbContext.L_User
                .FirstOrDefault(u => u.Usr_Init == username && u.Pwd == encryptedPassword);
        }

        public void UpdateUserPassword(string username, string encryptedPassword)
        {
            var user = _dbContext.L_User.FirstOrDefault(u => u.Usr_Init == username);
            if (user != null)
            {
                user.Pwd = encryptedPassword;
                _dbContext.SaveChanges();
            }
        }

        public SessionDataDto GetUserSessionValues(string username)
        {
            var user = _dbContext.L_User
                 .FirstOrDefault(u => u.Usr_Init == username);
            SessionDataDto userSession = new SessionDataDto();
            userSession.UserName = user.Usr_Name;
            userSession.UserId = user.Id;
            userSession.Prksn_Readership_lvl = user.Prksn_Readership_lvl;

            var RoleId = _dbContext.UserRoles.Where(x => x.UserId == user.Id).Select(r => r.RoleId).FirstOrDefault();
            userSession.RoleId = RoleId;

            return userSession;
        }

        //Logout section
        public void UpdateLogoutTime(string userId)
        {
            var loginRecord = _dbContext.L_Login.FirstOrDefault(l => l.Usr_Init == userId && l.LogOut_Time == null);
            if (loginRecord != null)
            {
                loginRecord.LogOut_Time = DateTime.Now;
                _dbContext.SaveChanges();
            }
        }
    }
}