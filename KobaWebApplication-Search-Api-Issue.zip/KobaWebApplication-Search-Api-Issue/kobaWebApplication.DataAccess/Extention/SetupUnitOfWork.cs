using Microsoft.Extensions.DependencyInjection;
using KobaWebApplication.DataAccess.Generic;
using KobaWebApplication.DataAccess.Interface;
using KobaWebApplication.DataAccess.Repositories;
using KobaWebApplication.DataAccess.UnitOfWork;

namespace KobaWebApplication.DataAccess.Extention
{
    public static class SetupUnitOfWork
    {
        public static void SetupUnitOfWorkDA(this IServiceCollection services)
        {
            services.AddScoped(typeof(ISqlRepository<>), typeof(SqlDBRepository<>));
            services.AddScoped<IUserDA, UserDA>();
            services.AddScoped<IRoleDA, RoleDA>();
            services.AddScoped<ILoginDA, LoginDA>();
            services.AddScoped<ICommonDA, CommonDA>();
            services.AddScoped<ILoginOptionDA, LoginOptionDA>();
            services.AddScoped<IUserRoleDA, UserRoleDA>();
            services.AddScoped<IRolePermissionDA, RolePermissionDA>();
            services.AddScoped<IHomeDA, HomeDA>();
            services.AddScoped<IHastPratDA, HastPratDA>();

            // KEEP THIS LINE AT THE END.
            services.AddScoped<IUnitOfWorkDA, UnitOfWorkDA>();
        }
    }
}