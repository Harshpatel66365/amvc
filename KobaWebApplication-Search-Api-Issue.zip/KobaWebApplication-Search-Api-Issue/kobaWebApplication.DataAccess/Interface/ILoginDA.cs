﻿using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Login;

namespace KobaWebApplication.DataAccess.Interface
{
    public interface ILoginDA
    {
        public L_User GetUserByEncryptedCredentials(string username, string encryptedPassword);

        public void UpdateUserPassword(string username, string encryptedPassword);

        public SessionDataDto GetUserSessionValues(string username);

        public void UpdateLogoutTime(string userId);
    }
}