﻿using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Common;
using KobaWebApplication.Dto.User;

namespace KobaWebApplication.DataAccess.Interface
{
    public interface IUserDA
    {
        public Task<IQueryable<L_User>> GetAllUsers(string working_type = "c");
        public Task<L_User> GetUsersById(int UserId);
        public int ChangeUserPassword(L_User updatedUser);
        public int UpdateUser(L_User user);
    }
}