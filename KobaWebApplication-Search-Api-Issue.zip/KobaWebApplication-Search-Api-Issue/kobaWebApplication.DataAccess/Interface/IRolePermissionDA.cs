﻿using Microsoft.AspNetCore.Identity;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto;
using System.Security.Claims;

namespace KobaWebApplication.DataAccess.Interface
{
    public interface IRolePermissionDA
    {
        public Task AddClaimToRoleAsync(int roleId, string claimType, string claimValue);
        public Task RemoveClaimToRoleAsync(int roleId, string claimType, string claimValue);
        public Task<List<RoleClaim>> GetClaimsForRoleAsync(int roleId);
    }
}