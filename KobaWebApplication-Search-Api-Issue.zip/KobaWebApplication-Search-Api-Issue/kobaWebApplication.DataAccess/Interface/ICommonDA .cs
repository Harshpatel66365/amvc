﻿using KobaWebApplication.DataEntities.Models;

namespace KobaWebApplication.DataAccess.Interface
{
    public interface ICommonDA
    {
        public void InsertUserTechnicalData(string userId, string machineName, string ProcType, string ActionType);
    }
}