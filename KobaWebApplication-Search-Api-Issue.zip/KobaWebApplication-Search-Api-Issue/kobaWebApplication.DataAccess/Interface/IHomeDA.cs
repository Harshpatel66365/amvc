﻿using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.DataEntities.Result;
using KobaWebApplication.Dto.Home.User_Score_Board;

namespace KobaWebApplication.DataAccess.Interface
{
    public interface IHomeDA
    {
        public Task<IQueryable<L_Gmandir_Messages>> GetHomePageData();

        public Task<IQueryable<Kr_Edit_Request>> GetKr_Edit_ReqByUser(string username, bool isReceiver);

        public Task<IQueryable<Hp_Edit_Request>> GetHp_Edit_ReqByUser(string username, bool isReceiver);

        public Task<IQueryable<Vid_Edit_Request>> GetVid_Edit_ReqByUser(string username, bool isReceiver);

        public Task<IQueryable<Vid_Gach_Edit_Request>> GetVid_Gach_Edit_ReqByUser(string username, bool isReceiver);

        public Task<IQueryable<Mag_Edit_Request>> GetMag_Edit_ReqByUser(string username, bool isReceiver);

        public Task<IQueryable<Prksn_Edit_Request>> GetPrksn_Edit_ReqByUser(string username, bool isReceiver);

        public Task<IQueryable<Pblsr_Edit_Request>> GetPblsr_Edit_ReqByUser(string username, bool isReceiver);

        public Task<IQueryable<Mag_Bind_Edit_Request>> GetMag_EditBind_ReqByUser(string username, bool isReceiver);

        public Task<IQueryable<Kr_Unique_Suggestion>> GetKr_Unique_SuggestionsByUser(string username, bool isReceiver);

        public Task<IQueryable<Vid_Unique_Suggestion>> GetVid_Unique_SuggestionsByUser(string username, bool isReceiver);

        public Task<IQueryable<Vid_Gach_Unique_Suggestion>> GetVid_Gach_Unique_SuggestionsByUser(string username, bool isReceiver);

        public Task<IQueryable<Pblsr_Unique_Suggestion>> GetPblsr_Unique_SuggestionsByUser(string username, bool isReceiver);

        public Task<IQueryable<Prksn_Unique_Suggestion>> GetPrksn_Unique_SuggestionsByUser(string username, bool isReceiver);

        public Task<IQueryable<GPendingWorkView>> GetGPendingWorkFromView(string username);

        public Task<IQueryable<RoutineWorkView>> GetGRoutinWorkFromView(string username);

        public IQueryable<L_Remark_Master> GetL_Remark_MasterByUser(string username, bool isMain);

        public Task<IQueryable<BookIssueDetailView>> GetBookOverDueFromView();

        public Task<IQueryable<OverdueBookFollowupDetail>> GetFollowUpBookDue();

        public Task<IQueryable<ErrorDetailView>> GetErrorDetailsFromView(string username);

        public Task<IQueryable<Hp_Internal_Issue>> GetHpInternalIssueByUser(string username, int hpIssueType);

        public Task<IQueryable<UserAddUpdateScoreBoard_Response>> GetUserScoreBoardFromSP(UserScoreBoardFilterDto dataTableFilterDto, CancellationToken cancellationToken);

        public Task<IQueryable<L_DailyView>> GetDailyWorkLogsFromView(string username);

        public Task<DashboardCounts> GetDashboardCountsFromSP(string username, CancellationToken cancellationToken);
    }
}