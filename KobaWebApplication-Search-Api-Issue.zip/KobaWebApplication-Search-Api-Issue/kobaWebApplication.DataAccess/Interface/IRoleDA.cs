﻿using Microsoft.AspNetCore.Identity;
using KobaWebApplication.DataEntities.Models;

namespace KobaWebApplication.DataAccess.Interface
{
    public interface IRoleDA
    {
        public Task<Role> CreateRoleAsync(string roleName);
        public Task<Role?> GetRoleByIdAsync(int roleId);
        public Task<IQueryable<Role>> GetAllRolesAsync();
        public Task DeleteRoleAsync(int roleId);
    }
}