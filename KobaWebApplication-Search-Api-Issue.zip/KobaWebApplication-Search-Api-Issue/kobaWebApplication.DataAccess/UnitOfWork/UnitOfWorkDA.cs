using KobaWebApplication.DataAccess.Interface;
using KobaWebApplication.DataAccess.Repositories;
using KobaWebApplication.DataEntities;

namespace KobaWebApplication.DataAccess.UnitOfWork
{
    public class UnitOfWorkDA : IUnitOfWorkDA
    {
        private readonly ApplicationDbContext _context;

        public IUserDA UserDA { get; }
        public IRoleDA RoleDA { get; }
        public IRolePermissionDA RolePermissionDA { get; }
        public ILoginDA LoginDA { get; }
        public ILoginOptionDA LoginOptionDA { get; }
        public ICommonDA CommonDA { get; }
        public IHomeDA HomeDA { get; }

        public IUserRoleDA UserRoleDA { get; }
        public IHastPratDA HastPratDA { get; }
        public UnitOfWorkDA(ApplicationDbContext context, IUserDA userDA, IRoleDA roleDA, IRolePermissionDA rolePermissionDA, ILoginDA loginDA, ICommonDA commonDA, ILoginOptionDA loginOptionDA, IUserRoleDA userRoleDA, IHomeDA homeDA, IHastPratDA hastPratDA)
        {
            _context = context;
            UserDA = userDA;
            RoleDA = roleDA;
            RolePermissionDA = rolePermissionDA;
            LoginDA = loginDA;
            CommonDA = commonDA;
            LoginOptionDA = loginOptionDA;
            UserRoleDA = userRoleDA;
            HomeDA = homeDA;
            HastPratDA = hastPratDA;
        }

        #region TransactionMethod

        public async Task BeginTransactionAsync()
        {
            await _context.Database.BeginTransactionAsync();
        }

        public async Task CommitTransactionAsync()
        {
            await _context.Database.CommitTransactionAsync();
        }

        public async Task RollbackTransactionAsync()
        {
            await _context.Database.RollbackTransactionAsync();
        }

        #endregion TransactionMethod

        #region DisposeMethod

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion DisposeMethod
    }
}