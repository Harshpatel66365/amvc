using KobaWebApplication.DataAccess.Interface;
using KobaWebApplication.DataEntities.Models;

namespace KobaWebApplication.DataAccess.UnitOfWork
{
    public interface IUnitOfWorkDA
    {   
        IUserDA UserDA { get; }
        ILoginDA LoginDA { get; }
        ICommonDA CommonDA { get; }
        IRoleDA RoleDA { get; }
        IUserRoleDA UserRoleDA { get; }
        ILoginOptionDA LoginOptionDA { get; }
        IRolePermissionDA RolePermissionDA { get; }
        IHomeDA HomeDA { get; }
        IHastPratDA HastPratDA { get; }
               
        Task BeginTransactionAsync();

        Task CommitTransactionAsync();

        Task RollbackTransactionAsync();
    }
}