﻿using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;


namespace KobaWebApplication.Localization
{
    public class JsonStringLocalizerFactory : IStringLocalizerFactory
    {
        private readonly IDistributedCache _distributedCache;
       private readonly IConfiguration _configuration;


        public JsonStringLocalizerFactory(IDistributedCache distributedCache, IConfiguration configuration)
        {
            _distributedCache = distributedCache;
            _configuration = configuration;
        }

        public IStringLocalizer Create(Type resourceSource)
        {
            return new JsonStringLocalizer(_distributedCache, new Newtonsoft.Json.JsonSerializer(), new Microsoft.AspNetCore.Http.HttpContextAccessor(), _configuration);
        }

        public IStringLocalizer Create(string baseName, string location)
        {
            return new JsonStringLocalizer(_distributedCache, new Newtonsoft.Json.JsonSerializer(), new Microsoft.AspNetCore.Http.HttpContextAccessor(), _configuration);
        }
    }
}
