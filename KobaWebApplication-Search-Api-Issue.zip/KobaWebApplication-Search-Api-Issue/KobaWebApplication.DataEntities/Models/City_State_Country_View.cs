﻿namespace KobaWebApplication.DataEntities.Models
{
    public class City_State_Country_View
    {
        public string? City_Key { get; set; }
        public string? City_Nam { get; set; }
        public string? State_Name { get; set; }
        public string? Country_Name { get; set; }
    }
}
