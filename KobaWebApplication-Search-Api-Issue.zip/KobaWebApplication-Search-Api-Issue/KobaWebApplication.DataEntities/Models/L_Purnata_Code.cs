﻿namespace KobaWebApplication.DataEntities.Models
{
    public class L_Purnata_Code
    {
        public string? Purnata_Name { get; set; }
        public string? Purnata_Short_Name { get; set; }
        public string? For_Hp { get; set; }
    }
    public class L_Purnata_Remark_Code
    {
        public int Purnata_Remark_Code { get; set; }
        public string? Remark { get; set; }
    }
}
