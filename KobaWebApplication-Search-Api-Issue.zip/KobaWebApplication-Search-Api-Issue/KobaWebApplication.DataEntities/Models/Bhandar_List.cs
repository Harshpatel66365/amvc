﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KobaWebApplication.DataEntities.Models
{
    public class Bhandar_List
    {
        [Key]
        public string Bhandar_Code { get; set; }  //   NOT NULL

        public string Bhandar_Name { get; set; }  //   NOT NULL

        public string Bhandar_Short_Name { get; set; }  //   NOT NULL

        public string Prnt_Bhandar_Code { get; set; }  //   NULL

        public string Readership_lvl { get; set; }  //   NOT NULL

        public string Remark { get; set; }  //   NULL

        public string Short_Remark { get; set; }  //   NULL

        public string IsDefault { get; set; }  // [dbo].[YNType] NOT NULL

        public string Has_Hp { get; set; }  // [dbo].[YNType] NOT NULL

        public string Has_Book { get; set; }  // [dbo].[YNType] NOT NULL

        public string Has_EMedia { get; set; }  // [dbo].[YNType] NOT NULL

        public string Has_Magazine { get; set; }  // [dbo].[YNType] NOT NULL

        public string Has_Museum { get; set; }  // [dbo].[YNType] NOT NULL

        public string Hp_No { get; set; }  //   NULL

        public string Hp_Form_No { get; set; }  //   NULL

        public string Hp_Old_No { get; set; }  //   NULL

        public string Hp_Unit_Type_Short_Name { get; set; }  //   NULL

        public string Book_Accession_No { get; set; }  //   NULL

        public string Book_Vibhagiya_No { get; set; }  //   NULL

        public string Book_Unit_Type_Short_Name { get; set; }  //   NULL

        public string Mag_Ank_Copy_Accession_No { get; set; }  //   NULL

        public string Mag_Bind_No { get; set; }  //   NULL

        public string Mag_Unit_Type_Short_Name { get; set; }  //   NULL

        public string Antique_Accession_No { get; set; }  //   NULL

        public string Museum_Antique_Vibhagiya_No { get; set; }  //   NULL

        public string Museum_Unit_Type_Short_Name { get; set; }  //   NULL

        public int? Related_Tot_Book { get; set; }  // [int] NULL

        public int? Related_Tot_Emedia { get; set; }  // [int] NULL

        public int? Related_Tot_Vibhag { get; set; }  // [int] NULL

        public int? Related_Tot_Hp { get; set; }  // [int] NULL

        public int? Related_Tot_Mag_Ank_Copy { get; set; }  // [int] NULL

        public int? Related_Tot_Museum_Antique { get; set; }  // [int] NULL

        public string Add_Init { get; set; }  //   NOT NULL

        public string Updt_Init { get; set; }  //   NULL

        public string Last_Edtr { get; set; }  //   NULL

        public string Certifier { get; set; }  //   NULL

        public int? Updt_Authority_Level { get; set; }  // [int] NULL

        public int? Certifier_Authority_Level { get; set; }  // [int] NULL
    }
}
