﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KobaWebApplication.DataEntities.Models
{
    public class R_Message_List
    {
        public int Language_Id { get; set; }

        [Key]
        public int Message_Id { get; set; }

        public string Message { get; set; }

        public string Add_Init { get; set; }

        public string Updt_Init { get; set; }
    }

}
