﻿namespace KobaWebApplication.DataEntities.Models
{
    public class HP_PDF_LNK
    {
        public string Bhandar_Code { get; set; } // char(2), non-nullable
        public string Hp_No { get; set; } // nchar(14), non-nullable
        public string? Pdf_Image_150 { get; set; } // char(250), nullable
        public string? Pdf_Image_300 { get; set; } // char(250), nullable
        public string? Pdf_Text_Unicode { get; set; } // char(250), nullable
        public string? Pdf_Text_ThirdParty_font { get; set; } // char(250), nullable
        public string? Index_Detail { get; set; } // nvarchar(max), nullable
        public string? Index_File_Name { get; set; } // char(250), nullable
        public string? Add_Init { get; set; } // varchar(3), nullable
        public string? Updt_Init { get; set; } // varchar(3), nullable
        public string? Last_Edtr { get; set; } // varchar(3), nullable
        public string? Certifier { get; set; } // varchar(3), nullable
        public int? Updt_Authority_Level { get; set; } // int, nullable
        public int? Certifier_Authority_Level { get; set; } // int, nullable
        public string? Pdf_File_Source_150 { get; set; } // varchar(50), nullable
        public string? Pdf_File_Source_300 { get; set; } // varchar(50), nullable
        public string? Pdf_File_Source_Unicode { get; set; } // varchar(50), nullable
        public string? Pdf_File_Source_ThirdParty_font { get; set; } // varchar(50), nullable
        public DateTime? Add_Date_Time { get; set; } // datetime, nullable
        public DateTime? Updt_Date_Time { get; set; } // datetime, nullable
        public DateTime? Edit_Date_Time { get; set; } // datetime, nullable
        public DateTime? Certi_Date_Time { get; set; } // datetime, nullable
        public string? Remark { get; set; } // nvarchar(1000), nullable
    }
}