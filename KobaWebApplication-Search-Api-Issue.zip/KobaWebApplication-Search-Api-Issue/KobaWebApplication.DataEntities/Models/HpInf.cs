﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace KobaWebApplication.DataEntities.Models
{
    public class HpInf
    {
        [Key]
        [Column("Hp_No")]
        public string HpNo { get; set; } = string.Empty;
        [Key]
        [Column("Bhandar_Code")]
        public string BhandarCode { get; set; } = string.Empty;
        [Column("Form_No")]
        public string? FormNo { get; set; }
        [Column("Hp_Tot_Pet")]
        public string? HpTotPet { get; set; }
        [Column("Purnata_short_name")]
        public string? PurnataShortName { get; set; }
        [Column("Purnata_Remark_Code")]
        public int? PurnataRemarkCode { get; set; }
        [Column("Purnata_Remark")]
        public string? PurnataRemark { get; set; }
        [Column("Dasha_Short_Name")]
        public string? DashaShortName { get; set; }
        [Column("Dasha_Remark")]
        public string? DashaRemark { get; set; }
        [Column("Laksn_Code_String")]
        public string? LaksnCodeString { get; set; }
        [Column("Importance_Level_Code")]
        public string? ImportanceLevelCode { get; set; }
        [Column("Dasha_Code_String")]
        public string? DashaCodeString { get; set; }
        [Column("Hp_Vishesh")]
        public string? HpVishesh { get; set; }
        [Column("Prst_Pusp_Type_Short_Name")]
        public string? PrstPuspTypeShortName { get; set; }
        [Column("Prati_Pusp_Pariman_Count")]
        public string? PratiPuspParimanCount { get; set; }
        [Column("Hp_Parampara")]
        public string? HpParampara { get; set; }
        [Column("Pur_Don_Lot_No")]
        public int PurDonLotNo { get; set; }
        [Column("Old_No")]
        public string? OldNo { get; set; }
        [Column("Lipi_Short_Name")]
        public string? LipiShortName { get; set; }
        [Column("Material_Short_Name")]
        public string? MaterialShortName { get; set; }
        [Column("Hp_Type_Short_Name")]
        public string? HpTypeShortName { get; set; }
        [Column("Dharma_Code")]
        public string? DharmaCode { get; set; }
        [Column("Pgs_Last")]
        public int PgsLast { get; set; }
        [Column("Pgs_Ght")]
        public string? PgsGht { get; set; }
        [Column("Pgs_Ght_Tot")]
        public int? PgsGhtTot { get; set; }
        [Column("Pgs_Avst_Ght")]
        public string? PgsAvstGht { get; set; }
        [Column("Pgs_Avst_Ght_Tot")]
        public int? PgsAvstGhtTot { get; set; }
        [Column("Pgs_Bdth")]
        public string? PgsBdth { get; set; }
        [Column("Pgs_Bdth_Tot")]
        public int? PgsBdthTot {get; set; }
        [Column("Pgs_Net")]
        public int PgsNet { get; set; }
        [Column("Length_Min")]
        public decimal LengthMin { get; set; }
        [Column("Length_Max")]
        public decimal LengthMax { get; set; }
        [Column("Width_Min")]
        public decimal WidthMin { get; set; }
        [Column("Width_Max")]
        public decimal WidthMax { get; set; }
        [Column("Lines_Min")]
        public int LinesMin { get; set; }
        [Column("Lines_Max")]
        public int LinesMax { get; set; }
        [Column("Char_Min")]
        public int CharMin { get; set; }
        [Column("Char_Max")]
        public int CharMax { get; set; }
        [Column("Lekhan_Prakar_Short_Name")]
        public string? LekhanPrakarShortName { get; set; }
        
        [Column("Catalog_No")]
        public string? CatalogNo { get; set; }
        [Column("Del_Miss_Short_Name")]
        public string? DelMissShortName { get; set; }
        [Column("Related_Tot_Vidvan")]
        public int? RelatedTotVidvan { get; set; }
        [Column("Related_Tot_Kruti")]
        public int? RelatedTotKruti { get; set; }
        [Column("Related_Tot_Laksn")]
        public int? RelatedTotLaksn { get; set; }
        [Column("Related_Tot_Dasha_Detail_Codes")]
        public int? RelatedTotDashaDetailCodes { get; set; }
        [Column("Related_Tot_Nam")]
        public int? RelatedTotNam { get; set; }
        [Column("Related_Tot_Shlok")]
        public int? RelatedTotShlok { get; set; }
        [Column("Related_Tot_Year")]
        public int? RelatedTotYear { get; set; }
        [Column("Related_Tot_City")]
        public int? RelatedTotCity { get; set; }
        [Column("Related_Tot_Internal_Issue")]
        public int? RelatedTotInternalIssue { get; set; }
        [Column("Related_Tot_External_Issue")]
        public int? RelatedTotExternalIssue { get; set; }
        [Column("Related_Tot_Xerox_Issue")]
        public int? RelatedTotXeroxIssue { get; set; }
        [Column("Add_Init")]
        public string? AddInit { get; set; }
        [Column("Updt_Init")]
        public string? UpdtInit { get; set; }
        [Column("Last_Edtr")]
        public string? LastEdtr { get; set; }
        [Column("Certifier")]
        public string? Certifier { get; set; }
        [Column("Updt_Authority_Level")]
        public int? UpdtAuthorityLevel { get; set; }
        [Column("Certifier_Authority_Level")]
        public int? CertifierAuthorityLevel { get; set; }
        [Column("Add_Date_Time")]
        public DateTime? AddDateTime { get; set; }
        [Column("Updt_Date_Time")]
        public DateTime? UpdtDateTime { get; set; }
        [Column("Edit_Date_Time")]
        public DateTime? EditDateTime { get; set; }
        [Column("Certi_Date_Time")]
        public DateTime? CertiDateTime { get; set; }
        [Column("Readership_Lvl")]
        public char ReadershipLvl { get; set; }
    }
}