﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KobaWebApplication.DataEntities.Models
{
    public class User_Bhandar_Access_View
    {
        public string Bhandar_Code { get; set; }  // From dbo.S_User_Role_Lnk

        public string Usr_Init { get; set; }  // From dbo.L_User
    }

}
