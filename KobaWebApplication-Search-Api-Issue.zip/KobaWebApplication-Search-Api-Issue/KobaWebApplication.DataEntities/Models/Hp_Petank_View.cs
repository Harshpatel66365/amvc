﻿using System.ComponentModel.DataAnnotations;

namespace KobaWebApplication.DataEntities.Models
{
    public class Hp_Petank_View
    {
        [Required]
        [StringLength(20)]
        public string? Bhandar_Short_Name { get; set; }

        [Required]
        [StringLength(2, MinimumLength = 2)]
        public string? Bhandar_Code { get; set; }

        [Required]
        [StringLength(14)]
        public string? Hp_No { get; set; }

        [Required]
        [StringLength(4)]
        public string? Hp_Pet_Key { get; set; }

        [Required]
        public int Hp_Peta_No { get; set; }

        [Required]
        public bool Main_Petank { get; set; }  // Assuming `YNType` is represented by a `bool`

        [Required]
        [StringLength(22)]
        public string? Pet_Pages { get; set; }

        [StringLength(16)]
        public string? Purnata_Short_Name { get; set; }

        public int? Purnata_Remark_Code { get; set; }

        [StringLength(500)]
        public string? Purnata_Remark { get; set; }

        [StringLength(12)]
        public string? Prst_Pusp_Type_Short_Name { get; set; }

        [StringLength(200)]
        public string? Prati_Pusp_Pariman_Count { get; set; }

        [StringLength(1000)]
        public string? Remark { get; set; }

        [StringLength(1)]
        public string? Readership_Lvl { get; set; }

        [StringLength(6)]
        public string? Pet_Form_No { get; set; }

        public int? Related_Tot_Vidvan { get; set; }

        public int? Related_Tot_Nam { get; set; }

        public int? Related_Tot_Shlok { get; set; }

        public int? Related_Tot_Year { get; set; }

        public int? Related_Tot_City { get; set; }

        [Required]
        [StringLength(3)]
        public string? Add_Init { get; set; }

        [StringLength(3)]
        public string? Updt_Init { get; set; }

        [StringLength(3)]
        public string? Last_Edtr { get; set; }

        [StringLength(3)]
        public string? Certifier { get; set; }

        [StringLength(3600)]
        public string? Hp_Nam { get; set; }

        [StringLength(3600)]
        public string? Hp_Nam_filtered { get; set; }

        [StringLength(1)]
        public string? Main_Nam { get; set; }

        public bool? IsEnglish { get; set; }  // Assuming `YNType` is represented by a nullable `bool`

        [StringLength(12)]
        public string? Name_Type_Short_Name { get; set; }
    }

}
