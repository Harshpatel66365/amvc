﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KobaWebApplication.DataEntities.Models
{
    public class Bhandar_Group_Inf
    {
        [Key]
        public string Group_Short_Name { get; set; }

        public string Group_Name { get; set; }

        public string Readership_Lvl { get; set; }

        public string? Remark { get; set; }

        public string? Short_Remark { get; set; }

        //[Required]
        //public string IsDefault { get; set; } // Assuming YNType is a string

        public string Add_Init { get; set; }

        public string? Updt_Init { get; set; }

        public string? Last_Edtr { get; set; }

        public string? Certifier { get; set; }

        public int? Updt_Authority_Level { get; set; }

        public int? Certifier_Authority_Level { get; set; }
    }
}
