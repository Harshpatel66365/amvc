﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KobaWebApplication.DataEntities.Models
{
    public class R_Language
    {
        [Key]
        public int Language_ID { get; set; }

        public string Language_Name { get; set; }

        public string Remark { get; set; }

        public string Add_Init { get; set; }

        public string Updt_Init { get; set; }
        public string LanguageShortKey { get; set; }

    }
}
