﻿using System.ComponentModel.DataAnnotations;

namespace KobaWebApplication.DataEntities.Models
{
    public class Hp_Shlok_Lnk_View
    {
        [Required]
        [StringLength(2, MinimumLength = 2)]
        public string Bhandar_Code { get; set; }

        [Required]
        [StringLength(20)]
        public string Bhandar_Short_Name { get; set; }

        [Required]
        public int Shlok_No { get; set; }

        [Required]
        [StringLength(14)]
        public string Hp_No { get; set; }

        [StringLength(4)]
        public string Hp_Pet_Key { get; set; }

        [StringLength(12)]
        public string Kr_Key { get; set; }

        [Required]
        public int Shlok_Disp_Seq { get; set; }

        public int? Group_No { get; set; }

        [StringLength(400)]
        public string Pad1 { get; set; }

        [StringLength(400)]
        public string Pad2 { get; set; }

        [StringLength(400)]
        public string Pad3 { get; set; }

        [StringLength(400)]
        public string Pad4 { get; set; }

        [StringLength(400)]
        public string Pad5 { get; set; }

        [StringLength(400)]
        public string Pad6 { get; set; }

        [StringLength(1000)]
        public string Remark { get; set; }

        [StringLength(2420)]
        public string Shlok { get; set; }

        [Required]
        [StringLength(3)]
        public string Add_Init { get; set; }

        [StringLength(3)]
        public string Updt_Init { get; set; }

        [StringLength(3)]
        public string Last_Edtr { get; set; }

        [StringLength(3)]
        public string Certifier { get; set; }
    }

}
