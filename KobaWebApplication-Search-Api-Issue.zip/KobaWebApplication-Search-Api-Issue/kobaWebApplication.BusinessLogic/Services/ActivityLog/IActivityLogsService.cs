﻿using KobaWebApplication.DataEntities.Models;

namespace KobaWebApplication.BusinessLogic.Services.ActivityLog
{
    public interface IActivityLogsService
    {
        public Task<ActivityLogs> PerformActivityLog(int subjectTypeId, long subjectId, string description, string action, CancellationToken cancellationToken, string? remark = "", int createdBy = 0);
    }
}