﻿using Microsoft.AspNetCore.Http.HttpResults;
using KobaWebApplication.Core.Services.DateTimeParsing;
using KobaWebApplication.DataAccess.UnitOfWork;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto;

namespace KobaWebApplication.BusinessLogic.Services.ActivityLog
{
    public class ActivityLogsService : IActivityLogsService
    {
        private readonly IUnitOfWorkDA _unitOfWorkDA;

        public ActivityLogsService(IUnitOfWorkDA unitOfWorkDA)
        {
            _unitOfWorkDA = unitOfWorkDA;
        }

        public async Task<ActivityLogs> PerformActivityLog(int subjectTypeId, long subjectId, string description, string action, CancellationToken cancellationToken, string? remark, int createdBy)
        {
            var dataActivityLog = MapActivityLogs(subjectTypeId, subjectId, description, action, remark, createdBy);
            var activityLog = new ActivityLogs();//await _unitOfWorkDA.ActivityLogsDA.SaveActivityLogs(dataActivityLog, cancellationToken);
            return activityLog;
        }

        private ActivityLogs MapActivityLogs(int subjectTypeId, long subjectId, string description, string action, string? remark, int createdBy)
        {
            return new ActivityLogs()
            {
                SubjectTypeId = subjectTypeId,
                SubjectId = subjectId,
                Description = $"{description}",
                Action = action,
                Remarks = remark,
                CreatedBy = 0,
                CreatedDate = DateTimeOffset.Now,
                CreatedUTCDate = DateTime.UtcNow
            };
        }
    }
}