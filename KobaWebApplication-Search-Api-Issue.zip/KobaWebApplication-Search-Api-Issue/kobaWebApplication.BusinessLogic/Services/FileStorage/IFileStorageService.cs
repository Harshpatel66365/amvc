﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace KobaWebApplication.BusinessLogic.Services.FileStorage
{
    public interface IFileStorageService
    {
        Task<string> StoreFile(IFormFile file, string fileSavingPath);

        Task<bool> RemoveFile(string fileName);

        Task<string> UploadFileToS3Bucket(IFormFile file, string FolderName);

        Task<string> UploadFileToS3Bucket(MemoryStream file, string FolderName, int tenantId, string extension);

        Task<bool> DeleteFile(string FileName);
    }
}