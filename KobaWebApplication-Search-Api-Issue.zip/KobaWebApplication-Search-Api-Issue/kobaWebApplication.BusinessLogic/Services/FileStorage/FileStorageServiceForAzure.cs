﻿using Amazon.Runtime;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using Amazon.S3;
using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using KobaWebApplication.Core.CommonHelper;
using KobaWebApplication.Dto;
using Amazon;

namespace KobaWebApplication.BusinessLogic.Services.FileStorage
{
    public class FileStorageServiceForAzure : IFileStorageService
    {
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IConfiguration _configuration;

        public FileStorageServiceForAzure(IHostingEnvironment hostingEnvironment, IConfiguration configuration)
        {
            this._hostingEnvironment = hostingEnvironment;
            _configuration = configuration;
        }

        // Upload file to Azure
        public async Task<string> UploadFileToAzure(IFormFile file, string FolderName)
        {
            try
            {
                string url = string.Empty;
                string cdnPath = _configuration["AppSettings:Azure:CDNHostName"];

                using (var ms = new MemoryStream())
                {
                    string appendFolderName = "/" + FolderName;
                    FolderName = appendFolderName.Replace("\\", "/").Substring(0, appendFolderName.Length - 1);

                    string nameOfBlob = FolderName + "/" + CommonMethod.GetUniqueFileName(file.FileName);
                    BlobClient blobClient = new BlobClient(connectionString: _configuration["AppSettings:Azure:ConnectionString"], blobContainerName: _configuration["AppSettings:Azure:BlobContainerName"], blobName: nameOfBlob);
                    blobClient.Upload(file.OpenReadStream());

                    if (!String.IsNullOrEmpty(cdnPath))
                    {
                        url = cdnPath + "/" + blobClient.BlobContainerName + "/" + blobClient.Name + _configuration["AppSettings:Azure:PreSignedURL"];
                    }
                    else
                    {
                        url = Convert.ToString(blobClient.Uri) + _configuration["AppSettings:Azure:PreSignedURL"];
                    }
                }
                return url;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Delete file from Azure
        public async Task<bool> DeleteFileInAzure(string filePath)
        {
            try
            {
                BlobClient blobClient = new BlobClient(_configuration["AppSettings:AWS:ConnectionString"], _configuration["AppSettings:AWS:BlobContainerName"], filePath);
                await blobClient.DeleteIfExistsAsync();
                return true;
            }
            catch (Exception ex)
            {
                return false;
                throw ex;
            }
        }

        public async Task<string> StoreFile(IFormFile file, string fileSavingPath)
        {
            string uploadedImagePath = string.Empty;
            string path = _hostingEnvironment.WebRootPath + fileSavingPath;

            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);

            string fileName = Guid.NewGuid() + Path.GetExtension(file.FileName);
            using (var stream = new FileStream(path + fileName, FileMode.Create))
            {
                await file.CopyToAsync(stream);
                uploadedImagePath = fileSavingPath + fileName;
            }
            return uploadedImagePath;
        }

        public async Task<bool> RemoveFile(string fileName)
        {
            string path = _hostingEnvironment.WebRootPath + fileName;
            if (File.Exists(path))
            {
                File.Delete(path);
                return true;
            }
            return false;
        }

        // Upload file to s3 bucket
        public async Task<string> UploadFileToS3Bucket(IFormFile file, string FolderName)
        {
            string url = string.Empty;
            try
            {
                string cdnPath = _configuration["AppSettings:Azure:CDNHostName"];

                using (var ms = new MemoryStream())
                {
                    string appendFolderName = "/" + FolderName;
                    FolderName = appendFolderName.Replace("\\", "/").Substring(0, appendFolderName.Length - 1);

                    string nameOfBlob = FolderName + "/" + CommonMethod.GetUniqueFileName(file.FileName); //file.FileName + "." + file.ContentType.Split("/")[1]
                    BlobClient blobClient = new BlobClient(connectionString: _configuration["AppSettings:Azure:ConnectionString"], blobContainerName: _configuration["AppSettings:Azure:BlobContainerName"], blobName: nameOfBlob);
                    blobClient.Upload(file.OpenReadStream());

                    if (!String.IsNullOrEmpty(cdnPath))
                    {
                        url = cdnPath + "/" + blobClient.BlobContainerName + "/" + blobClient.Name + _configuration["AppSettings:Azure:PreSignedURL"];
                    }
                    else
                    {
                        url = Convert.ToString(blobClient.Uri) + _configuration["AppSettings:Azure:PreSignedURL"];
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return url;
        }

        public async Task<string> UploadFileToS3Bucket(MemoryStream file, string FolderName, int tenantId, string extension)
        {
            string url = string.Empty;
            try
            {
                string cdnPath = _configuration["AppSettings:Azure:CDNHostName"];

                using (var ms = new MemoryStream())
                {
                    string appendFolderName = "/" + tenantId + FolderName;
                    FolderName = appendFolderName.Replace("\\", "/").Substring(0, appendFolderName.Length - 1);

                    string nameOfBlob = FolderName + "/" + CommonMethod.GetUniqueFileName(tenantId.ToString()) + extension;
                    BlobClient blobClient = new BlobClient(connectionString: _configuration["AppSettings:Azure:ConnectionString"], blobContainerName: _configuration["AppSettings:Azure:BlobContainerName"], blobName: nameOfBlob);
                    file.Position = 0;
                    blobClient.Upload(file);

                    if (!String.IsNullOrEmpty(cdnPath))
                    {
                        url = cdnPath + "/" + blobClient.BlobContainerName + "/" + blobClient.Name + _configuration["AppSettings:Azure:PreSignedURL"];
                    }
                    else
                    {
                        url = Convert.ToString(blobClient.Uri) + _configuration["AppSettings:Azure:PreSignedURL"];
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return url;
        }

        //Delete file from s3 bucket
        public async Task<bool> DeleteFile(string filePath)
        {
            return true;
            string S3AccessKey = _configuration["AppSettings:S3Bucket:S3AccessKey"];
            string S3SecretKey = _configuration["AppSettings:S3Bucket:S3SecretKey"];
            string S3StorageBucketName = _configuration["AppSettings:S3Bucket:S3StorageBucketName"];
            try
            {
                if (!string.IsNullOrEmpty(filePath))
                {
                    var amazonClient = new AmazonS3Client(S3AccessKey, S3SecretKey, RegionEndpoint.USEast1);
                    var deleteObjectRequest = new DeleteObjectRequest { BucketName = S3StorageBucketName, Key = filePath.Split('?')[0].Split('/')[4] + "/" + filePath.Split('?')[0].Split('/')[5] + "/" + filePath.Split('?')[0].Split('/')[6] };
                    var response = await amazonClient.DeleteObjectAsync(deleteObjectRequest);
                    if (response != null)
                        return true;
                    else
                        return false;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}