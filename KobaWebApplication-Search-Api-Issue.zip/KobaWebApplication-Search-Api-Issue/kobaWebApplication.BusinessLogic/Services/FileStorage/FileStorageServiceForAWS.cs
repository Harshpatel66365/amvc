﻿using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using KobaWebApplication.Core.CommonHelper;
using KobaWebApplication.Dto;

namespace KobaWebApplication.BusinessLogic.Services.FileStorage
{
    public class FileStorageServiceForAWS : IFileStorageService
    {
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IConfiguration _configuration;

        public FileStorageServiceForAWS(IHostingEnvironment hostingEnvironment, IConfiguration configuration)
        {
            this._hostingEnvironment = hostingEnvironment;
            _configuration = configuration;
        }

        public async Task<string> StoreFile(IFormFile file, string fileSavingPath)
        {
            string uploadedImagePath = string.Empty;
            string path = _hostingEnvironment.WebRootPath + fileSavingPath;

            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);

            string fileName = Guid.NewGuid() + Path.GetExtension(file.FileName);
            using (var stream = new FileStream(path + fileName, FileMode.Create))
            {
                await file.CopyToAsync(stream);
                uploadedImagePath = fileSavingPath + fileName;
            }
            return uploadedImagePath;
        }

        public async Task<bool> RemoveFile(string fileName)
        {
            string path = _hostingEnvironment.WebRootPath + fileName;
            if (File.Exists(path))
            {
                File.Delete(path);
                return true;
            }
            return false;
        }

        // Upload file to s3 bucket
        public async Task<string> UploadFileToS3Bucket(IFormFile file, string FolderName)
        {
            string url = string.Empty;
            using (var ms = new MemoryStream())
            {
                var uniqueFileName = CommonMethod.GetUniqueFileName(file.FileName);

                file.CopyTo(ms);
                var fileBytes = ms.ToArray();

                string appendFolderName = "/" + FolderName;
                FolderName = appendFolderName.Replace("\\", "/").Substring(0, appendFolderName.Length - 1);
                string S3AccessKey = _configuration["AppSettings:S3Bucket:S3AccessKey"];
                string S3SecretKey = _configuration["AppSettings:S3Bucket:S3SecretKey"];
                string S3StorageBucketName = _configuration["AppSettings:S3Bucket:S3StorageBucketName"];

                try
                {
                    AmazonS3Client clientS3 = new AmazonS3Client(S3AccessKey, S3SecretKey, RegionEndpoint.USEast1);
                    AWSCredentials credentials = new BasicAWSCredentials(S3AccessKey, S3SecretKey);
                    IAmazonS3 client = new AmazonS3Client(credentials, RegionEndpoint.USEast1);
                    TransferUtility utility = new TransferUtility(client);
                    TransferUtilityUploadRequest request = new TransferUtilityUploadRequest();
                    if (!string.IsNullOrEmpty(FolderName))
                        request.BucketName = S3StorageBucketName + FolderName;
                    else
                        request.BucketName = S3StorageBucketName;
                    request.Key = uniqueFileName;
                    request.InputStream = ms;
                    utility.Upload(request);
                    GetPreSignedUrlRequest requestUrl = new GetPreSignedUrlRequest();
                    if (!string.IsNullOrEmpty(FolderName))
                        requestUrl.BucketName = S3StorageBucketName + FolderName;
                    else
                        requestUrl.BucketName = S3StorageBucketName;
                    requestUrl.Key = uniqueFileName;
                    requestUrl.Expires = DateTime.Now.AddYears(10);
                    requestUrl.Protocol = Protocol.HTTPS;
                    url = client.GetPreSignedURL(requestUrl);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return url;
        }

        //Delete file from s3 bucket
        public async Task<bool> DeleteFile(string filePath)
        {
            return true;
            string S3AccessKey = _configuration["AppSettings:S3Bucket:S3AccessKey"];
            string S3SecretKey = _configuration["AppSettings:S3Bucket:S3SecretKey"];
            string S3StorageBucketName = _configuration["AppSettings:S3Bucket:S3StorageBucketName"];
            try
            {
                if (!string.IsNullOrEmpty(filePath))
                {
                    var amazonClient = new AmazonS3Client(S3AccessKey, S3SecretKey, RegionEndpoint.USEast1);
                    var deleteObjectRequest = new DeleteObjectRequest { BucketName = S3StorageBucketName, Key = filePath.Split('?')[0].Split('/')[4] + "/" + filePath.Split('?')[0].Split('/')[5] + "/" + filePath.Split('?')[0].Split('/')[6] };
                    var response = await amazonClient.DeleteObjectAsync(deleteObjectRequest);
                    if (response != null)
                        return true;
                    else
                        return false;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task<string> UploadFileToAzure(MemoryStream file, string FolderName, string Key)
        {
            throw new NotImplementedException();
        }

        public Task<string> UploadFileToS3Bucket(MemoryStream file, string FolderName, int tenantId, string extension)
        {
            throw new NotImplementedException();
        }
    }
}