﻿using KobaWebApplication.Dto.DataGrid;
using KobaWebApplication.Dto.Role;
using KobaWebApplication.Dto.RolePermission;

namespace KobaWebApplication.BusinessLogic.Interface
{
    public interface IRoleBL
    {
        public Task<RolesDetailsDto> GetRoleByIdAsync(int roleId);
        public Task<List<RolesDetailsDto>> GetAllRolesAsync();
        public Task CreateRole(string roleName);
        public Task DeleteRoleAsync(int roleId);
        public Task<RoleRequestDto> GetRoleNameID(int Id, List<RolePermissionResponseDto> rolePermissionResponseDto);
        public Task<JsonRepsonse<RolesDetailsDto>> GetRoleDataTable(RoleDataTableFilterDto dataTableFilterDto);
    }
}