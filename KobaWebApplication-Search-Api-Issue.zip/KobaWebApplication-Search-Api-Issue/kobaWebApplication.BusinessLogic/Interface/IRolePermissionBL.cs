﻿using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.RolePermission;

namespace KobaWebApplication.BusinessLogic.Interface
{
    public interface IRolePermissionBL
    {
        public Task<IEnumerable<RoleClaim>> GetClaimsByRoleIdAsync(int roleId);
        public Task AddClaimToRoleAsync(int roleId, string claimType, string claimValue);
        public Task RemoveClaimToRoleAsync(int roleId, string claimType, string claimValue);
        public Task<List<RolePermissionResponseDto>> GetRolePermissions(string Id, List<string> allPermissions);
    }
}