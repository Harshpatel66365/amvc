﻿using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.AdvanceSearch;
using KobaWebApplication.Dto.Browser;
using KobaWebApplication.Dto.DataGrid;
using KobaWebApplication.Dto.localization;

namespace KobaWebApplication.BusinessLogic.Interface
{
    public interface ICommonBL
    {
        public void InsertUserTechnicalData(string userId, string machineName, string ProcType, string ActionType);

        public List<LocalizationViewModel> GetLocalizationData();
    }
}