﻿using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.DataGrid;
using KobaWebApplication.Dto.Login;
using KobaWebApplication.Dto.Role;
using KobaWebApplication.Dto.RolePermission;
using KobaWebApplication.Dto.User;
using Microsoft.AspNetCore.Http;

namespace KobaWebApplication.BusinessLogic.Interface
{
    public interface ILoginBL
    {
        public bool ValidateUser(string username, string password, out string message);

        public SessionDataDto GetUserSession(string username, HttpContext httpContext);

        public void LogoutUser(string userId);
    }
}