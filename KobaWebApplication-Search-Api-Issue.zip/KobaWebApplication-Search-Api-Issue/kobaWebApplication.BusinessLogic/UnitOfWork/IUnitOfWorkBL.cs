﻿using KobaWebApplication.BusinessLogic.Interface;
using KobaWebApplication.BusinessLogic.Services.ActivityLog;
using KobaWebApplication.BusinessLogic.Services.FileStorage;
using KobaWebApplication.Core.Services.Email;

namespace KobaWebApplication.BusinessLogic.UnitOfWork
{
    public interface IUnitOfWorkBL
    {
        IRoleBL RoleBL { get; }
        IUserRoleBL UserRoleBL { get; }
        ILoginBL LoginBL { get; }
        ILoginOptionBL LoginOptionBL { get; }
        ICommonBL CommonBL { get; }
        IRolePermissionBL RolePermissionBL { get; }
        IFileStorageService FileStorageService { get; }
        IActivityLogsService ActivityLogsService { get; }
        IEmailHelper EmailHelper { get; }
        IHomeBL HomeBL { get; }
        IUserBL UserBL { get; }
        IBrowserBL BrowserBL { get; }
        IHastPratBL HastPratBL { get; }
    }
}