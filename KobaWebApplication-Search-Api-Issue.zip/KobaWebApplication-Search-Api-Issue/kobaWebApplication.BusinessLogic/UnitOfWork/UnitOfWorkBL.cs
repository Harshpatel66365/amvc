﻿using KobaWebApplication.BusinessLogic.Interface;
using KobaWebApplication.BusinessLogic.Services.ActivityLog;
using KobaWebApplication.BusinessLogic.Services.FileStorage;
using KobaWebApplication.Core.Services.Email;
using KobaWebApplication.DataEntities;

namespace KobaWebApplication.BusinessLogic.UnitOfWork
{
    public class UnitOfWorkBL : IUnitOfWorkBL
    {
        private readonly ApplicationDbContext _context;
        public IFileStorageService FileStorageService { get; }
        public IRoleBL RoleBL { get; }
        public IRolePermissionBL RolePermissionBL { get; }
        public IActivityLogsService ActivityLogsService { get; }
        public IEmailHelper EmailHelper { get; }
        public ILoginBL LoginBL { get; }
        public ICommonBL CommonBL { get; }
        public ILoginOptionBL LoginOptionBL { get; }
        public IHomeBL HomeBL { get; }

        public IUserRoleBL UserRoleBL { get; }

        public IUserBL UserBL { get; }

        public IBrowserBL BrowserBL { get; set; }
        public IHastPratBL HastPratBL { get; set; }

        public UnitOfWorkBL(ApplicationDbContext context, IRoleBL roleBL, IRolePermissionBL rolePermissionBL, IActivityLogsService activityLogsService, IEmailHelper emailHelper, IFileStorageService fileStorageService, ILoginBL loginBL, ICommonBL commonBL, ILoginOptionBL loginOptionBL, IUserRoleBL userRoleBL, IHomeBL homeBL, IUserBL userBL, IBrowserBL browserBL, IHastPratBL hastPratBL)
        {
            _context = context;
            FileStorageService = fileStorageService;
            RoleBL = roleBL;
            RolePermissionBL = rolePermissionBL;
            ActivityLogsService = activityLogsService;
            LoginBL = loginBL;
            CommonBL = commonBL;
            LoginOptionBL = loginOptionBL;
            UserRoleBL = userRoleBL;
            HomeBL = homeBL;
            UserBL = userBL;
            BrowserBL = browserBL;
            HastPratBL = hastPratBL;
        }

        #region DisposeMethod

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion DisposeMethod
    }
}