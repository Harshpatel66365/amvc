﻿using Mapster;
using Microsoft.Extensions.DependencyInjection;
using KobaWebApplication.BusinessLogic.Interface;
using KobaWebApplication.BusinessLogic.Repositories;
using KobaWebApplication.BusinessLogic.Services.ActivityLog;
using KobaWebApplication.BusinessLogic.UnitOfWork;
using KobaWebApplication.Core.Services.Email;
using KobaWebApplication.Core.Services.Kafka.Producer;
using KobaWebApplication.Dto;
using System.Reflection;

namespace KobaWebApplication.BusinessLogic.Extention
{
    public static class SetupBusinessLogic
    {
        public static void SetupUnitOfWorkBL(this IServiceCollection services)
        {
            services.AddScoped<IRoleBL, RoleBL>();
            services.AddScoped<ILoginBL, LoginBL>();
            services.AddScoped<ICommonBL, CommonBL>();
            services.AddScoped<ILoginOptionBL, LoginOptionBL>();
            services.AddScoped<IRolePermissionBL, RolePermissionBL>();
            services.AddScoped<IHomeBL, HomeBL>();
            services.AddScoped<IUserBL, UserBL>();

            services.AddScoped<IUserRoleBL, UserRoleBL>();
            services.AddScoped<IBrowserBL, BrowserBL>();
            services.AddScoped<IHastPratBL, HastPratBL>();

            services.AddScoped<IActivityLogsService, ActivityLogsService>();

            services.AddScoped<IEmailHelper, EmailHelper>();

            services.AddSingleton<IKafkaProducerService, KafkaProducerService>();

            //services.AddScoped<ITanyoChatBotBL, TanyoChatBotBL>();

            //KEEP THIS LINE AT THE BOTTOM
            services.AddScoped<IUnitOfWorkBL, UnitOfWorkBL>();
        }

        public static void SetupAutoMapper(this IServiceCollection services)
        {
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
        }

        public static void AddMapster(this IServiceCollection services)
        {
            var typeAdapterConfig = TypeAdapterConfig.GlobalSettings;
            Assembly applicationAssembly = typeof(BaseDto<,>).Assembly;
            typeAdapterConfig.Scan(applicationAssembly);
        }
    }
}