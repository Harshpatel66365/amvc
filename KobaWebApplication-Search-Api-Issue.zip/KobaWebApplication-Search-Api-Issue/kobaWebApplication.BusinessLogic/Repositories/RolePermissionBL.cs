﻿using Microsoft.AspNetCore.Identity;
using KobaWebApplication.BusinessLogic.Interface;
using KobaWebApplication.Core.Constants;
using KobaWebApplication.DataAccess.UnitOfWork;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto;
using KobaWebApplication.Dto.APIResponse;
using KobaWebApplication.Dto.RolePermission;
using System.Security.Claims;

namespace KobaWebApplication.BusinessLogic.Repositories
{
    public class RolePermissionBL : IRolePermissionBL
    {
        private readonly IUnitOfWorkDA _unitOfWorkDA;

        public RolePermissionBL(IUnitOfWorkDA unitOfWorkDA)
        {
            _unitOfWorkDA = unitOfWorkDA;
        }
        public async Task<IEnumerable<RoleClaim>> GetClaimsByRoleIdAsync(int roleId)
        {
            return await _unitOfWorkDA.RolePermissionDA.GetClaimsForRoleAsync(roleId);
        }

        public async Task AddClaimToRoleAsync(int roleId, string claimType, string claimValue)
        {
            await _unitOfWorkDA.RolePermissionDA.AddClaimToRoleAsync(roleId, claimType, claimValue);
        }
        public async Task RemoveClaimToRoleAsync(int roleId, string claimType, string claimValue)
        {
            await _unitOfWorkDA.RolePermissionDA.RemoveClaimToRoleAsync(roleId, claimType, claimValue);
        }
        public async Task<List<RolePermissionResponseDto>> GetRolePermissions(string Id, List<string> allPermissions)
        {
            var allClaimsByRole = await GetClaimsByRoleIdAsync(Convert.ToInt32(Id));
            List<RolePermissionResponseDto> RolePermissionResponseDto = new List<RolePermissionResponseDto>();
            foreach (var item in allPermissions)
            {
                RolePermissionResponseDto moduleResponseDtoChild = RolePermissionResponseDto.FirstOrDefault(p => p.ApplicationType == item.Split(".")[1]);
                if (moduleResponseDtoChild == null)
                {
                    moduleResponseDtoChild = new RolePermissionResponseDto();
                    moduleResponseDtoChild.ApplicationType = item.Split(".")[1];
                    moduleResponseDtoChild.RolePermissionList = new List<PermissiongResponseDto>();
                    RolePermissionResponseDto.Add(moduleResponseDtoChild);
                }
                PermissiongResponseDto permissionResponseDto = new PermissiongResponseDto();
                permissionResponseDto.Id = item.Split(".")[2] + item.Split(".")[3];
                permissionResponseDto.Module = item.Split(".")[2];
                permissionResponseDto.PermissionType = item.Split(".")[3];
                permissionResponseDto.Permission = item;
                if (allClaimsByRole.Any(x => x.ClaimValue == item))
                    permissionResponseDto.IsChecked = "checked";
                moduleResponseDtoChild.RolePermissionList.Add(permissionResponseDto);
            }
            return RolePermissionResponseDto;
        }
    }
}