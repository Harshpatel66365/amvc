﻿using KobaWebApplication.BusinessLogic.Interface;
using KobaWebApplication.DataAccess.UnitOfWork;
using Microsoft.AspNetCore.Http;
using KobaWebApplication.Core.Common;
using KobaWebApplication.Dto.Login;

namespace KobaWebApplication.BusinessLogic.Repositories
{
    public class LoginBL : ILoginBL
    {
        private readonly IUnitOfWorkDA _unitOfWorkDA;

        public LoginBL(IUnitOfWorkDA unitOfWorkDA)
        {
            _unitOfWorkDA = unitOfWorkDA;
        }

        public bool ValidateUser(string username, string password, out string message)
        {
            message = string.Empty;

            // Check with encrypted password
            string encryptedPassword = MagnusMindsCommon.g_Pwd_Encrypt(password);
            var user = _unitOfWorkDA.LoginDA.GetUserByEncryptedCredentials(username, encryptedPassword);

            if (user != null)
            {
                if (user.Working_Type == "X")
                {
                    message = "Please contact Administrator.\r\nYou are a past user.";
                    return false;
                }

                return true;
            }

            message = "Invalid login credentials.";
            return false;
        }

        public SessionDataDto GetUserSession(string username, HttpContext httpContext)
        {
            var sessionValues = _unitOfWorkDA.LoginDA.GetUserSessionValues(username);

            return sessionValues;
        }

        public void LogoutUser(string userId)
        {
            // Update the logout time
            _unitOfWorkDA.LoginDA.UpdateLogoutTime(userId);
        }
    }
}