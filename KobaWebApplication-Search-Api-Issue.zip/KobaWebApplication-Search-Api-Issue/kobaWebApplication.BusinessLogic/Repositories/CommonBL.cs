﻿using AutoMapper;
using KobaWebApplication.BusinessLogic.Interface;
using KobaWebApplication.DataAccess.UnitOfWork;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.AdvanceSearch;
using KobaWebApplication.Dto.Browser;
using KobaWebApplication.Dto.DataGrid;
using KobaWebApplication.Dto.localization;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Text;

namespace KobaWebApplication.BusinessLogic.Repositories
{
    public class CommonBL : ICommonBL
    {
        private readonly IUnitOfWorkDA _unitOfWorkDA;
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly IMapper _mapper;

        public CommonBL(IUnitOfWorkDA unitOfWorkDA, IWebHostEnvironment hostingEnvironment, IMapper mapper)
        {
            _unitOfWorkDA = unitOfWorkDA;
            _hostingEnvironment = hostingEnvironment;
            _mapper = mapper;
        }

        public void InsertUserTechnicalData(string userId, string machineName, string ProcType, string ActionType)
        {
            _unitOfWorkDA.CommonDA.InsertUserTechnicalData(userId, machineName, ProcType, ActionType);
        }

        public List<LocalizationViewModel> GetLocalizationData()
        {
            var localizationList = new List<LocalizationViewModel>();

            var enJsonPath = Path.Combine(_hostingEnvironment.ContentRootPath, "Resources", "en.json");
            var guJsonPath = Path.Combine(_hostingEnvironment.ContentRootPath, "Resources", "gu.json");
            var hiJsonPath = Path.Combine(_hostingEnvironment.ContentRootPath, "Resources", "hi.json");
            var descJsonPath = Path.Combine(_hostingEnvironment.ContentRootPath, "Resources", "description.json");

            var enJson = JObject.Parse(File.ReadAllText(enJsonPath));
            var guJson = JObject.Parse(File.ReadAllText(guJsonPath));
            var hiJson = JObject.Parse(File.ReadAllText(hiJsonPath));
            var descJson = JObject.Parse(File.ReadAllText(descJsonPath));

            foreach (var key in enJson.Properties())
            {
                localizationList.Add(new LocalizationViewModel
                {
                    Key = key.Name,
                    Description = descJson[key.Name]?.ToString(),
                    English = enJson[key.Name]?.ToString(),
                    Gujarati = guJson[key.Name]?.ToString(),
                    Hindi = hiJson[key.Name]?.ToString()
                });
            }

            return localizationList;
        }

      
    }
}