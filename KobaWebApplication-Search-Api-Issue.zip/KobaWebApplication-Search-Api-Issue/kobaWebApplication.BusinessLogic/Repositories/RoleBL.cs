﻿using AutoMapper;
using KobaWebApplication.BusinessLogic.Interface;
using KobaWebApplication.DataAccess.UnitOfWork;
using KobaWebApplication.Dto.DataGrid;
using KobaWebApplication.Dto.Role;
using KobaWebApplication.Dto.RolePermission;
using System.Linq.Dynamic.Core;

namespace KobaWebApplication.BusinessLogic.Repositories
{
    public class RoleBL : IRoleBL
    {
        private readonly IUnitOfWorkDA _unitOfWorkDA;
        private readonly IMapper _mapper;

        public RoleBL(IUnitOfWorkDA unitOfWorkDA, IMapper mapper)
        {
            _unitOfWorkDA = unitOfWorkDA;
            _mapper = mapper;
        }

        public async Task<RolesDetailsDto> GetRoleByIdAsync(int roleId)
        {
            var Role = await _unitOfWorkDA.RoleDA.GetRoleByIdAsync(roleId);
            return _mapper.Map<RolesDetailsDto>(Role);
        }

        public async Task<List<RolesDetailsDto>> GetAllRolesAsync()
        {
            var Roles =  await _unitOfWorkDA.RoleDA.GetAllRolesAsync();
            return _mapper.Map<List<RolesDetailsDto>>(Roles).ToList();
        }

        public async Task CreateRole(string roleName)
        {
            await _unitOfWorkDA.RoleDA.CreateRoleAsync(roleName);
        }

        public async Task DeleteRoleAsync(int roleId)
        {
            await _unitOfWorkDA.RoleDA.DeleteRoleAsync(roleId);
        }
        public async Task<RoleRequestDto> GetRoleNameID(int Id, List<RolePermissionResponseDto> rolePermissionResponseDto)
        {
            RoleRequestDto mRoleRequestDto = new RoleRequestDto();
            var roleData = await GetAllRolesAsync();
            var roleName = roleData.Where(x => x.Id == Id).Select(n => n.Name).FirstOrDefault();
            mRoleRequestDto.Id = Id.ToString();
            mRoleRequestDto.Name = roleName;
            mRoleRequestDto.ModulePermissionList.AddRange(rolePermissionResponseDto);
           
            return mRoleRequestDto;
        }
        public async Task<JsonRepsonse<RolesDetailsDto>> GetRoleDataTable(RoleDataTableFilterDto dataTableFilterDto)
        {
            try
            {
                var resultData = await _unitOfWorkDA.RoleDA.GetAllRolesAsync();

                if (!string.IsNullOrEmpty(dataTableFilterDto.Search.value))
                {
                    var searchTerm = dataTableFilterDto.Search.value.ToLower();
                    resultData = resultData.Where(x =>
                        x.Name.ToLower().Contains(searchTerm));
                }

                var sortBy = dataTableFilterDto.MapOrderBy(dataTableFilterDto.Order[0].column);
                var sortOrder = dataTableFilterDto.Order[0].dir;
                resultData = sortOrder == "asc" ? resultData.OrderBy(sortBy) : resultData.OrderBy($"{sortBy} descending");

                var totalRecords = resultData.Count();

                var paginatedData = resultData
                .Skip(dataTableFilterDto.Start)
                .Take(dataTableFilterDto.PageSize)
                .ToList();

                var rolesResult = _mapper.Map<List<RolesDetailsDto>>(paginatedData);

                return new JsonRepsonse<RolesDetailsDto>(dataTableFilterDto.Draw, totalRecords, totalRecords, rolesResult);
            }
            catch (Exception ex)
            {
                return new JsonRepsonse<RolesDetailsDto>(dataTableFilterDto.Draw, 0, 0, new List<RolesDetailsDto>());
            }
        }

        
    }
}