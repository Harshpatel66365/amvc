﻿namespace KobaWebApplication.Models
{
    public class LoginOptionsModel
    {
        public string Option { get; set; }
        public string BhandarGroup { get; set; }
        public string BhandarList { get; set; }
        public string Language { get; set; }
        public string Remark { get; set; }
    }

    public class BhandarViewModel
    {
        public string BhandarCode { get; set; }
        public string BhandarName { get; set; }
        public string IsDefault{ get; set; }
    }

    public class BhandarGroupViewModel
    {
        public string GroupCode { get; set; }
        public string GroupName { get; set; }
    }

    public class LanguageViewModel
    {
        public string LanguageName { get; set; }
        public string LanguageShortKey { get; set; }

    }

}
