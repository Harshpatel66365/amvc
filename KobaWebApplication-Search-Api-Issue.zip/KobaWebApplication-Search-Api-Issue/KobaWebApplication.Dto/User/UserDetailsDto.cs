﻿using KobaWebApplication.Dto.DataGrid;

namespace KobaWebApplication.Dto.User
{
    public class UserDetailsDto
    {
        public int Id { get; set; }
        public string Usr_Init { get; set; } 

        public string Usr_Name { get; set; } 

        public string Pwd { get; set; } 

        public string Designation { get; set; } 

        public string? Main_Work { get; set; }

        public string Address1 { get; set; } 

        public string? Address2 { get; set; }

        public string? Address3 { get; set; }

        public string? City_Key { get; set; }

        public string? Pincode { get; set; }

        public string Permanent_Address { get; set; } 

        public string? Other_Contact_Address { get; set; }

        public string? Phone { get; set; }

        public string? Fax { get; set; }

        public string? Mobile { get; set; }

        public string? Email { get; set; }

        public string? Blood_Group { get; set; }

        public byte[]? Photo { get; set; }

        public string? Working_Type { get; set; }

        public string? Home_Dir { get; set; }

        public string? Hp_Readership_lvl { get; set; }

        public string? Kr_Readership_lvl { get; set; }

        public string? Prksn_Readership_lvl { get; set; }

        public string? Book_Readership_lvl { get; set; }

        public string? EMedia_Readership_lvl { get; set; }

        public string? EMedia_Vibhag_Readership_lvl { get; set; }

        public string? Mag_Readership_lvl { get; set; }

        public string? Remark { get; set; }

        public string? Add_Init { get; set; }

        public string? Updt_Init { get; set; }

        public string? Last_Edtr { get; set; }

        public string? Certifier { get; set; }

        public int? Updt_Authority_Level { get; set; }

        public int? Certifier_Authority_Level { get; set; }
    }
    public class UserFilterDto : DataTableFilterDto
    {
        public string WorkingType { get; set; }
        public string MapOrderBy(int orderbyColumn)
        {

            switch (orderbyColumn)
            {
                case 0: return "usr_Name";
                case 1: return "usr_Init";
                case 2: return "designation";
                case 3: return "main_Work";
                case 4: return "permanent_Address";
                case 5: return "Id";
                case 6: return "Working_Type";
                default: return "usr_Name";
            }
        }
    }
}
