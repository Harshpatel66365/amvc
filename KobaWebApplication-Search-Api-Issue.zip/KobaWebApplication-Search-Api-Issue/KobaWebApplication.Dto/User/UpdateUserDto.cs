﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KobaWebApplication.Dto.User
{
    public class UpdateUserDto
    {
        public int Id { get; set; } // Hidden field to identify the user
        public string Usr_Name { get; set; } // Editable
        public string Permanent_Address { get; set; } // Editable
    }
}
