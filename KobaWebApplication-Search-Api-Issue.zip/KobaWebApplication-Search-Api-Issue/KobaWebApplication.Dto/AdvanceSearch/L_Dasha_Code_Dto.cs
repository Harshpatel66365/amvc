﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KobaWebApplication.Dto.AdvanceSearch
{
    public class L_Dasha_Code_Dto
    {
        public string? Dasha_name { get; set; }
        public string? Dasha_Short_Name { get; set; }
        public string? For_Other { get; set; }
    }
}
