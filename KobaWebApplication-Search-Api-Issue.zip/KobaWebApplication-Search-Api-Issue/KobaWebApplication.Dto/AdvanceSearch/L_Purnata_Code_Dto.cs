﻿namespace KobaWebApplication.Dto.AdvanceSearch
{
    public class L_Purnata_Code_Dto
    {
        public string? Purnata_Name { get; set; }
        public string? Purnata_Short_Name { get; set; }
        public string? For_Hp { get; set; }
        //public string? For_Other { get; set; }
    }
    public class L_Purnata_Remark_Code_Dto
    {
        public int Purnata_Remark_Code { get; set; }
        public string? Remark { get; set; }
    }
}
