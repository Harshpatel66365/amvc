﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KobaWebApplication.Dto.AdvanceSearch
{
    public class City_State_Country_View_Dto
    {
        public string City_Key { get; set; }
        public string City_Nam { get; set; }
        public string State_Name { get; set; }
        public string Country_Name { get; set; }
    }
}
