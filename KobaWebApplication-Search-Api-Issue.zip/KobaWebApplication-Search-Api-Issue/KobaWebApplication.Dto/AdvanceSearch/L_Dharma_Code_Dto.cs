﻿namespace KobaWebApplication.Dto.AdvanceSearch
{
    public class L_Dharma_Code_Dto
    {
        public string Dharma_Code { get; set; }
        public string Dharma_Name { get; set; }
        public string For_Hp { get; set; }
        public string Is_Hp_Default { get; set; }
    }
}
