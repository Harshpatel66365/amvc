﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KobaWebApplication.Dto.Account
{
    public class UserProfileViewModel
    {
        public string ProfileImageUrl { get; set; }
        public string Username { get; set; }
        public string RoleName { get; set; }

    }
}
