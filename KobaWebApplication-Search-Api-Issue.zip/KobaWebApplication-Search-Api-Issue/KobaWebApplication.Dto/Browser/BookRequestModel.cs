﻿using System.ComponentModel.DataAnnotations;

namespace KobaWebApplication.Dto.Browser
{
    public class BookRequestModel
    {
        [Required(ErrorMessage = "Contact person name is required.")]
        public string RequestedPersonName { get; set; }

        [Required(ErrorMessage = "Mobile number is required.")]
        [MinLength(10, ErrorMessage = "Mobile number must be 10 digits.")]
        [MaxLength(10, ErrorMessage = "Mobile number must be 10 digits.")]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Please enter a valid Mobile Number.")]
        public string RequestedPersonMobile { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address.")]
        public string RequestedPersonEmail { get; set; }

        [Required(ErrorMessage = "City is required.")]
        public string RequestedPersonCity { get; set; }

        [Required(ErrorMessage = "State is required.")]
        public string RequestedPersonState { get; set; }

        public string BookCategory { get; set; }
        public string BookSrNo { get; set; }
        public string BookTitle { get; set; }
    }

}