﻿using Confluent.Kafka;
using Microsoft.AspNetCore.Http;

namespace KobaWebApplication.Dto.Browser
{
    public class SearchCountResponseDto
    {
        public long? KrutiCount { get; set; } = 0;
        public long? AuthorCount { get; set; } = 0;
        public long? hastpratCount { get; set; } = 0;
        public long? publisherCount { get; set; } = 0;
    }
}
