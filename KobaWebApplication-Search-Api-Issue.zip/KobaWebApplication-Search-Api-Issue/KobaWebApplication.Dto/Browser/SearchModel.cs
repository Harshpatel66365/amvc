﻿namespace KobaWebApplication.Dto.Browser
{
    public class SearchRequest
    {
        public string SearchTerm { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10;
        public string SelectedIndex { get; set; }
        public string IndexName => "elk_koba_" + SelectedIndex + "_new";
        public bool IsExactSearch { get; set; } = false;
        public bool IsAdvanceSearch { get; set; } = false;
        public List<FilterCriteria>? filterCriterias { get; set; }
        public bool IsPaginationLoad { get; set; } = false;
    }

    //public class SearchResponseDto
    //{
    //    public object Results { get; set; } // Adjust the type based on your search results
    //    public long SearchTime { get; set; }
    //    public long TotalResults { get; set; }
    //    public int PageNumber { get; set; }
    //    public int PageSize { get; set; }
    //    public string SelectedIndex { get; set; }
    //    public string SearchTerm { get; set; }
    //}
    public class SearchResponseDto
    {
        public List<SearchResult> Results { get; set; } // Adjust the type based on your search results
        public long SearchTime { get; set; }
        public long TotalResults { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public string SelectedIndex { get; set; }
        public string SearchTerm { get; set; }
        public AccordianResponse accordianRes { get; set; }
    }

    public class FilterCriteria
    {
        public string IndexName { get; set; }
        public string FieldName { get; set; }
        public string SearchTerm { get; set; }

        public double start { get; set; } = 0;
        public double end { get; set; } = 0;
    }

    public class AccordianResponse
    {
        public string IndexName { get; set; }
        // Common properties across different types (replace nullables with actual types as needed)
        public string vir_st_duration { get; set; }

        public string vir_end_duration { get; set; }
        public string dharma_Code { get; set; }

        // 'Prakashan' section
        public string vol_Sub_Vol { get; set; }
        public string reprint { get; set; }

        public string Jild { get; set; }
        public string isbn { get; set; }
        public string prksn_Nam { get; set; }
        public string pblsr_Nam { get; set; }
        public string series_name { get; set; }

        // 'Vidvan' section
        public string vid_No { get; set; }

        public string vid_Nam { get; set; }
        public string guru_Vid_No { get; set; }
        public string guru_Name { get; set; }
        public string dada_Guru_Vid_No { get; set; }
        public string dada_Guru_Name { get; set; }
        public string gach_Key { get; set; }
        public string gach_nam { get; set; }
        public string sadhu_Grihast_Code { get; set; }
        public string male_Female_Code { get; set; }

        // Properties for "hastprat" section
        public string bhandar_Code { get; set; }

        public string bhandar_Name { get; set; }
        public string hp_No { get; set; }
        public string hp_Nam { get; set; }
        public string lipi_Short_Name { get; set; }
        public string material_Short_Name { get; set; }
        public string year_type_short_name { get; set; }
        public string year_value { get; set; }
        public string vir_st_year { get; set; }
        public string vir_end_year { get; set; }
        public string vid_Type_Short_Name { get; set; }

        // Properties for "kruti" section
        public string ki_Kr_Key { get; set; }

        public string ki_Kr_Nam { get; set; }
        public string adiVakya { get; set; }
        public string antimVakya { get; set; }
        public string granthagra { get; set; }
        public string chand_Type_short_name { get; set; }
        public string adhyay_short_name { get; set; }
        public int? Chand_count { get; set; }
        public int? adhyay_count { get; set; }
    }
    public class IsPrakashanBookReq_Res_Dto
    {
        public bool isAvailabel { get; set; }
        public string message { get; set; }
        public string url { get; set; }
        public int statusCode { get; set; }
    }
}