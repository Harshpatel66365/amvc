﻿namespace KobaWebApplication.Dto.Browser
{
    public class SearchResultDto
    {
        public long TotalCount { get; set; }
        public List<SearchResult> Results { get; set; }
    }

    public class SearchResult
    {
        public string Index { get; set; }
        public object Source { get; set; }
    }

    public class AdvanceFiltersDto
    {
        public List<string>? Bhandar_Short_Name { get; set; }
        public List<string>? Lipi_Short_Name { get; set; }
        public List<string>? Publisher_Name { get; set; }
        public List<string>? Language { get; set; }
        public List<PublisherInfoDto> publisherInfoDtos { get; set; }
        public List<PublisherInfoDto> editionInfoDtos { get; set; }
        public List<PublisherInfoDto> dharmaCodeInfoDtos { get; set; }
        public List<PublisherInfoDto> granthmalaInfoDtos { get; set; }

        public List<PublisherInfoDto> bhandarInfoDtos { get; set; }
        public List<PublisherInfoDto> lipiInfoDtos { get; set; }
        public List<PublisherInfoDto> vidTypeShortNameInfoDtos { get; set; }

        public List<PublisherInfoDto> languageInfoDtos { get; set; }
        public List<PublisherInfoDto> vidNameInfoDtos { get; set; }

        public List<PublisherInfoDto> gachNameInfoDtos { get; set; }
        public List<PublisherInfoDto> guruNameInfoDtos { get; set; }
        public List<PublisherInfoDto> dadaGuruNameInfoDtos { get; set; }
        public List<PublisherInfoDto> genderCodeInfoDtos { get; set; }
        public List<PublisherInfoDto> gruhasthInfoDtos { get; set; }
    }

    public class PublisherInfoDto
    {
        public string Name { get; set; }
        public long Count { get; set; }
    }
}