﻿using KobaWebApplication.Dto.DataGrid;

namespace KobaWebApplication.Dto.Browser
{
    public class Hastprat_Search_Request_Dto : DataTableFilterDto
    {
        public string? AtxtBhandar { get; set; }
        public string? AtxtHpNam { get; set; }
        public string? AtxtPetaAnk { get; set; }
        public string? AtxtPratNoStart { get; set; }
        public string? AtxtPratNoEnd { get; set; }
        public string? AtxtSholk { get; set; }
        public string? AtxtSthal { get; set; }
        public string? AtxtDashaCode { get; set; }
        public string? AtxtPurnataCode { get; set; }
        public string? AtxtPRCode { get; set; }
        public string? AtxtTotPetaAnkStart { get; set; }
        public bool chkRelatedHpPDFLnk { get; set; }
        public bool ChkHpFilter { get; set; }
        public string? cmbHpByType { get; set; }
        public string? cmbHpPosition { get; set; }
        public string? cmbHpAndOr { get; set; }
        public string? cmbPetaAnkByType { get; set; }
        public string? cmbPetaAnkPosition { get; set; }
        public string? cmbPetaAnkAndOr { get; set; }
        public string? cmbPratNoCondn { get; set; }
        public string? cmbPratNoAndOr { get; set; }
        public string? cmbSholkPosition { get; set; }
        public string? cmbSholkAndOr { get; set; }
        public bool chkSthalIsNot { get; set; }
        public string? cmbSthalAndOr { get; set; }
        public bool chkDashaCodeIsNot { get; set; }
        public string? cmbPurnataCodeAndOr { get; set; }
        public bool chkPRCodeIsNot { get; set; }
        public string? cmbDashaCodeAndOr { get; set; }
        public bool chkPurnataCodeIsNot { get; set; }
        public string? cmbPRCodeAndOr { get; set; }
        public bool chkHpDharmaCodeManual { get; set; }
        public bool chkHpDharmaCodeIsNot { get; set; }
        public bool AtxtTotPetaAnkEnd { get; set; }
        public string? cmbHpDharmaPosition { get; set; }
        public string? cmbHpDharmaCodeAndOr { get; set; }
        public string? AtxtDharmaCode { get; set; }
        public string? cmbTotPetaAnkOperator { get; set; }
        public string? cmbTotPetaAnkAndOr { get; set; }
        public string? cmbHpPDFAndOr { get; set; }

        public  string? cmbDharmaCodeEqualTxt { get; set; }
        public string MapOrderBy(int orderbyColumn)
        {
            switch (orderbyColumn)
            {
                case 0: return "AtxtBhandar";
                case 1: return "AtxtHpNam";
                case 2: return "AtxtPetaAnk";
                default: return "AtxtHpNam";
            }
        }
    }

    public class Hastprat_Search_Grid_Request_Dto : DataTableFilterDto
    {
        public string? SearchModel { get; set; }
        public string MapOrderBy(int orderbyColumn)
        {
            switch (orderbyColumn)
            {
                case 0: return "HpNam";
                case 1: return "DashaShortName";
                case 2: return "DharmaCode";
                default: return "HpNam";
            }
        }
    }
}