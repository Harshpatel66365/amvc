﻿
namespace KobaWebApplication.Dto.Browser
{
    public class AddHastpratInfoRequest_Dto
    {
        public string PratNumber { get; set; } = string.Empty;
        public string PratName { get; set; } = string.Empty;
        public string PratPrakar { get; set; } = string.Empty;
        public string MaterialPrakar { get; set; } = string.Empty;
        public string LekhanPrakar { get; set; } = string.Empty;
        public string Lipi { get; set; } = string.Empty;
        public string Dharma { get; set; } = string.Empty;
        public string PratVishesh { get; set; } = string.Empty;
        public string PurDonLotNo { get; set; } = string.Empty;
        public string LakshanCodeString { get; set; } = string.Empty;
        public string FormNumber { get; set; } = string.Empty;
        public string OldNumber { get; set; } = string.Empty;
        public string Purnata { get; set; } = string.Empty;
        public string PurnataVishesh { get; set; } = string.Empty;
        public string PurnataRemarkCode { get; set; } = string.Empty;
        public string FirstPage { get; set; } = string.Empty;
        public string LastPage { get; set; } = string.Empty;
        public string GhatateTotal { get; set; } = string.Empty;
        public string GhatatePatra { get; set; } = string.Empty;
        public string BadhteTotal { get; set; } = string.Empty;
        public string BadhtePatra { get; set; } = string.Empty;
        public string AvastavikGhatateTotal { get; set; } = string.Empty;
        public string AvastavikGhatatePatra { get; set; } = string.Empty;
        public string NetPages { get; set; } = string.Empty;
        public string ImportanceLevel { get; set; } = string.Empty;
        public char ReadershipLevel { get; set; } 
        public string CatalogNumber { get; set; } = string.Empty;
        public string ReadershipLvl { get; set; } = string.Empty;
    }
}
