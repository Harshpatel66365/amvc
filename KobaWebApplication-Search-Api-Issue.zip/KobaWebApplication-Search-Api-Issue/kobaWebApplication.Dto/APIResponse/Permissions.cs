﻿namespace KobaWebApplication.Dto.APIResponse
{
    public class Permissions
    {
        public string Feature { get; set; }
        public bool HasAccess { get; set; }
    }
}