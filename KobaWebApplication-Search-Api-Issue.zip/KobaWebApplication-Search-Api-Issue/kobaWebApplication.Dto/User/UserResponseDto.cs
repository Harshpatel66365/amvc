﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace KobaWebApplication.Dto.User
{
    public class UserResponseDto
    {
        public string Id { get; set; }

        [DisplayName("First Name")]
        public string FirstName { get; set; } = string.Empty;

        [DisplayName("Last Name")]
        public string LastName { get; set; } = string.Empty;

        [DisplayName("User Name")]
        public string UserName { get; set; } = string.Empty;

        [DisplayName("Email Address")]
        [EmailAddress(ErrorMessage = "Please enter valid email address")]
        public string Email { get; set; } = string.Empty;

        public string Password { get; set; } = string.Empty;

        public string UserRole { get; set; } = string.Empty;

        [DisplayName("Phone Number")]
        public string PhoneNumber { get; set; } = string.Empty;

        [DisplayName("Registered FCMToken")]
        public string? RegisteredFCMToken { get; set; }

        public int UserId { get; set; }
        public bool IsActive { get; set; }

        public string RoleId { get; set; }
    }

    public class DataResponseModel
    {
        public int StatusCode { get; set; }
        public bool IsValid { get; set; }
        public string? ErrorMessage { get; set; }
        public string? OldMacAddress { get; set; }
    }
}