﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace KobaWebApplication.Dto.User
{
    public class UserRequestDto
    {
        public string Id { get; set; }

        public int UserId { get; set; }

        [Required]
        [DisplayName("First Name")]
        [RegularExpression(@"^[a-zA-Z]+[a-zA-Z\s]*$", ErrorMessage = "Please enter valid first name.")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Maximum 50 characters.")]
        public string FirstName { get; set; } = string.Empty;

        [Required]
        [DisplayName("Last Name")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Maximum 50 characters.")]
        [RegularExpression(@"^[a-zA-Z]+[a-zA-Z\s]*$", ErrorMessage = "Please enter valid last name.")]
        public string LastName { get; set; } = string.Empty;

        [Required]
        [DisplayName("User Name")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "Maximum 256 characters.")]
        public string UserName { get; set; } = string.Empty;

        [DisplayName("Email Address")]
        [EmailAddress(ErrorMessage = "Please enter valid email address.")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "The E-mail is not valid.")]
        [Remote("DuplicateUserEmail", "User", AdditionalFields = nameof(UserId), ErrorMessage = ("Email already exist. Please enter a different Email."))]
        public string Email { get; set; } = string.Empty;

        [Required]
        [RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[#$^+=!*()@%&]).{8,}$", ErrorMessage = "Please Enter 8 to 16 With Upper Case, Lower Case and Special Character.")]
        public string? Password { get; set; } = string.Empty;

        [DisplayName("Phone Number")]
        [MaxLength(10, ErrorMessage = "Please enter 10 digit")]
        [MinLength(10, ErrorMessage = "Please enter 10 digit")]
        [Remote("DuplicateUserPhoneNumber", "User", AdditionalFields = nameof(UserId), ErrorMessage = ("Phone Number already exists. Please enter a different Phone Number."))]
        public string PhoneNumber { get; set; } = string.Empty;

        public int UserTenantMappingId { get; set; }

        public int TenantId { get; set; }

        [DisplayName("User Role")]
        public string AspNetRole { get; set; } = string.Empty;

        [DisplayName("Registered FCMToken")]
        public string? RegisteredFCMToken { get; set; }

        public string NormalizedName { get; set; } = string.Empty;

        [DisplayName("Device UDID")]
        public string? MobileDeviceId { get; set; }
    }
}