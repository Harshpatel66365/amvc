﻿namespace KobaWebApplication.Dto.LogoutResponseDto
{
    public class LogoutResponseDto
    {
        public int Id { get; set; }
        public string RoleId { get; set; }
        public string TenantId { get; set; }
    }
}