﻿using KobaWebApplication.Dto.DataGrid;
using Newtonsoft.Json;

namespace KobaWebApplication.Dto.Role
{
    //public class RoleDataTableFilterDto : DataTableFilterDto
    //{
    //    [JsonProperty("roleName")]
    //    public string RoleName { get; set; }

    //    [JsonProperty("roleId")]
    //    public string RoleId { get; set; }
    //}
    public class RoleDataTableFilterDto : DataTableFilterDto
    {
        public string MapOrderBy(int orderbyColumn)
        {
            switch (orderbyColumn)
            {
                case 0: return "Name";
                case 1: return "Id";
                default: return "Name";
            }
        }
    }
}