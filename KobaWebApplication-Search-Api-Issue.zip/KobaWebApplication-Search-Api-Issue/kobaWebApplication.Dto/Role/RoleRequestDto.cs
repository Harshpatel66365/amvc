﻿using Microsoft.AspNetCore.Mvc;
using KobaWebApplication.Dto.RolePermission;
using System.ComponentModel.DataAnnotations;

namespace KobaWebApplication.Dto.Role
{
    public class RoleRequestDto
    {
        public RoleRequestDto()
        {
            ModulePermissionList = new List<RolePermissionResponseDto>();
        }

        public string Id { get; set; }

        [Required(ErrorMessage = "The Role Name field is required.")]
        [MaxLength(50, ErrorMessage = "A maximum of 50 characters is allowed.")]
        [Remote("DuplicateRoleName", "Role", AdditionalFields = nameof(Id), ErrorMessage = "Name already exist. Please enter a different name.")]
        public string Name { get; set; }

        public string NormalizedName { get; set; }
        public string ConcurrencyStamp { get; set; }
        public int? TenantId { get; set; }

        public bool IsDelete { get; set; }
        public List<RolePermissionResponseDto> ModulePermissionList { get; set; }
        public string IsPortalAccessChecked { get; set; }

    }
}