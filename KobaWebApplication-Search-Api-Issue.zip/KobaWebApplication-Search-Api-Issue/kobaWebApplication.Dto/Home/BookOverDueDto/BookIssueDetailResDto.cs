﻿using KobaWebApplication.Dto.DataGrid;

namespace KobaWebApplication.Dto.Home.BookOverDueDto
{
    public class BookIssueFilterDto : DataTableFilterDto
    {
        public int BookTypeFlag { get; set; }
        public string MapOrderBy(int orderbyColumn)
        {
            switch (orderbyColumn)
            {
                case 0: return "Bhandar_Code";
                case 1: return "Book_No";
                case 2: return "Is_Lost";
                case 3: return "Issue_Tran_No";
                case 4: return "Issue_date";
                case 5: return "Issue_init";
                case 6: return "Expected_date";
                case 7: return "Receipt_Dt";
                case 8: return "Reciever_Init";
                case 9: return "Prksn_Nam";
                case 10: return "Vol_Sub_Vol";
                case 11: return "Reader_No";
                case 12: return "Receipt_Tran_No";
                case 13: return "Book_Remark";
                case 14: return "L_Ext_Iss_Gatepass_Remark";
                case 15: return "L_Ext_Iss_Detail_Remark";
                case 16: return "Prksn_Key";
                case 17: return "Certifier";
                default: return "Bhandar_Code";
            }
        }
    }

    public class BookIssueDetailResDto
    {
        public string Bhandar_Code { get; set; }
        public string Book_No { get; set; }
        public string Is_Lost { get; set; }
        public int Issue_Tran_No { get; set; }
        public DateTime? Issue_date { get; set; }
        public string? Issue_init { get; set; }
        public DateTime? Expected_date { get; set; }
        public DateTime? Receipt_Dt { get; set; }
        public string? Reciever_Init { get; set; }
        public string? Prksn_Nam { get; set; }
        public string? Vol_Sub_Vol { get; set; }
        public string? Reader_No { get; set; }
        public int? Receipt_Tran_No { get; set; }
        public string? Book_Remark { get; set; }
        public string? L_Ext_Iss_Gatepass_Remark { get; set; }
        public string? L_Ext_Iss_Detail_Remark { get; set; }
        public string Prksn_Key { get; set; }
        public string? Certifier { get; set; }
    }

}
