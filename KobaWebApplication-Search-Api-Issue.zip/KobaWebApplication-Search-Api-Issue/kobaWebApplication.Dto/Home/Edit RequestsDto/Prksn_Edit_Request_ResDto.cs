﻿using KobaWebApplication.Dto.DataGrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KobaWebApplication.Dto.Home.EditRequestsDto
{
    public class Prksn_Edit_Request_FilterDto : DataTableFilterDto
    {
        public bool IsEditReqToYou { get; set; }

        public string MapOrderBy(int orderbyColumn)
        {
            switch (orderbyColumn)
            {
                case 0: return "Msg_No";
                case 1: return "Prksn_key";
                case 2: return "Prksn_Pet_Key";
                case 3: return "Sender_Init";
                case 4: return "Sender_Msg";
                case 5: return "Receiver_init";
                case 6: return "Receiver_Reply";
                case 7: return "Urgency_Type_Short_name";
                case 8: return "Status_Short_name";
                case 9: return "Send_Dt";
                case 10: return "Reply_Dt";
                case 11: return "Add_Init";
                case 12: return "Updt_Init";
                case 13: return "Last_Edtr";
                case 14: return "Certifier";
                case 15: return "Updt_Authority_Level";
                case 16: return "Certifier_Authority_Level";
                case 17: return "Add_Date_Time";
                case 18: return "Updt_Date_Time";
                case 19: return "Edit_Date_Time";
                case 20: return "Certi_Date_Time";
                default: return "Msg_No";
            }
        }
    }


    public class Prksn_Edit_Request_ResDto
    {
        public int Msg_No { get; set; }
        public string Prksn_key { get; set; }
        public string? Prksn_Pet_Key { get; set; }
        public string Sender_Init { get; set; }
        public DateTime Send_Dt { get; set; }
        public string Sender_Msg { get; set; }
        public string Receiver_init { get; set; }
        public DateTime? Reply_Dt { get; set; }
        public string? Receiver_Reply { get; set; }
        public string Urgency_Type_Short_name { get; set; }
        public string Status_Short_name { get; set; }
        public string Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }
        public DateTime? Add_Date_Time { get; set; }
        public DateTime? Updt_Date_Time { get; set; }
        public DateTime? Edit_Date_Time { get; set; }
        public DateTime? Certi_Date_Time { get; set; }
    }

}
