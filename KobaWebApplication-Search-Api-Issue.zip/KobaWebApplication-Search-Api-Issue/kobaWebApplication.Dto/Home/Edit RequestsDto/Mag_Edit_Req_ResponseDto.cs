﻿using KobaWebApplication.Dto.DataGrid;

namespace KobaWebApplication.Dto.Home.EditRequestsDto
{

    public class Mag_Edit_Request_FilterDto : DataTableFilterDto
    {
        public bool IsEditReqToYou { get; set; }

        public string MapOrderBy(int orderbyColumn)
        {
            switch (orderbyColumn)
            {
                case 0: return "Msg_No";
                case 1: return "Mag_No";
                case 2: return "Ank_No";
                case 3: return "Ank_Pet_Key";
                case 4: return "Sender_Init";
                case 5: return "Sender_Msg";
                case 6: return "Receiver_Init";
                case 7: return "Receiver_Reply";
                case 8: return "Urgency_Type_Short_name";
                case 9: return "Status_Short_Name";
                case 10: return "Send_Dt";
                case 11: return "Reply_Dt";
                case 12: return "Add_Init";
                case 13: return "Updt_Init";
                case 14: return "Last_Edtr";
                case 15: return "Certifier";
                case 16: return "Updt_Authority_Level";
                case 17: return "Certifier_Authority_Level";
                case 18: return "Add_Date_Time";
                case 19: return "Updt_Date_Time";
                case 20: return "Edit_Date_Time";
                case 21: return "Certi_Date_Time";
                default: return "Msg_No";
            }
        }
    }

    public class Mag_Edit_Req_ResponseDto
    {
        public int Msg_No { get; set; }
        public string Mag_No { get; set; }
        public string Ank_No { get; set; }
        public string Ank_Pet_Key { get; set; }
        public string Sender_Init { get; set; }
        public string Sender_Msg { get; set; }
        public string Receiver_Init { get; set; }
        public string Receiver_Reply { get; set; }
        public string Urgency_Type_Short_name { get; set; }
        public string Status_Short_Name { get; set; }
        public DateTime Send_Dt { get; set; }
        public DateTime? Reply_Dt { get; set; }
        public string Add_Init { get; set; }
        public string Updt_Init { get; set; }
        public string Last_Edtr { get; set; }
        public string Certifier { get; set; }
        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }
        public DateTime? Add_Date_Time { get; set; }
        public DateTime? Updt_Date_Time { get; set; }
        public DateTime? Edit_Date_Time { get; set; }
        public DateTime? Certi_Date_Time { get; set; }

        public bool IsReceiver { get; set; }
    }
}
