﻿using KobaWebApplication.Dto.DataGrid;

namespace KobaWebApplication.Dto.Home.EditRequestsDto
{
    public class Vid_Edit_Request_FilterDto : DataTableFilterDto
    {
        public bool IsEditReqToYou { get; set; }

        public string MapOrderBy(int orderbyColumn)
        {
            switch (orderbyColumn)
            {
                case 0: return "Msg_No";
                case 1: return "Vid_no";
                case 2: return "Sender_Init";
                case 3: return "Sender_Msg";
                case 4: return "Receiver_init";
                case 5: return "Receiver_Reply";
                case 6: return "Urgency_Type_Short_name";
                case 7: return "Status_Short_name";
                case 8: return "Send_Dt";
                case 9: return "Reply_Dt";
                case 10: return "Add_Init";
                case 11: return "Updt_Init";
                case 12: return "Last_Edtr";
                case 13: return "Certifier";
                case 14: return "Updt_Authority_Level";
                case 15: return "Certifier_Authority_Level";
                case 16: return "Add_Date_Time";
                case 17: return "Updt_Date_Time";
                case 18: return "Edit_Date_Time";
                case 19: return "Certi_Date_Time";
                default: return "Msg_No";
            }
        }
    }

    public class Vid_Edit_ResponseDto
    {
        public int Msg_No { get; set; }
        public string Vid_no { get; set; }
        public string Sender_Init { get; set; }
        public string Sender_Msg { get; set; }
        public string Receiver_init { get; set; }
        public string? Receiver_Reply { get; set; }
        public string Urgency_Type_Short_name { get; set; }
        public string Status_Short_name { get; set; }
        public DateTime Send_Dt { get; set; }
        public DateTime? Reply_Dt { get; set; }
        public string Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }
        public DateTime? Add_Date_Time { get; set; }
        public DateTime? Updt_Date_Time { get; set; }
        public DateTime? Edit_Date_Time { get; set; }
        public DateTime? Certi_Date_Time { get; set; }

        public bool IsReceiver { get; set; }
    }
}
