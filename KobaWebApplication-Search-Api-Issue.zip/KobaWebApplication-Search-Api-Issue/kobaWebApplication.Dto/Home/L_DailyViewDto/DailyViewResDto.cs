﻿using KobaWebApplication.Dto.DataGrid;

namespace KobaWebApplication.Dto.Home.L_DailyViewDto
{
    public class DailyViewFilterDto : DataTableFilterDto
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string MapOrderBy(int orderbyColumn)
        {
            switch (orderbyColumn)
            {
                case 0: return "Daily_Id";
                case 1: return "Sess_datetime";
                case 2: return "Leave";
                case 3: return "Half_Day";
                case 4: return "Dutyleave";
                case 5: return "Arrival";
                case 6: return "Departure";
                case 7: return "Recess";
                case 8: return "Tea_break";
                case 9: return "Main_Work";
                case 10: return "Main_Desc";
                case 11: return "Work_Output";
                case 12: return "M_Rel_Work";
                case 13: return "M_Rel_Desc";
                case 14: return "M_Rel_Output";
                case 15: return "Other_Work";
                case 16: return "Other_Desc";
                case 17: return "Other_Output";
                case 18: return "Disturb";
                case 19: return "Disturb_Desc";
                case 20: return "Remark";
                case 21: return "Supervisor_Remark";
                case 22: return "Supervisor_Remark_Dt";
                case 23: return "User_Reply";
                case 24: return "User_Reply_Dt";
                case 25: return "Supervisor_Remark_Status_Code";
                case 26: return "Add_Init";
                case 27: return "Updt_Init";
                case 28: return "Last_Edtr";
                case 29: return "Certifier";
                case 30: return "Updt_Authority_Level";
                case 31: return "Certifier_Authority_Level";
                case 32: return "Status_Short_name";
                case 33: return "UserName";
                case 34: return "Usr_Init";
                default: return "Daily_Id";
            }
        }
    }


    public class DailyViewResDto
    {
        public int Daily_Id { get; set; }
        public DateTime Sess_datetime { get; set; }
        public string Leave { get; set; }
        public string Half_Day { get; set; }
        public string Dutyleave { get; set; }
        public string? Arrival { get; set; }
        public string? Departure { get; set; }
        public string? Recess { get; set; }
        public string? Tea_break { get; set; }
        public string? Main_Work { get; set; }
        public string? Main_Desc { get; set; }
        public string? Work_Output { get; set; }
        public string? M_Rel_Work { get; set; }
        public string? M_Rel_Desc { get; set; }
        public string? M_Rel_Output { get; set; }
        public string? Other_Work { get; set; }
        public string? Other_Desc { get; set; }
        public string? Other_Output { get; set; }
        public string? Disturb { get; set; }
        public string? Disturb_Desc { get; set; }
        public string? Remark { get; set; }
        public string? Supervisor_Remark { get; set; }
        public DateTime? Supervisor_Remark_Dt { get; set; }
        public string? User_Reply { get; set; }
        public DateTime? User_Reply_Dt { get; set; }
        public string? Supervisor_Remark_Status_Code { get; set; }
        public string Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }
        public string? Status_Short_name { get; set; }
        public string? UserName { get; set; }
        public string? Usr_Init { get; set; }
    }

}
