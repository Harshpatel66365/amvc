﻿using KobaWebApplication.Dto.DataGrid;

namespace KobaWebApplication.Dto.Home.User_Error_Suggestion
{
    public class ErrorDetailFilterDto : DataTableFilterDto
    {
        public int ErrorType { get; set; }
        public string MapOrderBy(int orderbyColumn)
        {
            switch (orderbyColumn)
            {
                case 0: return "ErrorID";
                case 1: return "Error_Description";
                case 2: return "Error_Status_Description";
                case 3: return "Error_PostDate";
                case 4: return "Programmer_Remark";
                case 5: return "TypeOfError";
                case 6: return "Urgency_Type_Short_name";
                case 7: return "User_Reply";
                case 8: return "Entity";
                case 9: return "Entity_Field";
                case 10: return "Programmer_Init";
                case 11: return "Error_Solved_Date";
                case 12: return "Error_Image_Path";
                case 13: return "User_Init";
                default: return "ErrorID";
            }
        }
    }

    public class ErrorDetailResDto
    {
        public int ErrorID { get; set; }
        public string? Error_Description { get; set; }
        public string? Error_Status_Description { get; set; }
        public DateTime? Error_PostDate { get; set; }
        public string? Programmer_Remark { get; set; }
        public string? TypeOfError { get; set; }
        public string? Urgency_Type_Short_name { get; set; }
        public string? User_Reply { get; set; }
        public string? Entity { get; set; }
        public string? Entity_Field { get; set; }
        public string? Programmer_Init { get; set; }
        public DateTime? Error_Solved_Date { get; set; }
        public string? Error_Image_Path { get; set; }
        public string? User_Init { get; set; }
    }

}
