﻿using KobaWebApplication.Dto.DataGrid;

namespace KobaWebApplication.Dto.Home.RemarkManagementDto
{
    public class L_Remark_Master_ResDto
    {
        public int MainUserReplyD { get; set; }
        public int MainUserReplyN { get; set; }
        public int MainHeadReplyD { get; set; }
        public int MainHeadReplyN { get; set; }

        public int OtherUserReplyD { get; set; }
        public int OtherUserReplyN { get; set; }
        public int OtherHeadReplyD { get; set; }
        public int OtherHeadReplyN { get; set; }
    }
}