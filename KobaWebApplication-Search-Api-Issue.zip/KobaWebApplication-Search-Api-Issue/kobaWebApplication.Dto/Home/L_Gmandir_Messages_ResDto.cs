﻿using KobaWebApplication.Dto.DataGrid;

namespace KobaWebApplication.Dto.Home
{
    public class L_Gmandir_Edit_Request_FilterDto : DataTableFilterDto
    {
        public string MapOrderBy(int orderbyColumn)
        {
            switch (orderbyColumn)
            {
                case 0: return "Message_id";
                case 1: return "Message_Date";
                case 2: return "Message";
                case 3: return "Display_Flag";
                case 4: return "Total_Facility";
                default: return "Message_id";
            }
        }
    }

    public class L_Gmandir_Messages_ResDto
    {
        public int Message_id { get; set; }
        public DateTime Message_Date { get; set; }
        public string Message { get; set; }
        public string Display_Flag { get; set; }
        public int? Total_Facility { get; set; }
    }
}
