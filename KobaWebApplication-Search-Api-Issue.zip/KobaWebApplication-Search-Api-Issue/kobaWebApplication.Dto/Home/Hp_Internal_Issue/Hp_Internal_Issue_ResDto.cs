﻿using KobaWebApplication.Dto.DataGrid;

namespace KobaWebApplication.Dto.Home.Hp_Internal_Issue
{
    public class Hp_Internal_Issue_FilterDto : DataTableFilterDto
    {
        public int Hp_IssueType { get; set; }
        public string MapOrderBy(int orderbyColumn)
        {
            switch (orderbyColumn)
            {
                case 0: return "Tran_No";
                case 1: return "Bhandar_Code";
                case 2: return "Hp_No";
                case 3: return "Request_On_Dt";
                case 4: return "To_Whom";
                case 5: return "Issue_Init";
                case 6: return "Issue_Dt";
                case 7: return "Receiver_Init";
                case 8: return "Received_By_User_Dt";
                case 9: return "Returned_By_User_Dt";
                case 10: return "Issue_Type_Short_name";
                case 11: return "Request_Cancelled";
                case 12: return "Is_Lost";
                case 13: return "Add_Init";
                case 14: return "Updt_Init";
                case 15: return "Updt_Authority_Level";
                default: return "Tran_No";
            }
        }
    }

    public class Hp_Internal_Issue_ResDto
    {
        public int Tran_No { get; set; }
        public string Bhandar_Code { get; set; }
        public string Hp_No { get; set; }
        public DateTime Request_On_Dt { get; set; }
        public string To_Whom { get; set; }
        public string? Issue_Init { get; set; }
        public DateTime? Issue_Dt { get; set; }
        public string? Receiver_Init { get; set; }
        public DateTime? Received_By_User_Dt { get; set; }
        public DateTime? Returned_By_User_Dt { get; set; }
        public string? Issue_Type_Short_name { get; set; }
        public string Request_Cancelled { get; set; }
        public string Is_Lost { get; set; }
        public string Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public int? Updt_Authority_Level { get; set; }
    }
}
