﻿using KobaWebApplication.Dto.DataGrid;

namespace KobaWebApplication.Dto.Home.PendingTaskDto
{
    public class GPendingWorkViewFilterDto : DataTableFilterDto
    {
        public string MapOrderBy(int orderbyColumn)
        {
            switch (orderbyColumn)
            {
                case 0: return "Pending_Work";
                case 1: return "P_Date";
                case 2: return "Deadline_dt";
                case 3: return "For_Whom";
                case 4: return "Remark";
                case 5: return "Main_Attending_Person";
                case 6: return "Alternate_Attending_Person";
                case 7: return "Reminder_St_Dt";
                case 8: return "Attending_User_Group_Short_Name";
                case 9: return "Add_Init";
                case 10: return "Updt_Init";
                case 11: return "Last_Edtr";
                case 12: return "Certifier";
                case 13: return "Section_Short_Name";
                case 14: return "Section_Name";
                case 15: return "Urgency_Type_name";
                case 16: return "Urgency_Type_Short_name";
                case 17: return "Status_name";
                case 18: return "Status_Short_name";
                case 19: return "User_Group_Name";
                case 20: return "User_Group_Short_Name";
                default: return "Pending_Work";
            }
        }
    }


    public class GPendingWorkViewResDto
    {
        public decimal Pending_Id { get; set; }
        public string Pending_Work { get; set; }
        public DateTime P_Date { get; set; }
        public DateTime Deadline_dt { get; set; }
        public string For_Whom { get; set; }
        public string Remark { get; set; }
        public string Main_Attending_Person { get; set; }
        public string Alternate_Attending_Person { get; set; }
        public DateTime Reminder_St_Dt { get; set; }
        public string Attending_User_Group_Short_Name { get; set; }
        public string Add_Init { get; set; }
        public string Updt_Init { get; set; }
        public string Last_Edtr { get; set; }
        public string Certifier { get; set; }
        public string Section_Short_Name { get; set; }
        public string Section_Name { get; set; }
        public string Urgency_Type_name { get; set; }
        public string Urgency_Type_Short_name { get; set; }
        public string Status_name { get; set; }
        public string Status_Short_name { get; set; }
        public string User_Group_Name { get; set; }
        public string User_Group_Short_Name { get; set; }
    }
}
