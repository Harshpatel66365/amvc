﻿using KobaWebApplication.Dto.DataGrid;

namespace KobaWebApplication.Dto.Home.User_Score_Board
{
    public class UserScoreBoardFilterDto : DataTableFilterDto
    {
        public string Username { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }

    public class UserScoreBoardResponseDto
    {
        public string TableName { get; set; }
        public int Add_Record_Count { get; set; }
        public int Update_Record_Count { get; set; }
    }
}