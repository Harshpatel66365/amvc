﻿using KobaWebApplication.Dto.DataGrid;

namespace KobaWebApplication.Dto.Home.RoutinWorkDto
{
    public class RoutineWorkViewFilterDto : DataTableFilterDto
    {
        public string MapOrderBy(int orderbyColumn)
        {
            switch (orderbyColumn)
            {
                case 0: return "Title";
                case 1: return "Custom_Msg";
                case 2: return "User_Group_Short_Name";
                case 3: return "Main_Attending_Person";
                case 4: return "Alternate_Attending_Person";
                case 5: return "Msg_Dt";
                case 6: return "Start_Remind_Duration_Day";
                case 7: return "Duration_Short_name";
                case 8: return "Duration_Deadline_Dt";
                case 9: return "Show_Msg";
                case 10: return "DoneBy_Init";
                case 11: return "DoneOn_Dt";
                case 12: return "Add_init";
                case 13: return "Updt_Init";
                case 14: return "Last_Edtr";
                case 15: return "Certifier";
                case 16: return "Updt_Authority_Level";
                case 17: return "Certifier_Authority_Level";
                default: return "Title";
            }
        }
    }

    public class RoutineWorkViewResDto
    {
        public int Routine_Work_Id { get; set; }
        public string Title { get; set; }
        public string Custom_Msg { get; set; }
        public string? User_Group_Short_Name { get; set; }
        public string Main_Attending_Person { get; set; }
        public string? Alternate_Attending_Person { get; set; }
        public DateTime Msg_Dt { get; set; }
        public string Start_Remind_Duration_Day { get; set; }
        public string Duration_Short_name { get; set; }
        public DateTime Duration_Deadline_Dt { get; set; }
        public string? Show_Msg { get; set; }
        public string? DoneBy_Init { get; set; }
        public DateTime? DoneOn_Dt { get; set; }
        public string? Add_init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }
    }

}
