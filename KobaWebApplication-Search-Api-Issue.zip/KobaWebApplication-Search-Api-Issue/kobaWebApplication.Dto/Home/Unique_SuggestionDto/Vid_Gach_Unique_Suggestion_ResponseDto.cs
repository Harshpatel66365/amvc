﻿using KobaWebApplication.Dto.DataGrid;

namespace KobaWebApplication.Dto.Home.Unique_SuggestionDto
{
    public class Vid_Gach_Unique_Suggestion_FilterDto : DataTableFilterDto
    {
        public bool IsSuggestionToYou { get; set; }

        public string MapOrderBy(int orderbyColumn)
        {
            switch (orderbyColumn)
            {
                case 0: return "Unique_Suggestion_Id";
                case 1: return "Destination_Gach_Key";
                case 2: return "Source_Gach_Key";
                case 3: return "Unique_Type_Short_Name";
                case 4: return "Send_Dt";
                case 5: return "Send_Msg";
                case 6: return "Receiver_Init";
                case 7: return "Reply_Dt";
                case 8: return "Reply_Msg";
                case 9: return "Status_Short_Name";
                case 10: return "Remark";
                case 11: return "Add_Init";
                case 12: return "Updt_Init";
                case 13: return "Last_Edtr";
                case 14: return "Certifier";
                case 15: return "Updt_Authority_Level";
                case 16: return "Certifier_Authority_Level";
                default: return "Unique_Suggestion_Id";
            }
        }
    }

    public class Vid_Gach_Unique_Suggestion_ResponseDto
    {
        public int Unique_Suggestion_Id { get; set; }
        public string Destination_Gach_Key { get; set; }
        public string Source_Gach_Key { get; set; }
        public string Unique_Type_Short_Name { get; set; }
        public DateTime Send_Dt { get; set; }
        public string Send_Msg { get; set; }
        public string Receiver_Init { get; set; }
        public DateTime? Reply_Dt { get; set; }
        public string Reply_Msg { get; set; }
        public string Status_Short_Name { get; set; }
        public string Remark { get; set; }
        public string Add_Init { get; set; }
        public string Updt_Init { get; set; }
        public string Last_Edtr { get; set; }
        public string Certifier { get; set; }
        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }

        public bool IsReceiver { get; set; }
    }

}
