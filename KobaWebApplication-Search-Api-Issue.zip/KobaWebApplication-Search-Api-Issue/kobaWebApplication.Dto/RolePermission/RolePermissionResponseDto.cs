﻿using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.APIResponse;

namespace KobaWebApplication.Dto.RolePermission
{
    public class RolePermissionResponseDto
    {
        public string ApplicationType { get; set; }
        public List<PermissiongResponseDto> RolePermissionList { get; set; }
    }

    public class PermissiongResponseDto
    {
        public string Id { get; set; }
        public string Module { get; set; }
        public string Permission { get; set; }
        public string PermissionType { get; set; }
        public string IsChecked { get; set; }
    }

    public class ModulePermissions
    {
        public string moduleName { get; set; }
        public bool HasAccess { get; set; }
    }
}