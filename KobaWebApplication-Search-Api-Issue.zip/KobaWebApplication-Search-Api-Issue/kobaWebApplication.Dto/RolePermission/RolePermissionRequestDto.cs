﻿namespace KobaWebApplication.Dto.RolePermission
{
    public class RolePermissionRequestDto
    {
        public string RoleId { get; set; }
        public string Permission { get; set; }
        public string IsChecked { get; set; }
    }
}