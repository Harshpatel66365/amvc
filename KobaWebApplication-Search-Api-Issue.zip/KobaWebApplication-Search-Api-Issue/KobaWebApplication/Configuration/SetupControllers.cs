﻿using KobaWebApplication.Admin.Middleware;

namespace KobaWebApplication.Admin.Configuration
{
    /// <summary>
    ///     Configure MVC options
    /// </summary>
    public static class MvcConfig
    {
        /// <summary>
        ///     Configure controllers
        /// </summary>
        /// <param name="services"></param>
        public static void SetupControllers(this IServiceCollection services)
        {
            services.AddHttpContextAccessor();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            
            services.AddSingleton<LocalizationMiddleware>();
            services.AddMemoryCache();
            
        }
    }
}