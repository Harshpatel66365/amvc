﻿using KobaWebApplication.Admin.Middleware;
using KobaWebApplication.Middleware;
using Serilog;

namespace KobaWebApplication.Admin.Configuration
{
    public static class ConfigureMethod
    {
        public static void ConfigureWebApplication(this WebApplication app)
        {
            // seed the default data
            //  app.Services.SeedIdentityDataAsync().Wait();

            // Set Common DateTime Format Globally
            app.ConfigureCulture();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/InternalServerError");
                app.UseHsts();
            }
            app.UseSerilogRequestLogging();
            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseNToastNotify();

            //app.UseMiddleware<UseExceptionHandlerMiddleware>();
            app.UseExceptionHandlerMiddleware();
            app.UseRouting();

            // Localization implemented for message response
            app.UseLocalizationMiddleware();
            app.UseSession();

            var cookiePolicyOptions = new CookiePolicyOptions
            {
                MinimumSameSitePolicy = SameSiteMode.Strict,
                HttpOnly = Microsoft.AspNetCore.CookiePolicy.HttpOnlyPolicy.Always,
                Secure = CookieSecurePolicy.None,
            };

            app.UseCookiePolicy(cookiePolicyOptions);

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseMiddleware<SessionCheckMiddleware>();
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Browser}/{action=Index}/{id?}");

            app.Run();
        }
    }
}