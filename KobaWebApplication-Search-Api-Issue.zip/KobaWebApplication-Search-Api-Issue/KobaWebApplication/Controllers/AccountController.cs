﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using KobaWebApplication.BusinessLogic.UnitOfWork;
using NToastNotify;
using KobaWebApplication.Dto.DataGrid;
using KobaWebApplication.Dto.User;
using AutoMapper;
using KobaWebApplication.Dto.Account;
using System.Threading.Channels;
using System.Security.Claims;

namespace KobaWebApplication.Admin.Controllers
{
    public class AccountController : Controller
    {
        private readonly IUnitOfWorkBL _unitOfWorkBL;
        private readonly IToastNotification _toastNotification;
        private readonly IMemoryCache _memoryCache;
        private readonly IMapper _mapper;

        public AccountController(IUnitOfWorkBL unitOfWorkBL, IMapper mapper, IToastNotification toastNotification)
        {
            _unitOfWorkBL = unitOfWorkBL;
            _mapper = mapper;
            _toastNotification = toastNotification;
        }

        private (string FullName, string Username, string Role, string UserId) GetUserClaims()
        {
            var claimsIdentity = User.Identity as ClaimsIdentity;

            var fullNameClaim = claimsIdentity?.FindFirst(ClaimTypes.GivenName)?.Value;
            var usernameClaim = claimsIdentity?.FindFirst(ClaimTypes.Name)?.Value;
            var roleClaim = claimsIdentity?.FindFirst(ClaimTypes.Role)?.Value;
            var userIdClaim = claimsIdentity?.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            return (fullNameClaim ?? "Unknown User", usernameClaim ?? "Unknown Username", roleClaim ?? "", userIdClaim ?? "0");
        }

        public async Task<IActionResult> UserProfile()
        {
            var userClaims = GetUserClaims();
            var userId = userClaims.UserId;

            var user = await _unitOfWorkBL.UserBL.GetUsersById(Convert.ToInt32(userId));

            var RoleId = userClaims.Role;
            var Role = await _unitOfWorkBL.RoleBL.GetRoleByIdAsync(Convert.ToInt32(RoleId));

            ViewBag.RoleName = Role.Name;

            return View(user);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateUser([FromBody] UpdateUserDto updatedUser)
        {
            if (ModelState.IsValid)
            {
                var user = await _unitOfWorkBL.UserBL.GetUsersById(updatedUser.Id);

                if (user != null)
                {
                    // Update the editable fields
                    user.Usr_Name = updatedUser.Usr_Name;
                    user.Permanent_Address = updatedUser.Permanent_Address;

                    // Save changes
                    var Res = await _unitOfWorkBL.UserBL.UpdateUser(user);
                    if (Res.Status == "Success")
                    {
                        _toastNotification.AddSuccessToastMessage(Res.Message);
                        //RedirectToAction("GetUserProfile");
                    }
                    else
                    {
                        _toastNotification.AddErrorToastMessage(Res.Message);
                    }
                    return Ok();
                }

                return NotFound();
            }

            return BadRequest(ModelState);
        }
        public IActionResult ChangePassword()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> ChangePassword(ChangePasswordReq model)
        {
            if (ModelState.IsValid)
            {
                var userClaims = GetUserClaims();
                var userId = userClaims.UserId;
                var response = await _unitOfWorkBL.UserBL.ChangeUserPassword(model, Convert.ToInt32(userId));
                if (response.Status == "Success")
                {
                    _toastNotification.AddSuccessToastMessage(response.Message);
                }
                else
                {
                    _toastNotification.AddErrorToastMessage(response.Message);
                }
                ViewBag.Message = response.Message;
            }

            // If validation fails or password change is unsuccessful, redisplay form with validation messages
            return View(model);
        }
    }
}