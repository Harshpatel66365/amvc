﻿using Microsoft.AspNetCore.Mvc;
using KobaWebApplication.Dto.Browser;
using KobaWebApplication.BusinessLogic.UnitOfWork;

namespace KobaWebApplication.Controllers
{
    public class BookController : Controller
    {
        private readonly IUnitOfWorkBL _unitOfWorkBL;

        public BookController(IUnitOfWorkBL unitOfWorkBL)
        {
            _unitOfWorkBL = unitOfWorkBL;
        }

        [HttpGet]
        public IActionResult Index(string BookCategory, string BookSrNo, string BookTitle)
        {
            var model = new BookRequestModel
            {
                BookCategory = BookCategory,
                BookSrNo = BookSrNo,
                BookTitle = BookTitle
            };
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> BookRequest(BookRequestModel model)
        {
            if (ModelState.IsValid)
            {
                // Call BL Method here
                var response = await _unitOfWorkBL.BrowserBL.RequestToBook(model);
                if (response)
                {
                    return Json(new { success = true, message = "Book requested successfully!" });
                }
                else
                {
                    return Json(new { success = false, message = "Book not requested successfully!" });
                }
            }

            return Json(new { success = false, message = "Book not requested successfully!" });
        }
    }
}