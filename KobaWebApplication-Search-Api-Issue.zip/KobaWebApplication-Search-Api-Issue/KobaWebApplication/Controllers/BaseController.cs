﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using KobaWebApplication.BusinessLogic.UnitOfWork;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc.Filters;

namespace KobaWebApplication.Admin.Controllers
{
    public class BaseController : Controller
    {
        public readonly IStringLocalizer<BaseController> _localizer;
        protected readonly IUnitOfWorkBL UnitOfWorkBL;
        protected string UserInit => Convert.ToString(HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value);

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            // Check if the user is authenticated
            if (!User.Identity.IsAuthenticated)
            {
                // Redirect to the login page
                context.Result = new RedirectToActionResult("Login", "Account", null);
            }
            base.OnActionExecuting(context);
        }

        public BaseController(IStringLocalizer<BaseController> localizer)
        {
            _localizer = localizer;
        }

        public BaseController(IStringLocalizer<BaseController> localizer, IUnitOfWorkBL unitOfWorkBL)
        {
            _localizer = localizer;
            UnitOfWorkBL = unitOfWorkBL;
        }
    }
}