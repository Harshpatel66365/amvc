﻿using KobaWebApplication.Models;
using Microsoft.AspNetCore.Mvc;
using NToastNotify;
using System.Data;
using KobaWebApplication.BusinessLogic.UnitOfWork;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace KobaWebApplication.Controllers
{
    public class LoginController : Controller
    {
        private string vFinalMsg;
        public static string vPass = "";
        public bool vLogin = false;
        private readonly IToastNotification _toastNotification;
        protected readonly IUnitOfWorkBL _unitOfWorkBL;
        private readonly IMemoryCache _cache;
        private readonly HttpContext _httpContext;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public LoginController(IToastNotification toastNotification, IUnitOfWorkBL unitOfWorkBL, IMemoryCache cache, IHttpContextAccessor httpContextAccessor)
        {
            _toastNotification = toastNotification;
            _unitOfWorkBL = unitOfWorkBL;
            _cache = cache;
            _httpContext = httpContextAccessor.HttpContext;
        }

        public IActionResult Index()
        {
            foreach (var item in _httpContext.Request.Cookies.Keys)
            {
                _httpContext.Response.Cookies.Delete(item);
            }

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(LoginModel loginModel, string returnPath = null)
        {
            try
            {
                string message;
                if (string.IsNullOrEmpty(loginModel.Username) || string.IsNullOrEmpty(loginModel.Password))
                {
                    message = "Please enter username & password to login.";
                    _toastNotification.AddErrorToastMessage(message);
                    return View("Index");
                }

                if (_unitOfWorkBL.LoginBL.ValidateUser(loginModel.Username, loginModel.Password, out message))
                {
                    var sessionValues = _unitOfWorkBL.LoginBL.GetUserSession(loginModel.Username, _httpContext);
                    int roleId = sessionValues.RoleId;
                    string fullName = sessionValues.UserName;
                    int userId = sessionValues.UserId;

                    var permissions = await _unitOfWorkBL.RolePermissionBL.GetClaimsByRoleIdAsync(Convert.ToInt32(roleId));

                    var claims = new List<Claim>
                                 {
                                     new Claim(ClaimTypes.GivenName, Convert.ToString(fullName)),
                                     new Claim(ClaimTypes.Name, loginModel.Username),
                                     new Claim(ClaimTypes.NameIdentifier, Convert.ToString(userId)),
                                     new Claim(ClaimTypes.Role, Convert.ToString(roleId))
                                 };

                    // Add user permissions to claims
                    claims.AddRange(permissions.Select(permission => new Claim("Permission", permission.ClaimValue)));

                    var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    var principal = new ClaimsPrincipal(identity);
                    var authProperties = new AuthenticationProperties
                    {
                        IsPersistent = true,
                        ExpiresUtc = DateTime.UtcNow.AddHours(1)
                    };

                    await _httpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, authProperties);

                    // Redirect to the original path if ReturnPath is provided
                    if (!string.IsNullOrEmpty(returnPath))
                    {
                        return Redirect(returnPath);
                    }

                    return RedirectToAction("LoginOptions", "Login");
                }
                else
                {
                    _toastNotification.AddErrorToastMessage(message);
                    return View("Index");
                }
            }
            catch (Exception ex)
            {
                _toastNotification.AddErrorToastMessage("An error occurred while processing your request." + ex.Message);
                throw ex;
                return View("Index");
            }
        }

        public async Task<IActionResult> LoginOptions()
        {
            var bhandar = await LoadBhandarList();
            var bhandarGroup = await LoadBhandarGroupList();
            var lang = await LoadLanguageList();
            if (bhandar && bhandarGroup && lang)
                return View();
            else
            {
                return RedirectToAction("Index", "Login");
            }
        }

        [HttpPost]
        public async Task<IActionResult> LoginOptions(LoginOptionsModel model)
        {
            var currentClaims = _httpContext.User.Claims.ToList();

            var additionalClaims = new List<Claim>
                                   {
                                        new Claim("BhandarOption", Convert.ToString(model.Option)??""),
                                        new Claim("BhandarGroup",Convert.ToString( model.BhandarGroup)??""),
                                        new Claim("BhandarList", Convert.ToString(model.BhandarList) ?? "")
                                   };

            var claimsDict = currentClaims.Where(c => c.Type != "Permission").ToDictionary(c => c.Type, c => c);
            foreach (var additionalClaim in additionalClaims)
            {
                if (claimsDict.ContainsKey(additionalClaim.Type))
                {
                    var existingClaim = claimsDict[additionalClaim.Type];
                    currentClaims.Remove(existingClaim);
                    currentClaims.Add(additionalClaim);
                }
                else
                {
                    currentClaims.Add(additionalClaim);
                }
            }

            var updatedIdentity = new ClaimsIdentity(currentClaims, CookieAuthenticationDefaults.AuthenticationScheme);
            var updatedPrincipal = new ClaimsPrincipal(updatedIdentity);

            var authProperties = new AuthenticationProperties
            {
                IsPersistent = true,
                ExpiresUtc = DateTime.UtcNow.AddHours(1)
            };

            await _httpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, updatedPrincipal, authProperties);

            return RedirectToAction("Index", "Home");
        }

        public async Task<IActionResult> Logout()
        {
            try
            {
                string currentUserInitial = Convert.ToString(_httpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value);

                _unitOfWorkBL.LoginBL.LogoutUser(currentUserInitial);
                _unitOfWorkBL.CommonBL.InsertUserTechnicalData(currentUserInitial, Environment.MachineName, "AddProc", "Logout");

                _httpContext.Response.Headers["Cache-Control"] = "no-cache, no-store, must-revalidate";
                _httpContext.Response.Headers["Pragma"] = "no-cache";
                _httpContext.Response.Headers["Expires"] = "-1";

                await _httpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            }
            catch (Exception ex)
            {
            }
            return View("LogoutRedirect");
        }

        private async Task<bool> LoadBhandarList()
        {
            try
            {
                if (!User.Identity.IsAuthenticated)
                {
                    return false;
                }
                string currentUserInitial = Convert.ToString(_httpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value);

                if (!string.IsNullOrEmpty(currentUserInitial))
                {
                    var bhandarList = await _unitOfWorkBL.LoginOptionBL.GetBhandarList(currentUserInitial);

                    // Set the list in ViewBag
                    ViewBag.BhandarList = bhandarList;
                }
                return true;
            }
            catch (Exception ex)
            {
                // Log the error
                Console.WriteLine($"Error in LoadBhandarList: {ex.Message}");
                return false;
            }
        }

        private async Task<bool> LoadBhandarGroupList()
        {
            try
            {
                if (!User.Identity.IsAuthenticated)
                {
                    return false;
                }
                string currentUserInitial = Convert.ToString(_httpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value);

                List<BhandarGroupViewModel> bhandarGroupList = new List<BhandarGroupViewModel>();

                if (!string.IsNullOrEmpty(currentUserInitial))
                {
                    bhandarGroupList = await _unitOfWorkBL.LoginOptionBL.LoadBhandarGroupListAsync(currentUserInitial);
                }

                // Set the list in ViewBag
                ViewBag.BhandarGroupList = bhandarGroupList;
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in Index: {ex.Message}");
                return false;
            }
        }

        private async Task<bool> LoadLanguageList()
        {
            try
            {
                if (!User.Identity.IsAuthenticated)
                {
                    return false;
                }
                var languageList = await _unitOfWorkBL.LoginOptionBL.GetLanguageList();
                ViewBag.LanguageList = languageList;
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in LoadLanguageList: {ex.Message}");
                return false;
            }
        }

        private bool UserLogin(string userId)
        {
            try
            {
                //var cmdCheckLogin = new SqlCommand("SELECT COUNT(*) FROM L_Login WHERE Usr_Init = @UserId", connection);
                //cmdCheckLogin.Parameters.AddWithValue("@UserId", userId);
                //int vIsExists = (int)cmdCheckLogin.ExecuteScalar();

                //if (vIsExists < 1)
                //{
                //    var cmdInsertLogin = new SqlCommand("INSERT INTO L_Login(Usr_Init, Login_Time, LogOut_Time, Machine_Name) Values(@UserId, GETDATE(), NULL, @MachineName)", connection);
                //    cmdInsertLogin.Parameters.AddWithValue("@UserId", userId);
                //    cmdInsertLogin.Parameters.AddWithValue("@MachineName", Environment.MachineName);
                //    cmdInsertLogin.ExecuteNonQuery();
                //}
                //else
                //{
                //    cmdCheckLogin.CommandText = "SELECT COUNT(*) FROM L_Login WHERE Usr_Init = @UserId AND LogOut_Time IS NULL";
                //    vIsExists = (int)cmdCheckLogin.ExecuteScalar();
                //    if (vIsExists > 0)
                //    {
                //        var cmdGetMachineName = new SqlCommand("SELECT Machine_Name FROM L_Login WHERE Usr_Init = @UserId AND LogOut_Time IS NULL", connection);
                //        cmdGetMachineName.Parameters.AddWithValue("@UserId", userId);
                //        string machineName = cmdGetMachineName.ExecuteScalar().ToString();

                //        vFinalMsg += GetReplacedMsg(GetMessage(((int)LoginMSG.ErrorAlreadyLogin).ToString(), connection), new string[] { userId, machineName }) + "\r\n";
                //        return false;
                //    }
                //    else
                //    {
                //        var cmdInsertLogin = new SqlCommand("INSERT INTO L_Login(Usr_Init, Login_Time, LogOut_Time, Machine_Name) Values(@UserId, GETDATE(), NULL, @MachineName)", connection);
                //        cmdInsertLogin.Parameters.AddWithValue("@UserId", userId);
                //        cmdInsertLogin.Parameters.AddWithValue("@MachineName", Environment.MachineName);
                //        cmdInsertLogin.ExecuteNonQuery();
                //    }
                //}
                return true;
            }
            catch (Exception ex)
            {
                // Log the error
                return false;
            }
        }

        private string GetMessage(string ErrorCode)
        {
            string vMsg = "";

            try
            {
                if (string.IsNullOrEmpty(ErrorCode))
                {
                    return vMsg;
                }
                else if (ErrorCode.LastIndexOf(",", StringComparison.Ordinal) == ErrorCode.Length - 1)
                {
                    vMsg = _unitOfWorkBL.LoginOptionBL.GetMessage(ErrorCode, 1);
                }
            }
            catch (Exception ex)
            {
                // Handle exception
                vMsg = ex.Message;
            }

            return vMsg;
        }

        private static string GetReplacedMsg(string Msg, string[] Val)
        {
            string vStr = Msg;
            try
            {
                for (int i = 0; i < Val.Count(); i++)
                {
                    vStr = vStr.Replace("<<" + System.Convert.ToString(i + 1) + ">>", Val[i]);
                }
            }
            catch (Exception ex)
            {
                vStr = ex.Message;
            }
            return vStr;
        }
    }
}