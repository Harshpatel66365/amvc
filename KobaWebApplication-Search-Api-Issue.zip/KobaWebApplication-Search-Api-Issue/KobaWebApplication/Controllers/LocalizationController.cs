using Microsoft.AspNetCore.Mvc;
using KobaWebApplication.Admin.Models;
using System.Diagnostics;
using KobaWebApplication.BusinessLogic.UnitOfWork;
using Microsoft.Extensions.Caching.Memory;
using KobaWebApplication.Dto.Home.EditRequestsDto;
using KobaWebApplication.Dto.Home.Unique_SuggestionDto;
using System.Security.Claims;
using KobaWebApplication.Dto.Home.PendingTaskDto;
using KobaWebApplication.Dto.Home.RoutinWorkDto;
using KobaWebApplication.Dto.Home.BookOverDueDto;
using KobaWebApplication.Admin.Controllers;
using Microsoft.Extensions.Localization;
using KobaWebApplication.Dto.Home.User_Error_Suggestion;
using KobaWebApplication.Dto.Home.Hp_Internal_Issue;
using KobaWebApplication.DataEntities.Result;
using KobaWebApplication.Dto.Home.L_DailyViewDto;
using KobaWebApplication.Dto.Home;
using Newtonsoft.Json.Linq;

namespace KobaWebApplication.Controllers
{
    public class LocalizationController : Controller
    {
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly ILogger<HomeController> _logger;
        private readonly IUnitOfWorkBL _unitOfWorkBL;
        private readonly IMemoryCache _cache;

        public LocalizationController(ILogger<HomeController> logger, IUnitOfWorkBL unitOfWorkBL, IMemoryCache memoryCache, IWebHostEnvironment webHostEnvironment)
        {
            _logger = logger;
            _unitOfWorkBL = unitOfWorkBL;
            _cache = memoryCache;
            _hostingEnvironment = webHostEnvironment;
        }

        [HttpGet]
        public IActionResult Index()
        {
            var model = _unitOfWorkBL.CommonBL.GetLocalizationData();
            return View(model);
        }

        [HttpPost]
        public IActionResult UpdateLocalization(Dictionary<string, string> EnglishValues, Dictionary<string, string> GujaratiValues, Dictionary<string, string> HindiValues)
        {
            var enJsonPath = Path.Combine(_hostingEnvironment.ContentRootPath, "Resources", "en.json");
            var guJsonPath = Path.Combine(_hostingEnvironment.ContentRootPath, "Resources", "gu.json");
            var hiJsonPath = Path.Combine(_hostingEnvironment.ContentRootPath, "Resources", "hi.json");

            var enJson = JObject.Parse(System.IO.File.ReadAllText(enJsonPath));
            var guJson = JObject.Parse(System.IO.File.ReadAllText(guJsonPath));
            var hiJson = JObject.Parse(System.IO.File.ReadAllText(hiJsonPath));

            // Update the JSON files with the new values
            foreach (var key in EnglishValues.Keys)
            {
                enJson[key] = EnglishValues[key];
                guJson[key] = GujaratiValues[key];
                hiJson[key] = HindiValues[key];
            }

            // Write the updated JSON back to the files
            System.IO.File.WriteAllText(enJsonPath, enJson.ToString());
            System.IO.File.WriteAllText(guJsonPath, guJson.ToString());
            System.IO.File.WriteAllText(hiJsonPath, hiJson.ToString());

            return RedirectToAction("Index");
        }
    }
}