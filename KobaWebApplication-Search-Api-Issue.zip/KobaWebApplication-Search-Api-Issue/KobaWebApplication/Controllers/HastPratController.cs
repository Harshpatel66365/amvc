﻿using KobaWebApplication.BusinessLogic.UnitOfWork;
using KobaWebApplication.Dto.Browser;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;
using NToastNotify;
using System.Security.Claims;

namespace KobaWebApplication.Controllers
{
    public class HastPratController : Controller
    {
        private readonly IUnitOfWorkBL _unitOfWorkBL;
        private readonly IToastNotification _toastNotification;
        private readonly IMemoryCache _memoryCache;
        private readonly HttpContext _httpContext;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public HastPratController(IUnitOfWorkBL unitOfWorkBL, IToastNotification toastNotification, IMemoryCache memoryCache, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWorkBL = unitOfWorkBL;
            _toastNotification = toastNotification;
            _memoryCache = memoryCache;
            _httpContext = httpContextAccessor.HttpContext;
        }

        public IActionResult Index()
        {
            ViewBag.SearchModel = TempData["SearchModel"]?.ToString();

            return View("HastPratSearchGrid");
        }

        [HttpPost]
        public async Task<IActionResult> HastPratSearchGridDetails(Hastprat_Search_Grid_Request_Dto model)
        {
            try
            {
                var home_ResponseDto = await _unitOfWorkBL.HastPratBL.GetHpInfoList(model);
                return Ok(home_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }
        public async Task<IActionResult> HastpratSearch()
        {
            await FillCityDropDown();
            await FillDashaCodeDropDown();
            await FillLDharmaCodeDropDown();
            await FillPurnataCodeDropDown();
            await FillPurnataRemarkCodeDropDown();

            if (User.Identity.IsAuthenticated)
            {

                string currentUserInitial = Convert.ToString(_httpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value);
                if (!string.IsNullOrEmpty(currentUserInitial))
                {
                    var bhandarList = await _unitOfWorkBL.LoginOptionBL.GetBhandarList(currentUserInitial);

                    // Set the list in ViewBag
                    ViewBag.BhandarName = bhandarList.FirstOrDefault(x => x.IsDefault.ToLower() == "y").BhandarName;
                    ViewBag.BhandarCode = bhandarList.FirstOrDefault(x => x.IsDefault.ToLower() == "y").BhandarCode;
                }
            }
            return PartialView("_HastpratSearchModalPopup");
        }
        [HttpPost]
        public async Task<IActionResult> HastpratSearch(Hastprat_Search_Request_Dto model)
        {
            var filterModelString = JsonConvert.SerializeObject(model);
            TempData["SearchModel"] = filterModelString;
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult AddHastPratInfo()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddHastPratInfo(AddHastpratInfoRequest_Dto? request)
        {
            _unitOfWorkBL.HastPratBL.AddHastPratInfo(request);
            return View();
        }
        private async Task FillCityDropDown()
        {
            var Cities = await _unitOfWorkBL.HastPratBL.GetCitiesList();
            var cityList = Cities
                               .Select(x => new SelectListItem
                               {
                                   Value = x.City_Key, // Use the mapped value
                                   Text = x.City_Nam + " " + x.State_Name + " " + x.Country_Name
                               })
                               .OrderBy(x => x.Text)
                               .ToList();

            ViewBag.CityList = cityList;
        }
        private async Task FillDashaCodeDropDown()
        {
            var l_Dasha_Code_s = await _unitOfWorkBL.HastPratBL.GetDashaCodeList();
            var dashaCodeList = l_Dasha_Code_s
                               .Select(x => new SelectListItem
                               {
                                   Value = x.Dasha_Short_Name, // Use the mapped value
                                   Text = x.Dasha_name
                               })
                               .OrderBy(x => x.Text)
                               .ToList();
            dashaCodeList.Insert(0,new SelectListItem {Value = "", Text = "Select" });
            ViewBag.DashacodeList = dashaCodeList;
        }
        private async Task FillLDharmaCodeDropDown()
        {
            var l_dharma_code_s = (await _unitOfWorkBL.HastPratBL.GetDharmaCodeList()).Where(d => d.For_Hp.ToLower() == "y");
            var dharmaCodeList = l_dharma_code_s
                               .Select(x => new SelectListItem
                               {
                                   Value = x.Dharma_Code, // Use the mapped value
                                   Text = x.Dharma_Name
                               })
                               .OrderBy(x => x.Text)
                               .ToList();
            dharmaCodeList.Insert(0,new SelectListItem {Value = "", Text = "Select" });
            ViewBag.DharmaCodeList = dharmaCodeList;
        }
        private async Task FillPurnataCodeDropDown()
        {
            var l_Puranata_Codes = await _unitOfWorkBL.HastPratBL.GetPurnataCodeList();
            var purnataCodeList = l_Puranata_Codes.Where(x => x.For_Hp.ToLower() == "y")
                               .Select(x => new SelectListItem
                               {
                                   Value = x.Purnata_Short_Name, // Use the mapped value
                                   Text = x.Purnata_Name
                               })
                               .OrderBy(x => x.Text)
                               .ToList();
            purnataCodeList.Insert(0,new SelectListItem {Value = "", Text = "Select" });

            ViewBag.PurnataCodeList = purnataCodeList;
        }
        private async Task FillPurnataRemarkCodeDropDown()
        {
            var l_Puranata_Remark_Codes = await _unitOfWorkBL.HastPratBL.GetPurnataRemarkCodeList();
            var purnataRemarkCodeList = l_Puranata_Remark_Codes
                               .Select(x => new SelectListItem
                               {
                                   Value = Convert.ToString(x.Purnata_Remark_Code), // Use the mapped value
                                   Text = x.Remark
                               })
                               .OrderBy(x => x.Text)
                               .ToList();
            purnataRemarkCodeList.Insert(0,new SelectListItem { Value = "", Text = "Select" });

            ViewBag.PurnataRemarkCodeList = purnataRemarkCodeList;
        }

    }
}
