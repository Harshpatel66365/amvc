﻿using AutoMapper;
using KobaWebApplication.BusinessLogic.UnitOfWork;
using KobaWebApplication.Dto.AdvanceSearch;
using KobaWebApplication.Dto.Browser;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using NToastNotify;

namespace KobaWebApplication.Controllers
{
    public class AdvanceSearchController : Controller
    {
        private readonly IUnitOfWorkBL _unitOfWorkBL;
        private readonly IToastNotification _toastNotification;
        private readonly IMemoryCache _memoryCache;
        private readonly IMapper _mapper;

        public AdvanceSearchController(IUnitOfWorkBL unitOfWorkBL, IMapper mapper)
        {
            _unitOfWorkBL = unitOfWorkBL;
            _mapper = mapper;
        }

        public async Task<IActionResult >Index()
        {
            return View();
        }
        public async Task<IActionResult> performSearch(SearchRequest searchRequest)
        {
            ViewBag.IsPaginationLoad = searchRequest.IsPaginationLoad;
            var result = await _unitOfWorkBL.BrowserBL.PerformSearchAsync(searchRequest);
            var CountResponse = await _unitOfWorkBL.BrowserBL.GetSearchCountsAsync(searchRequest.SearchTerm, searchRequest.IsExactSearch);
            if (result != null && !string.IsNullOrEmpty(searchRequest.SelectedIndex))
            {
                switch (searchRequest.SelectedIndex.ToLower())
                {
                    case "vidvan":
                        CountResponse.AuthorCount = result.TotalResults;
                        break;
                    case "kruti":
                        CountResponse.KrutiCount = result.TotalResults;
                        break;
                    case "prakashan":
                        CountResponse.publisherCount = result.TotalResults;
                        break;
                    case "hastprat":
                        CountResponse.hastpratCount = result.TotalResults;
                        break;

                    default:
                        break;
                }
            }
            ViewBag.SearchCounts = CountResponse;
            return PartialView("_SearchResult", result);
        }
        public async Task<IActionResult> performSearchLoadMore(SearchRequest searchRequest)
        {
            ViewBag.IsPaginationLoad = searchRequest.IsPaginationLoad;
            var result = await _unitOfWorkBL.BrowserBL.PerformSearchAsync(searchRequest);
            var CountResponse = await _unitOfWorkBL.BrowserBL.GetSearchCountsAsync(searchRequest.SearchTerm, searchRequest.IsExactSearch);
            if (result != null && !string.IsNullOrEmpty(searchRequest.SelectedIndex))
            {
                switch (searchRequest.SelectedIndex.ToLower())
                {
                    case "vidvan":
                        CountResponse.AuthorCount = result.TotalResults;
                        break;
                    case "kruti":
                        CountResponse.KrutiCount = result.TotalResults;
                        break;
                    case "prakashan":
                        CountResponse.publisherCount = result.TotalResults;
                        break;
                    case "hastprat":
                        CountResponse.hastpratCount = result.TotalResults;
                        break;

                    default:
                        break;
                }
            }
            ViewBag.SearchCounts = CountResponse;
            return PartialView("_SearchResultGridRows", result);
        }

        [HttpGet]
        public async Task<List<City_State_Country_View_Dto>> GetAllCitiesList()
        {
            var Cities = await _unitOfWorkBL.HastPratBL.GetCitiesList();
            return Cities;
        }
        [HttpGet]
        public async Task<List<L_Dasha_Code_Dto>> GetAllDashaCodeList()
        {
            var l_Dasha_Code_s = await _unitOfWorkBL.HastPratBL.GetDashaCodeList();
            return l_Dasha_Code_s;
        }

       
    }
}
