﻿using KobaWebApplication.BusinessLogic.UnitOfWork;
using KobaWebApplication.DataEntities.Result;
using KobaWebApplication.Dto.Browser;
using KobaWebApplication.Dto.DataGrid;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NToastNotify;
using System.Security.Claims;

namespace KobaWebApplication.Admin.Controllers
{
    public class BrowserController : Controller
    {
        private readonly IUnitOfWorkBL _unitOfWorkBL;
        private readonly IToastNotification _toastNotification;
        private readonly IMemoryCache _memoryCache;

        public BrowserController(IUnitOfWorkBL unitOfWorkBL, IToastNotification toastNotification, IMemoryCache memoryCache)
        {
            _unitOfWorkBL = unitOfWorkBL;
            _toastNotification = toastNotification;
            _memoryCache = memoryCache;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult PrivacyPolicy()
        {
            return View();
        }

        public IActionResult TermsOfService()
        {
            return View();
        }

 
        public async Task<IActionResult> performSearch(SearchRequest searchRequest)
        {
            ViewBag.IsPaginationLoad = searchRequest.IsPaginationLoad;
            var result = await _unitOfWorkBL.BrowserBL.PerformSearchAsync(searchRequest);
            var CountResponse = await _unitOfWorkBL.BrowserBL.GetSearchCountsAsync(searchRequest.SearchTerm, searchRequest.IsExactSearch);
            if (result != null && !string.IsNullOrEmpty(searchRequest.SelectedIndex))
            {
                switch (searchRequest.SelectedIndex.ToLower())
                {
                    case "vidvan":
                        CountResponse.AuthorCount = result.TotalResults;
                        break;
                    case "kruti":
                        CountResponse.KrutiCount = result.TotalResults;
                        break;
                    case "prakashan":
                        CountResponse.publisherCount = result.TotalResults;
                        break;
                    case "hastprat":
                        CountResponse.hastpratCount = result.TotalResults;
                        break;

                    default:
                        break;
                }
            }
            ViewBag.SearchCounts = CountResponse;
            return PartialView("_SearchResult", result);
        }

        public async Task<AdvanceFiltersDto> GetAdvanceSearchFilter(SearchRequest searchRequest)
        {
            ViewBag.IsPaginationLoad = searchRequest.IsPaginationLoad;
            var result = await _unitOfWorkBL.BrowserBL.GetAdvanceSearchFilterAsync(searchRequest);
            return result;
        }

        public async Task<IsPrakashanBookReq_Res_Dto> IsParakashanAvailableInLibrary(string prksnNo)
        {
            IsPrakashanBookReq_Res_Dto isPrakashanBookReq_Res_Dto = new IsPrakashanBookReq_Res_Dto();
            var result = await _unitOfWorkBL.BrowserBL.IsParakashanAvailableInLibrary(prksnNo);
            if (result != null && result.Result != null)
            {
                var source = JsonConvert.DeserializeObject<JObject>(result.Result.ToString());
                isPrakashanBookReq_Res_Dto = source.ToObject<IsPrakashanBookReq_Res_Dto>();
            }
            else
            {
                isPrakashanBookReq_Res_Dto.message = "Something went wrong !";
                isPrakashanBookReq_Res_Dto.isAvailabel = false;
                isPrakashanBookReq_Res_Dto.statusCode = 500;
            }
            return isPrakashanBookReq_Res_Dto;
        }
    }
}