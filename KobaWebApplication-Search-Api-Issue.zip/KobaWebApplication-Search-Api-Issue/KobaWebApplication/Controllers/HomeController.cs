using Microsoft.AspNetCore.Mvc;
using KobaWebApplication.Admin.Models;
using System.Diagnostics;
using KobaWebApplication.BusinessLogic.UnitOfWork;
using Microsoft.Extensions.Caching.Memory;
using KobaWebApplication.Dto.Home.EditRequestsDto;
using KobaWebApplication.Dto.Home.Unique_SuggestionDto;
using System.Security.Claims;
using KobaWebApplication.Dto.Home.PendingTaskDto;
using KobaWebApplication.Dto.Home.RoutinWorkDto;
using KobaWebApplication.Dto.Home.BookOverDueDto;
using KobaWebApplication.Admin.Controllers;
using Microsoft.Extensions.Localization;
using KobaWebApplication.Dto.Home.User_Error_Suggestion;
using KobaWebApplication.Dto.Home.Hp_Internal_Issue;
using KobaWebApplication.DataEntities.Result;
using KobaWebApplication.Dto.Home.L_DailyViewDto;
using KobaWebApplication.Dto.Home;
using KobaWebApplication.Dto.Home.User_Score_Board;

namespace KobaWebApplication.Controllers
{
    public class HomeController : BaseController
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IUnitOfWorkBL _unitOfWorkBL;
        private readonly IMemoryCache _cache;

        public HomeController(ILogger<HomeController> logger, IUnitOfWorkBL unitOfWorkBL, IMemoryCache memoryCache, IStringLocalizer<BaseController> localizer) : base(localizer)
        {
            _logger = logger;
            _unitOfWorkBL = unitOfWorkBL;
            _cache = memoryCache;
        }

        #region Default Home Page Implementations

        public IActionResult Index()
        {
            ViewData["Title"] = "Home Page";
            CancellationToken cancellationToken = new CancellationToken();
            DashboardCounts dashboardCounts = new DashboardCounts();
            var cacheCounts = _cache.Get<DashboardCounts>("DashboardCount_Cache");
            if (cacheCounts == null)
            {
                dashboardCounts = _unitOfWorkBL.HomeBL.GetDashboardCountsFromSP(UserInit, cancellationToken).Result;
                _cache.Set<DashboardCounts>("DashboardCount_Cache", dashboardCounts, DateTime.Now.AddHours(1));
            }
            else
            {
                dashboardCounts = cacheCounts;
            }

            return View(dashboardCounts);
        }

        [HttpPost]
        public async Task<IActionResult> GetHomePageData(L_Gmandir_Edit_Request_FilterDto dataTableFilterDto)
        {
            try
            {
                var home_ResponseDto = await _unitOfWorkBL.HomeBL.GetHomePageData(dataTableFilterDto);
                return Ok(home_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        #endregion Default Home Page Implementations

        public IActionResult Privacy()
        {
            string username = Convert.ToString(HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value);
            if (string.IsNullOrEmpty(username))
            {
                return RedirectToAction("Index", "Login");
            }
            ViewData["username"] = username;
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        #region Edit Request Implementations

        [HttpGet]
        public async Task<IActionResult> _Kr_Edit_Req_Partial(string isReceiver)
        {
            ViewData["IsReceiver_Kr"] = isReceiver;
            return PartialView("_Kr_Edit_Req_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetKrEditReqData(Kr_Edit_Request_FilterDto dataTableFilterDto)
        {
            try
            {
                var kr_Edit_ResponseDto = await _unitOfWorkBL.HomeBL.GetKr_Edit_ReqByUser(dataTableFilterDto, UserInit);
                return Ok(kr_Edit_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        public async Task<IActionResult> _Hp_Edit_Req_Partial(string isReceiver)
        {
            ViewData["IsReceiver_Hp"] = isReceiver;
            return PartialView("_Hp_Edit_Req_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetHpEditReqData(Hp_Edit_Request_FilterDto dataTableFilterDto)
        {
            try
            {
                var hp_Edit_ResponseDto = await _unitOfWorkBL.HomeBL.GetHp_Edit_ReqByUser(dataTableFilterDto, UserInit);
                return Ok(hp_Edit_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        public async Task<IActionResult> _Vid_Edit_Req_Partial(string isReceiver)
        {
            ViewData["IsReceiver_Vid"] = isReceiver;
            return PartialView("_Vid_Edit_Req_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetVidEditReqData(Vid_Edit_Request_FilterDto dataTableFilterDto)
        {
            try
            {
                var vid_Edit_ResponseDto = await _unitOfWorkBL.HomeBL.GetVid_Edit_ReqByUser(dataTableFilterDto, UserInit);
                return Ok(vid_Edit_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        public async Task<IActionResult> _VidGach_Edit_Req_Partial(string isReceiver)
        {
            ViewData["IsReceiver_VidGach"] = isReceiver;
            return PartialView("_VidGach_Edit_Req_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetVidGachEditReqData(Vid_Gach_Edit_Request_FilterDto dataTableFilterDto)
        {
            try
            {
                var vid_Edit_ResponseDto = await _unitOfWorkBL.HomeBL.GetVid_Gach_Edit_ReqByUser(dataTableFilterDto, UserInit);
                return Ok(vid_Edit_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        public async Task<IActionResult> _Mag_Edit_Req_Partial(string isReceiver)
        {
            ViewData["IsReceiver_Mag"] = isReceiver;
            return PartialView("_Mag_Edit_Req_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetMagEditReqData(Mag_Edit_Request_FilterDto dataTableFilterDto)
        {
            try
            {
                var vid_Edit_ResponseDto = await _unitOfWorkBL.HomeBL.GetMag_Edit_ReqByUser(dataTableFilterDto, UserInit);
                return Ok(vid_Edit_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        public async Task<IActionResult> _Prksn_Edit_Req_Partial(string isReceiver)
        {
            ViewData["IsReceiver_Prksn"] = isReceiver;
            return PartialView("_Prksn_Edit_Req_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetPrksnEditReqData(Prksn_Edit_Request_FilterDto dataTableFilterDto)
        {
            try
            {
                var kr_Edit_ResponseDto = await _unitOfWorkBL.HomeBL.GetPrksn_Edit_ReqByUser(dataTableFilterDto, UserInit);
                return Ok(kr_Edit_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        public async Task<IActionResult> _Pblsr_Edit_Req_Partial(string isReceiver)
        {
            ViewData["IsReceiver_Pblsr"] = isReceiver;
            return PartialView("_Pblsr_Edit_Req_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetPblsrEditReqData(Pblsr_Edit_Request_FilterDto dataTableFilterDto)
        {
            try
            {
                var pblsr_Edit_ResponseDto = await _unitOfWorkBL.HomeBL.GetPblsr_Edit_ReqByUser(dataTableFilterDto, UserInit);
                return Ok(pblsr_Edit_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        public async Task<IActionResult> _MagBind_Edit_Req_Partial(string isReceiver)
        {
            ViewData["IsReceiver_MagBind"] = isReceiver;
            return PartialView("_MagBind_Edit_Req_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetMagBindEditReqData(Mag_Bind_Edit_Request_FilterDto dataTableFilterDto)
        {
            try
            {
                var mg_Edit_ResponseDto = await _unitOfWorkBL.HomeBL.GetMag_Bind_Edit_ReqByUser(dataTableFilterDto, UserInit);
                return Ok(mg_Edit_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        #endregion Edit Request Implementations

        #region Unique Suggestions Implementations

        [HttpGet]
        public async Task<IActionResult> _Kr_Unqie_Suggestion_Partial(string isReceiver)
        {
            ViewData["IsReceiver_KrUnq"] = isReceiver;
            return PartialView("_Kr_Unqie_Suggestion_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetKrUniqueReqData(Kr_Unique_Suggestion_FilterDto dataTableFilterDto)
        {
            try
            {
                var krUnique_ResponseDto = await _unitOfWorkBL.HomeBL.GetKr_Unique_SuggestionByUser(dataTableFilterDto, UserInit);
                return Ok(krUnique_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        public async Task<IActionResult> _Vid_Unqie_Suggestion_Partial(string isReceiver)
        {
            ViewData["IsReceiver_VidUnq"] = isReceiver;
            return PartialView("_Vid_Unqie_Suggestion_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetVidUniqueReqData(Vid_Unique_Suggestion_FilterDto dataTableFilterDto)
        {
            try
            {
                var vidUnique_ResponseDto = await _unitOfWorkBL.HomeBL.GetVid_Unique_SuggestionByUser(dataTableFilterDto, UserInit);
                return Ok(vidUnique_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        public async Task<IActionResult> _Vid_Gach_Unqie_Suggestion_Partial(string isReceiver)
        {
            ViewData["IsReceiver_VidGachUnq"] = isReceiver;
            return PartialView("_Vid_Gach_Unqie_Suggestion_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetVidGachUniqueReqData(Vid_Gach_Unique_Suggestion_FilterDto dataTableFilterDto)
        {
            try
            {
                var vidGachUnique_ResponseDto = await _unitOfWorkBL.HomeBL.GetVid_Gach_Unique_SuggestionByUser(dataTableFilterDto, UserInit);
                return Ok(vidGachUnique_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        public async Task<IActionResult> _Pblsr_Unqie_Suggestion_Partial(string isReceiver)
        {
            ViewData["IsReceiver_PblsrUnq"] = isReceiver;
            return PartialView("_Pblsr_Unqie_Suggestion_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetPblsrUniqueReqData(Pblsr_Unique_Suggestion_FilterDto dataTableFilterDto)
        {
            try
            {
                var vidGachUnique_ResponseDto = await _unitOfWorkBL.HomeBL.GetPblsr_Unique_SuggestionByUser(dataTableFilterDto, UserInit);
                return Ok(vidGachUnique_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        public async Task<IActionResult> _Prksn_Unqie_Suggestion_Partial(string isReceiver)
        {
            ViewData["IsReceiver_PrksnUnq"] = isReceiver;
            return PartialView("_Prksn_Unqie_Suggestion_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetPrksnUniqueReqData(Prksn_Unique_Suggestion_FilterDto dataTableFilterDto)
        {
            try
            {
                var vidGachUnique_ResponseDto = await _unitOfWorkBL.HomeBL.GetPrksn_Unique_SuggestionByUser(dataTableFilterDto, UserInit);
                return Ok(vidGachUnique_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        #endregion Unique Suggestions Implementations

        #region Pending Task Implementation

        [HttpGet]
        public async Task<IActionResult> _PendingTask_Partial()
        {
            return PartialView("_PendingTask_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetPendingTaskData(GPendingWorkViewFilterDto dataTableFilterDto)
        {
            try
            {
                var pendingTask_ResponseDto = await _unitOfWorkBL.HomeBL.GetGPendingWorkByUser(dataTableFilterDto, UserInit);
                return Ok(pendingTask_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        #endregion Pending Task Implementation

        #region Routin Work Implementation

        [HttpGet]
        public async Task<IActionResult> _RoutinWork_Partial()
        {
            return PartialView("_RoutinWork_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetRoutinWorkData(RoutineWorkViewFilterDto dataTableFilterDto)
        {
            try
            {
                var pendingTask_ResponseDto = await _unitOfWorkBL.HomeBL.GetRoutineWorkByUser(dataTableFilterDto, UserInit);
                return Ok(pendingTask_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        #endregion Routin Work Implementation

        #region Remark Management Implementation

        [HttpGet]
        public async Task<IActionResult> _RemarkManagement_Partial(string isReceiver)
        {
            ViewData["IsRemarkAs_MainUser"] = isReceiver;
            bool isRemark = Convert.ToBoolean(isReceiver);
            try
            {
                var data = await _unitOfWorkBL.HomeBL.GetRemarkDataByUser(isRemark, UserInit);
                return PartialView("_RemarkManagement_Partial", data);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        #endregion Remark Management Implementation

        #region Book OverDues Implementation

        [HttpGet]
        public async Task<IActionResult> _Book_OverDues_Partial(int type)
        {
            ViewData["Book_OverDue_Type"] = type;
            return PartialView("_Book_OverDues_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetBookOVerDuesData(BookIssueFilterDto dataTableFilterDto)
        {
            try
            {
                var bookOverdue_ResponseDto = await _unitOfWorkBL.HomeBL.GetBookOverdueViewDataByUser(dataTableFilterDto, UserInit);
                return Ok(bookOverdue_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        #endregion Book OverDues Implementation

        #region User Error Suggestion Score Board Implementation

        [HttpGet]
        public async Task<IActionResult> _Error_Suggestion_Partial(int type)
        {
            ViewData["Error_Type"] = type;
            return PartialView("_Error_Suggestion_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetErrorsViewData(ErrorDetailFilterDto dataTableFilterDto)
        {
            try
            {
                var bookOverdue_ResponseDto = await _unitOfWorkBL.HomeBL.GetErrorDetailsViewData(dataTableFilterDto, UserInit);
                return Ok(bookOverdue_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        #endregion User Error Suggestion Score Board Implementation

        #region Hp Internal Issue Detail Implementation

        [HttpGet]
        public async Task<IActionResult> _Hp_InternalIssue_Partial(int type)
        {
            ViewData["Hp_IssueType"] = type;
            return PartialView("_Hp_InternalIssue_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetHp_Internal_Issue_Data(Hp_Internal_Issue_FilterDto dataTableFilterDto)
        {
            try
            {
                var bookOverdue_ResponseDto = await _unitOfWorkBL.HomeBL.GetHp_Internal_IssueByUser(dataTableFilterDto, UserInit);
                return Ok(bookOverdue_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        #endregion Hp Internal Issue Detail Implementation

        #region User Add Update Score Board Implementation

        public async Task<IActionResult> _User_Score_Board_Partial(CancellationToken cancellationToken)
        {
            DateTime sdate = DateTime.Now.AddDays(-1).Date;
            DateTime eDate = DateTime.Now.Date;
            ViewData["StartDate"] = sdate;
            ViewData["EndDate"] = eDate;

            return PartialView("_User_Score_Board_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetUserScoreBoardData(UserScoreBoardFilterDto dataTableFilterDto, CancellationToken cancellationToken)
        {
            UserScoreBoardViewModel _userScoreViewModel = new UserScoreBoardViewModel();

            dataTableFilterDto.Username = UserInit;
            try
            {
                var data = await _unitOfWorkBL.HomeBL.GetUserScoreBoardFromSP(dataTableFilterDto, cancellationToken);

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        #endregion User Add Update Score Board Implementation

        #region Daily Work Logs Implementation

        [HttpGet]
        public async Task<IActionResult> _DailyWorkLogs_Partial(string startDate, string endDate)
        {
            DateTime sdate = DateTime.Parse(startDate);
            DateTime eDate = DateTime.Parse(endDate).AddDays(1).AddTicks(-1);
            ViewData["StartDate"] = startDate;
            ViewData["EndDate"] = endDate;
            return PartialView("_DailyWorkLogs_Partial");
        }

        [HttpPost]
        public async Task<IActionResult> GetDailyWorkLogsData(DailyViewFilterDto dataTableFilterDto)
        {
            try
            {
                var dailyWork_ResponseDto = await _unitOfWorkBL.HomeBL.GetDailyViewDataByUser(dataTableFilterDto, UserInit);
                return Ok(dailyWork_ResponseDto);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        #endregion Daily Work Logs Implementation
    }
}