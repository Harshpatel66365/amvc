﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using KobaWebApplication.BusinessLogic.UnitOfWork;
using KobaWebApplication.Dto.Role;
using NToastNotify;
using Microsoft.AspNetCore.Mvc.Rendering;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Core.Constants;
using KobaWebApplication.Dto.RolePermission;
using Microsoft.Extensions.Localization;

namespace KobaWebApplication.Admin.Controllers
{
    public class RolesController : BaseController
    {
        private readonly IUnitOfWorkBL _unitOfWorkBL;
        private readonly IToastNotification _toastNotification;
        private readonly IMemoryCache _memoryCache;

        public RolesController(IUnitOfWorkBL unitOfWorkBL, IToastNotification toastNotification, IMemoryCache memoryCache, IStringLocalizer<BaseController> localizer) : base(localizer)
        {
            _unitOfWorkBL = unitOfWorkBL;
            _toastNotification = toastNotification;
            _memoryCache = memoryCache;
        }

        public async Task<IActionResult> Index(CancellationToken cancellationToken)
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> GetRolesDataTable(RoleDataTableFilterDto dataTableFilterDto)
        {
            var Roles = await _unitOfWorkBL.RoleBL.GetRoleDataTable(dataTableFilterDto);
            return Ok(Roles);
        }

        [HttpPost]
        public async Task<IActionResult> CreateRole(string name)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(name))
                {
                    _toastNotification.AddErrorToastMessage("Role assigned successfully!");
                    return Json(new { success = false, message = "Role name cannot be empty." });
                }

                var role = new Role { Name = name };
                await _unitOfWorkBL.RoleBL.CreateRole(name);

                _toastNotification.AddSuccessToastMessage("Role created successfully!");
                return Json(new { success = true });
            }
            catch
            {
                return Json(new { success = false, message = "Failed to create role." });
            }
        }

        public async Task<IActionResult> RolePermission(string Id, CancellationToken cancellationToken)
        {
            RoleRequestDto mRoleRequestDto = new RoleRequestDto();

            if (Id != null)
            {
                var allPermissions = ApplicationIdentityConstants.Permissions.GetAllPermissions();
                var rolePermissionResponseDto = await _unitOfWorkBL.RolePermissionBL.GetRolePermissions(Id, allPermissions);

                mRoleRequestDto = await _unitOfWorkBL.RoleBL.GetRoleNameID(Convert.ToInt32(Id), rolePermissionResponseDto);
                return View(mRoleRequestDto);
            }
            else
                return View(mRoleRequestDto);
        }

        [HttpPost]
        public async Task<JsonResult> CreateRolePermission([FromForm] RolePermissionRequestDto rolePermissionResponseDto, CancellationToken cancellationToken)
        {
            try
            {
                if (rolePermissionResponseDto.IsChecked == "true")
                    await _unitOfWorkBL.RolePermissionBL.AddClaimToRoleAsync(Convert.ToInt32(rolePermissionResponseDto.RoleId), "Permission", rolePermissionResponseDto.Permission);
                else
                    await _unitOfWorkBL.RolePermissionBL.RemoveClaimToRoleAsync(Convert.ToInt32(rolePermissionResponseDto.RoleId), "Permission", rolePermissionResponseDto.Permission);

                _toastNotification.AddSuccessToastMessage("Role permission updated successfully!");
                return Json("success");
            }
            catch (Exception ex)
            {
                return Json(ex.Message);
            }
        }
    }
}