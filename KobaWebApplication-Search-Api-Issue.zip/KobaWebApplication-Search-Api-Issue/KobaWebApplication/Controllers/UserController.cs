﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using KobaWebApplication.BusinessLogic.UnitOfWork;
using NToastNotify;
using KobaWebApplication.Dto.DataGrid;
using KobaWebApplication.Dto.User;
using AutoMapper;

namespace KobaWebApplication.Admin.Controllers
{
    public class UserController : Controller
    {
        private readonly IUnitOfWorkBL _unitOfWorkBL;
        private readonly IToastNotification _toastNotification;
        private readonly IMemoryCache _memoryCache;
        private readonly IMapper _mapper;

        public UserController(IUnitOfWorkBL unitOfWorkBL, IMapper mapper)
        {
            _unitOfWorkBL = unitOfWorkBL;
            _mapper = mapper;
        }

        public async Task<IActionResult> Index(CancellationToken cancellationToken)
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> GetUsers(UserFilterDto dataTableFilterDto)
        {
            var users = await _unitOfWorkBL.UserBL.GetUserDataTable(dataTableFilterDto);
            return Ok(users);
        }
    }
}