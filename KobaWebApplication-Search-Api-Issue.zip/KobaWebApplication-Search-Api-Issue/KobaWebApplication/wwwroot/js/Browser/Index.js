﻿let pageNumber = 1;
let IsSearchBtn = 0;
const pageSize = 10;
let isFetching = false; // To prevent multiple requests
var CurrentselectedIndex = "";
$(document).ready(function () {

    var searchText = document.getElementById("searchTextBox").value;
    if (searchText == "") {
        $("#divAdvanceSearchResult").addClass('d-none');
    }
    $(".category-checkbox").on('change', function () {
        const searchTerm = document.getElementById("searchTextBox").value;
        if ($(".category-checkbox:checked").length === 0) {
            $(this).prop('checked', true);
            toastr.error("At least one category must be selected. You cannot unselect this category.");
            return;
        }
        if (searchTerm == "") {
            toastr.error('Search term is mandetory.!');
            $(".category-checkbox").not(this).prop('checked', false);
            return;
        }
        $(".category-checkbox").not(this).prop('checked', false);
        var IndexName = $(this).data('category');
        $("#advancedCategoryDropdown").val(IndexName);
        performSearch(IndexName);
    });
});
function performSearch(IndexName, IsSearchBtn = 0) {
    $("#divAdvanceSearchResult").removeClass('d-none');
    pageNumber = 1;
    const searchTerm = document.getElementById("searchTextBox").value;
    if (searchTerm == "") {
        toastr.error('Search term is mandetory.!');
        return;
    }
    var IsAdvanceSearch = true;
    var selectedIndex;
    if (IndexName == 'find' && CurrentselectedIndex == "") {
        selectedIndex = 'All';
        IsAdvanceSearch = false;
        updateAdvancedFilters(selectedIndex);
    } else if (IndexName != 'find' && CurrentselectedIndex != "") {
        selectedIndex = IndexName;
        IsAdvanceSearch = false;
        updateAdvancedFilters(selectedIndex);
    }
    else if (IndexName == 'find' && CurrentselectedIndex != "" && IsSearchBtn == 1) {
        selectedIndex = $(".category-checkbox:checked").data('category');
        IsAdvanceSearch = true;
        updateAdvancedFilters(selectedIndex);
    }
    else {
        selectedIndex = CurrentselectedIndex;
    }
    const isExactSearch = document.getElementById("isExactSearchToggle").checked;
    CurrentselectedIndex = selectedIndex;
    // Initialize filter criteria if advanced search is enabled
    let filterCriterias = [];

    if (IsAdvanceSearch) {
        var AdvancedSearchIndex = $("#advancedCategoryDropdown").val();

        // Common filter array to hold the criteria

        if (AdvancedSearchIndex === "Hastprat") {
            //var BhandarName = $("#bhandar_Short_Name").val();
            var BhandarName = getCheckedValues("bhandar_Short_Name");
            var commaSeparatedBhandarNames;
            if (BhandarName && BhandarName.length > 0) {
                commaSeparatedBhandarNames = BhandarName.join(','); // Join the array into a comma-separated string
            }
            if (BhandarName && BhandarName.length > 0) {
                const fieldName = "bhandar_Short_Name";
                const searchTerm = BhandarName;
                filterCriterias.push({
                    IndexName: AdvancedSearchIndex,
                    FieldName: fieldName,
                    SearchTerm: commaSeparatedBhandarNames,
                    start: 0,
                    end: 0
                });
            }

            var FromDate = $("#start").val();
            var ToDate = $("#end").val();
            if (FromDate) {
                if (!ToDate) {
                    toastr.error('To date is mandetory for search');
                    return;
                } else {
                    // Add date criteria if both dates are provided
                    filterCriterias.push({
                        IndexName: AdvancedSearchIndex,
                        FieldName: "year",
                        SearchTerm: "Search Term",
                        start: FromDate,
                        end: ToDate
                    });
                }
            }

            // Add other fields similarly as required
            //var Lipi = $("#lipi_Short_Nm").val();
            var Lipi = getCheckedValues("lipi_Short_Nm");
            var commaSeparatedLipi;
            if (Lipi && Lipi.length > 0) {
                commaSeparatedLipi = Lipi.join(','); // Join the array into a comma-separated string
            }
            if (Lipi && Lipi.length > 0) {
                filterCriterias.push({
                    IndexName: AdvancedSearchIndex,
                    FieldName: "lipi_Short_Nm",
                    SearchTerm: commaSeparatedLipi,
                    start: 0,
                    end: 0
                });
            }
        } else if (AdvancedSearchIndex === "Kruti") {
            //var Language = $("#language").val();
            var Language = getCheckedValues("language");
            if (Language && Language.length > 0) {
                var commaSeparatedLanguages = Language.join(','); // Join the array into a comma-separated string
            }
            if (Language && Language.length > 0) {
                filterCriterias.push({
                    IndexName: AdvancedSearchIndex,
                    FieldName: "language",
                    SearchTerm: commaSeparatedLanguages,
                    start: 0,
                    end: 0
                });
            }

            var FromYear = $("#start").val();
            var ToYear = $("#end").val();
            if (FromYear) {
                if (!ToYear) {
                    toastr.error('To date is mandetory for search');
                    return;
                } else {
                    filterCriterias.push({
                        IndexName: AdvancedSearchIndex,
                        FieldName: "year",
                        SearchTerm: "Search Term",
                        start: FromYear,
                        end: ToYear
                    });
                }
            }
        } else if (AdvancedSearchIndex === "Prakashan") {
            //var PublisherName = $("#pblsr_Nam").val();
            var PublisherName = getCheckedValues("pblsr_Nam");
            var commaSeparatedPublisherName;
            if (PublisherName && PublisherName.length > 0) {
                commaSeparatedPublisherName = PublisherName.join(','); // Join the array into a comma-separated string
            }
            if (PublisherName && PublisherName.length > 0) {
                filterCriterias.push({
                    IndexName: AdvancedSearchIndex,
                    FieldName: "pblsr_Nam",
                    SearchTerm: commaSeparatedPublisherName,
                    start: 0,
                    end: 0
                });
            }

            var FromPrakashanYear = $("#start").val();
            var ToPrakashanYear = $("#end").val();
            if (FromPrakashanYear) {
                if (!ToPrakashanYear) {
                    toastr.error('To date is mandetory for search');
                    return;
                } else {
                    filterCriterias.push({
                        IndexName: AdvancedSearchIndex,
                        FieldName: "year",
                        SearchTerm: "Search Term",
                        start: FromPrakashanYear,
                        end: ToPrakashanYear
                    });
                }
            }
        }
        else if (AdvancedSearchIndex === "Vidvan") {
            var FromYear = $("#start").val();
            var ToYear = $("#end").val();
            if (FromYear) {
                if (!ToYear) {
                    toastr.error('To date is mandetory for search');
                    return;
                } else {
                    filterCriterias.push({
                        IndexName: AdvancedSearchIndex,
                        FieldName: "year",
                        SearchTerm: "year",
                        start: FromYear,
                        end: ToYear
                    });
                }
            }
        }
    }

    ShowLoader("show");
    // Make an AJAX call to your new search action
    $.ajax({
        url: 'AdvanceSearch/PerformSearch', // Call the new action
        type: 'POST',
        data: {
            SearchTerm: searchTerm,
            SelectedIndex: selectedIndex,
            IsExactSearch: !isExactSearch,
            IsAdvanceSearch: IsAdvanceSearch,
            filterCriterias: filterCriterias, // Add filter criteria if advanced search is enabled
            PageNumber: 1,  // Default page number
            PageSize: 10    // Default page size
        },
        success: function (response) {
            $("#searchIntroDiv").hide();
            $("#PartialView").html(response);
            $("#mainAllCount").text($("#allCount").text().trim());
            $("#mainAuthorCount").text($("#authorCount").text().trim());
            $("#mainKrutiCount").text($("#krutiCount").text().trim());
            $("#mainHastPratCount").text($("#hastpratCount").text().trim());
            $("#mainPublisherCount").text($("#publisherCount").text().trim());
            const filtersDiv = document.getElementById('advancedSearchFilters');
            filtersDiv.style.display = filtersDiv.style.display = 'block';
            ShowLoader("hide");
        },
        error: function () {
            toastr.error('Something went wrong while searching.!');
            ShowLoader("hide");
        }
    });
}

function updateAdvancedFilters(Indexname) {
    const selectedIndex = Indexname;
    document.getElementById('advancedCategoryDropdown').value = Indexname;
    const dynamicFiltersDiv = document.getElementById('dynamicFilters');
    dynamicFiltersDiv.innerHTML = ''; // Clear existing inputs

    let filtersHtml = '';
    if (selectedIndex === "Hastprat") {
        filtersHtml += `<div class="description-item"><label class="filter-label">Bhandar Name:</label><div id="bhandar_Short_Name" class="filter-list-data" placeholder="Bhandar Name"></div></div>`;
        filtersHtml += `<div class="description-item"><label class="filter-label">Lipi:</label><div id="lipi_Short_Nm" class="filter-list-data" placeholder="Lipi"></div></div>`;
        filtersHtml += `
        <div class="description-item">
            <label class="filter-label">Period</label>
            <div class="d-flex">
                <input type="text" class="form-control me-2" data-value="year" id="start" placeholder="From" style="flex: 1;" />
                <input type="text" class="form-control"  data-value="year" id="end" placeholder="To" style="flex: 1;" />
            </div>
        </div>`;
    }
    else if (selectedIndex === "Kruti") {
        filtersHtml += `<div class="description-item"><label class="filter-label">Language:</label><div id="language" class="filter-list-data" placeholder="Language"></div></div>`;
        filtersHtml += `
        <div class="description-item ">
            <label class="filter-label">Period</label>
            <div class="d-flex">
                <input type="text" class="form-control me-2"  data-value="year_Value" id="start" placeholder="From" style="flex: 1;" />
                <input type="text" class="form-control" id="end"  data-value="year_Value" placeholder="To" style="flex: 1;" />
            </div>
        </div>`;
    }
    else if (selectedIndex === "Prakashan") {
        filtersHtml += `<div class="description-item"><label class="filter-label">Publisher Name:</label><div id="pblsr_Nam" class="filter-list-data" placeholder="Publisher Name"></div></div>`;
        filtersHtml += `
        <div class="description-item">
            <label class="filter-label">Period</label>
            <div class="d-flex">
                <input type="text" class="form-control me-2" data-value="prksn_Year" id="start" placeholder="From" style="flex: 1;" />
                <input type="text" class="form-control"  data-value="prksn_Year" id="end" placeholder="To" style="flex: 1;" />
            </div>
        </div>`;
    }
    else if (selectedIndex === "Vidvan") {
        filtersHtml += `
        <div class="description-item">
            <label class="filter-label">Period</label>
            <div class="d-flex">
                <input type="text" class="form-control me-2" data-value="year" id="start" placeholder="From" style="flex: 1;" />
                <input type="text" class="form-control"  data-value="year" id="end" placeholder="To" style="flex: 1;" />
            </div>
        </div>`;
    }

    dynamicFiltersDiv.innerHTML = filtersHtml; // Insert new inputs
    const searchTerm = document.getElementById("searchTextBox").value;
    if (searchTerm == "") {
        toastr.error('Search term is mandetory.!');
        return;
    }

    const isExactSearch = document.getElementById("isExactSearchToggle").checked;
    const isAdvanceSearch = false;
    CurrentselectedIndex = selectedIndex;
    let filterCriterias = [];

    ShowLoader("show");
    $.ajax({
        url: 'Browser/GetAdvanceSearchFilter', // Call the new action
        type: 'POST',
        data: {
            SearchTerm: searchTerm,
            SelectedIndex: selectedIndex,
            IsExactSearch: !isExactSearch,
            PageNumber: 1,  // Default page number
            PageSize: 10    // Default page size
        },
        success: function (response) {
            ShowLoader("hide");
            FillFilterValues(response, selectedIndex);
        },
        error: function () {
            toastr.error('Something went wrong while searching.!');
            ShowLoader("hide");
        }
    });
}

function FillFilterValues(response, selectedIndex) {
    // Populate Bhandar and Lipi dropdowns for Hastprat
    if (selectedIndex === "Hastprat") {
        populateSelectArray(response.bhandarInfoDtos, 'bhandar_Short_Name');
        populateSelectArray(response.lipiInfoDtos, 'lipi_Short_Nm');
    }

    // Populate Language dropdown for Kruti
    if (selectedIndex === "Kruti") {
        populateSelectArray(response.languageInfoDtos, 'language');
    }

    // Populate Publisher Name dropdown for Prakashan
    if (selectedIndex === "Prakashan") {
        populateSelectArray(response.publisherInfoDtos, 'pblsr_Nam');
    }
}

function populateSelectArray(optionsArray, selectId) {
    const selectElement = document.getElementById(selectId);
    selectElement.innerHTML = ''; // Clear existing options

    // Clear the select element attributes
    selectElement.removeAttribute('multiple'); // Remove the multiple attribute since we are replacing with checkboxes

    if (optionsArray && optionsArray.length > 0) {
        const checkboxContainer = document.createElement('div');
        optionsArray.forEach(item => {
            const { name, count } = item;
            const innerDiv = document.createElement('div');
            innerDiv.classList = 'filter-item';

            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.classList = 'filter-checkbox';
            checkbox.value = name;
            checkbox.name = selectId; // Keep the name as the selectId for easy reference

            const label = document.createElement('label');
            label.textContent = `${name} (${count})`;

            innerDiv.appendChild(checkbox);
            innerDiv.appendChild(label);

            checkboxContainer.appendChild(innerDiv);
        });

        selectElement.appendChild(checkboxContainer);
        selectElement.disabled = false;
    } else {
        selectElement.innerHTML = '<p>No Data</p>';
        selectElement.disabled = true;
    }
}

function getCheckedValues(checkBoxName) {
    const checkedValues = [];
    const checkboxes = document.querySelectorAll('input[name="' + checkBoxName + '"]:checked');

    checkboxes.forEach(checkbox => {
        checkedValues.push(checkbox.value);
    });

    return checkedValues;
}
function ClearFilters() {
    $('#dynamicFilters').find('input[type="checkbox"]').prop('checked', false);
    $('.category-checkbox').find('input[type="checkbox"]').prop('checked', false);
    $('#allCheckbox').prop('checked', true).trigger('change');
    $('#dynamicFilters').find('input[type="text"]').val('');
}
function loadMoreResults() {
    if (isFetching) return;

    isFetching = true;
    pageNumber++; // Increment the page number

    const searchTerm = document.getElementById("searchTextBox").value;
    const selectedIndex = document.getElementById("advancedCategoryDropdown").value;
    const isExactSearch = document.getElementById("isExactSearchToggle").checked;
    const isAdvanceSearch = true;

    let filterCriterias = [];
    if (isAdvanceSearch) {
        var AdvancedSearchIndex = $("#advancedCategoryDropdown").val();

        // Common filter array to hold the criteria

        if (AdvancedSearchIndex === "Hastprat") {
            //var BhandarName = $("#bhandar_Short_Name").val();
            var BhandarName = getCheckedValues("bhandar_Short_Name");
            var commaSeparatedBhandarNames;
            if (BhandarName && BhandarName.length > 0) {
                commaSeparatedBhandarNames = BhandarName.join(','); // Join the array into a comma-separated string
            }
            if (BhandarName && BhandarName.length > 0) {
                const fieldName = "bhandar_Short_Name";
                const searchTerm = BhandarName;
                filterCriterias.push({
                    IndexName: AdvancedSearchIndex,
                    FieldName: fieldName,
                    SearchTerm: commaSeparatedBhandarNames,
                    start: 0,
                    end: 0
                });
            }

            var FromDate = $("#start").val();
            var ToDate = $("#end").val();
            if (FromDate) {
                if (!ToDate) {
                    toastr.error('To date is mandetory for search');
                    return;
                } else {
                    // Add date criteria if both dates are provided
                    filterCriterias.push({
                        IndexName: AdvancedSearchIndex,
                        FieldName: "year",
                        SearchTerm: "Search Term",
                        start: FromDate,
                        end: ToDate
                    });
                }
            }

            // Add other fields similarly as required
            //var Lipi = $("#lipi_Short_Nm").val();
            var Lipi = getCheckedValues("lipi_Short_Nm");
            var commaSeparatedLipi;
            if (Lipi && Lipi.length > 0) {
                commaSeparatedLipi = Lipi.join(','); // Join the array into a comma-separated string
            }
            if (Lipi && Lipi.length > 0) {
                filterCriterias.push({
                    IndexName: AdvancedSearchIndex,
                    FieldName: "lipi_Short_Nm",
                    SearchTerm: commaSeparatedLipi,
                    start: 0,
                    end: 0
                });
            }
        } else if (AdvancedSearchIndex === "Kruti") {
            //var Language = $("#language").val();
            var Language = getCheckedValues("language");
            if (Language && Language.length > 0) {
                var commaSeparatedLanguages = Language.join(','); // Join the array into a comma-separated string
            }
            if (Language && Language.length > 0) {
                filterCriterias.push({
                    IndexName: AdvancedSearchIndex,
                    FieldName: "language",
                    SearchTerm: commaSeparatedLanguages,
                    start: 0,
                    end: 0
                });
            }

            var FromYear = $("#start").val();
            var ToYear = $("#end").val();
            if (FromYear) {
                if (!ToYear) {
                    toastr.error('To date is mandetory for search');
                    return;
                } else {
                    filterCriterias.push({
                        IndexName: AdvancedSearchIndex,
                        FieldName: "year",
                        SearchTerm: "Search Term",
                        start: FromYear,
                        end: ToYear
                    });
                }
            }
        } else if (AdvancedSearchIndex === "Prakashan") {
            //var PublisherName = $("#pblsr_Nam").val();
            var PublisherName = getCheckedValues("pblsr_Nam");
            var commaSeparatedPublisherName;
            if (PublisherName && PublisherName.length > 0) {
                commaSeparatedPublisherName = PublisherName.join(','); // Join the array into a comma-separated string
            }
            if (PublisherName && PublisherName.length > 0) {
                filterCriterias.push({
                    IndexName: AdvancedSearchIndex,
                    FieldName: "pblsr_Nam",
                    SearchTerm: commaSeparatedPublisherName,
                    start: 0,
                    end: 0
                });
            }

            var FromPrakashanYear = $("#start").val();
            var ToPrakashanYear = $("#end").val();
            if (FromPrakashanYear) {
                if (!ToPrakashanYear) {
                    toastr.error('To date is mandetory for search');
                    return;
                } else {
                    filterCriterias.push({
                        IndexName: AdvancedSearchIndex,
                        FieldName: "year",
                        SearchTerm: "Search Term",
                        start: FromPrakashanYear,
                        end: ToPrakashanYear
                    });
                }
            }
        }
        else if (AdvancedSearchIndex === "Vidvan") {
            var FromYear = $("#start").val();
            var ToYear = $("#end").val();
            if (FromYear) {
                if (!ToYear) {
                    toastr.error('To date is mandetory for search');
                    return;
                } else {
                    filterCriterias.push({
                        IndexName: AdvancedSearchIndex,
                        FieldName: "year",
                        SearchTerm: "year",
                        start: FromYear,
                        end: ToYear
                    });
                }
            }
        }
    }
    ShowLoader("show");
    $.ajax({
        url: 'AdvanceSearch/performSearchLoadMore',
        type: 'POST',
        data: {
            SearchTerm: searchTerm,
            SelectedIndex: selectedIndex,
            IsExactSearch: !isExactSearch,
            IsAdvanceSearch: isAdvanceSearch,
            filterCriterias: filterCriterias,
            PageNumber: pageNumber,
            PageSize: pageSize,
            IsPaginationLoad: true
        },
        success: function (response) {
            $("#SearchResultBody").append(response);
            isFetching = false; // Allow new requests
            ShowLoader("hide");
        },
        error: function () {
            toastr.error('Error loading more results');
            isFetching = false;
            ShowLoader("hide");
        }
    });
}
