﻿$(function () {
    $("#AtxtPratNoStart").on('change', function () {
        var pratStartNo = $(this).val();
        if (pratStartNo.length > 0) {
            $("#AtxtPratNoEnd").prop('disabled', false);
        }
        else {
            $("#AtxtPratNoEnd").prop('disabled', true);
        }
    });

    $("#chkHpDharmaCodeManual").on('change', function () {
        if ($("#chkHpDharmaCodeManual").prop('checked')) {
            $("#chkHpDharmaCodeIsNot").prop('checked', false);
            $("#chkHpDharmaCodeIsNot").prop('disabled', true);
            $(".divManualIp").removeClass('d-none');
            $(".divEqualIp").addClass('d-none');
            $("#cmbDharmaCodeEqualTxt").val('');
            $("#cmbHpDharmaPosition").prop('disabled', false);
        }
        else {
            $("#cmbDharmaCodeEqualTxt").val('');
            $("#chkHpDharmaCodeIsNot").prop('disabled', false);
            $(".divEqualIp").removeClass('d-none');
            $(".divManualIp").addClass('d-none');
            $("#cmbHpDharmaPosition").prop('disabled', true);
        }
    });
});