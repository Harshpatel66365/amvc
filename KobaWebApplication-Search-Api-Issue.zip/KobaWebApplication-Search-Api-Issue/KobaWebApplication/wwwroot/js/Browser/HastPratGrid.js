﻿var tblHpInfo = null;
$(document).ready(function () {
    $("#sidebar").hide();
    InitializeDatatableForHpInfo();
});
function showHastpratPopup() {
    $.ajax({
        url: '/Hastprat/HastpratSearch', // Call the new action
        type: 'Get',
        success: function (response) {
            $("#divHastpratSearch").html('');
            $("#HastpratSearchModal").modal('hide');
            $("#divHastpratSearch").html(response);
            $("#HastpratSearchModal").modal('show');
        },
        error: function () {
            toastr.error('Something went wrong while searching.!');
            ShowLoader("hide");
        }
    });
}
function InitializeDatatableForHpInfo() {
    tblHpInfo = $("#hpInfoTable").DataTable({
        "dom": '<"top"lBf>rt<"bottom"ip><"clear">',
        "buttons": getCommonButtons(),
        "searching": true,
        "processing": true,
        "serverSide": true,
        "filter": false,
        "responsive": true,
        "scrollX": true,
        "pageLength": 25,
        "order": [0, 'desc'],
        "ajax": {
            "url": "/HastPrat/HastPratSearchGridDetails",
            "type": "POST",
            "datatype": "json",
            "data": function (d) {
                d.SearchModel = $("#searchQuery").val() || "";
            }
        },
        "columns": [
            { "data": 'bhandar_Code' },
            { "data": 'hp_No' },
            { "data": 'form_No' },
            { "data": 'hp_Tot_Pet' },
            { "data": 'purnata_short_name' },
            { "data": 'purnata_Remark_Code' },
            { "data": 'purnata_Remark' },
            { "data": 'dasha_Short_Name' },
            { "data": 'dasha_Remark' },
            { "data": 'laksn_Code_string' },
            { "data": 'importance_Level_Code' },
            { "data": 'dasha_code_string' },
            { "data": 'hp_Vishesh' },
            { "data": 'prst_Pusp_Type_Short_Name' },
            { "data": 'prati_Pusp_Pariman_Count' },
            { "data": 'hp_Parampara' },
            { "data": 'pur_Don_Lot_No' },
            { "data": 'old_No' },
            { "data": 'lipi_Short_Name' },
            { "data": 'material_Short_Name' },
            { "data": 'hp_Type_Short_Name' },
            { "data": 'dharma_Code' },
            { "data": 'pgs_First' },
            { "data": 'pgs_Last' },
            { "data": 'pgs_Ght' },
            { "data": 'pgs_Ght_Tot' },
            { "data": 'pgs_Avst_Ght' },
            { "data": 'pgs_Avst_Ght_Tot' },
            { "data": 'pgs_Bdth' },
            { "data": 'pgs_Bdth_Tot' },
            { "data": 'pgs_Net' },
            { "data": 'length_Min' },
            { "data": 'length_Max' },
            { "data": 'width_Min' },
            { "data": 'width_Max' },
            { "data": 'lines_Min' },
            { "data": 'lines_Max' },
            { "data": 'char_Min' },
            { "data": 'char_Max' },
            { "data": 'lekhan_Prakar_short_name' },
            { "data": 'readership_Lvl' },
            { "data": 'catalog_No' },
            { "data": 'del_miss_short_name' },
            { "data": 'related_Tot_Vidvan' },
            { "data": 'related_Tot_Kruti' },
            { "data": 'related_Tot_Laksn' },
            { "data": 'related_Tot_Dasha_Detail_Codes' },
            { "data": 'related_Tot_Nam' },
            { "data": 'related_Tot_Shlok' },
            { "data": 'related_Tot_Year' },
            { "data": 'related_Tot_City' },
            { "data": 'related_Tot_Internal_Issue' },
            { "data": 'related_Tot_External_Issue' },
            { "data": 'related_Tot_Xerox_Issue' },
            { "data": 'add_Init' },
            { "data": 'updt_Init' },
            { "data": 'last_Edtr' },
            { "data": 'certifier' },
            { "data": 'updt_Authority_Level' },
            { "data": 'certifier_Authority_Level' },
            { "data": 'bhandar_Short_Name' },
            { "data": 'remark' },
            { "data": 'hp_Nam' },
            { "data": 'hp_Nam_filtered' },
            { "data": 'main_Nam' },
            { "data": 'isEnglish' },
            { "data": 'name_Type_Short_Name' },
            { "data": 'year_type_short_name' },
            { "data": 'year_value' },
            { "data": 'vir_st_year' },
            { "data": 'vir_end_year' }
        ]
    });
}
