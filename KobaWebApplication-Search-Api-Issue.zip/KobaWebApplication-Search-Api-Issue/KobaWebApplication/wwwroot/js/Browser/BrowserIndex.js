﻿let pageNumber = 1;
let IsSearchBtn = 0;
const pageSize = 10;
let isFetching = false;
var CurrentselectedIndex = "";
let debounceTimer;

function debounce(fn, delay) {
    return function (...args) {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => fn(...args), delay);
    }
}

const searchTermInput = document.getElementById("searchTextBox");
const advancedCategoryDropdown = document.getElementById("advancedCategoryDropdown");

function performSearch(IndexName, IsSearchBtn = 0) {
    pageNumber = 1;
    const searchTerm = document.getElementById("searchTextBox").value;
    if (searchTerm == "") {
        toastr.error('Search term is mandetory.!');
        return;
    }
    var IsAdvanceSearch = true;
    var selectedIndex;
    if (IndexName == 'find' && CurrentselectedIndex == "") {
        selectedIndex = 'All';
        IsAdvanceSearch = false;
        updateAdvancedFilters(selectedIndex);
    } else if (IndexName != 'find' && CurrentselectedIndex != "") {
        selectedIndex = IndexName;
        IsAdvanceSearch = false;
        updateAdvancedFilters(selectedIndex);
    }
    else if (IndexName == 'find' && CurrentselectedIndex != "" && IsSearchBtn == 1) {
        selectedIndex = $(".category-checkbox:checked").data('category');
        IsAdvanceSearch = true;
        updateAdvancedFilters(selectedIndex);
    }
    else {
        selectedIndex = CurrentselectedIndex;
    }
    const isExactSearch = document.getElementById("isExactSearchToggle").checked;
    CurrentselectedIndex = selectedIndex;
    let filterCriterias = [];

    if (IsAdvanceSearch) {
        var AdvancedSearchIndex = $("#advancedCategoryDropdown").val();
        filterCriterias = populateFilterCriterias(AdvancedSearchIndex);
    }

    ShowLoader("show");
    $.ajax({
        url: 'Browser/PerformSearch',
        type: 'POST',
        data: {
            SearchTerm: searchTerm,
            SelectedIndex: selectedIndex,
            IsExactSearch: !isExactSearch,
            IsAdvanceSearch: IsAdvanceSearch,
            filterCriterias: filterCriterias,
            PageNumber: 1,
            PageSize: 10
        },
        success: function (response) {
            $("#searchIntroDiv").hide();
            $("#PartialView").html(response);
            $("#mainAllCount").text($("#allCount").text().trim());
            $("#mainAuthorCount").text($("#authorCount").text().trim());
            $("#mainKrutiCount").text($("#krutiCount").text().trim());
            $("#mainHastPratCount").text($("#hastpratCount").text().trim());
            $("#mainPublisherCount").text($("#publisherCount").text().trim());
            highlightBadge();
            const filtersDiv = document.getElementById('advancedSearchFilters');
            filtersDiv.style.display = filtersDiv.style.display = 'block';
            ShowLoader("hide");
            searchTermInput.addEventListener("input", debounce(() => performSearch(CurrentselectedIndex, 1), 3000));
        },
        error: function () {
            toastr.error('Something went wrong while searching.!');
            ShowLoader("hide");
        }
    });
}

function addFilterCriteria(filterCriterias, indexName, fieldId, customFieldName = null) {
    const values = getCheckedValues(fieldId);
    if (values.length > 0) {
        filterCriterias.push({
            IndexName: indexName,
            FieldName: customFieldName || fieldId,
            SearchTerm: values.join(','),
            start: 0,
            end: 0
        });
    }
}

function addDateCriteria(filterCriterias, indexName, fieldName) {
    const fromDate = $("#start").val();
    const toDate = $("#end").val();
    if (fromDate) {
        if (!toDate) {
            toastr.error('To date is mandatory for search');
            return;
        }
        filterCriterias.push({
            IndexName: indexName,
            FieldName: fieldName,
            SearchTerm: "Search Term",
            start: fromDate,
            end: toDate
        });
    }
}

function updateAdvancedFilters(Indexname) {
    const selectedIndex = Indexname;
    document.getElementById('advancedCategoryDropdown').value = selectedIndex;
    const dynamicFiltersDiv = document.getElementById('dynamicFilters');
    dynamicFiltersDiv.innerHTML = ''; // Clear existing inputs

    let filtersHtml = generateFilterHtml(selectedIndex);
    dynamicFiltersDiv.innerHTML = filtersHtml;

    const searchTerm = document.getElementById("searchTextBox").value.trim();
    if (!searchTerm) {
        toastr.error('Search term is mandatory!');
        return;
    }

    const isExactSearch = document.getElementById("isExactSearchToggle").checked;
    CurrentselectedIndex = selectedIndex;

    ShowLoader("show");
    $.ajax({
        url: 'Browser/GetAdvanceSearchFilter',
        type: 'POST',
        data: {
            SearchTerm: searchTerm,
            SelectedIndex: selectedIndex,
            IsExactSearch: !isExactSearch,
            PageNumber: 1,
            PageSize: 10
        },
        success: function (response) {
            if (selectedIndex !== "All")
                FillFilterValues(response, selectedIndex);
            ShowLoader("hide");
        },
        error: function () {
            toastr.error('Something went wrong while searching!');
            ShowLoader("hide");
        }
    });
}

function generateFilterHtml(selectedIndex) {
    const filtersMap = {
        "Hastprat": [
            { label: "Bhandar Name", id: "bhandar_Short_Name" },
            { label: "Lipi", id: "lipi_Short_Nm" }
        ],
        "Kruti": [
            { label: "Language", id: "language" },
            { label: "Vidvaan Name", id: "KrVid" }
        ],
        "Prakashan": [
            { label: "Publisher Name", id: "pblsr_Nam" },
            { label: "Edition", id: "edition" },
            { label: "Dharma Code", id: "dharma_code" },
            { label: "Granthmala", id: "granthmala" }
        ],
        "Vidvan": [
            { label: "Gach Name", id: "gach_name" },
            { label: "Guru Name", id: "guru_name" },
            { label: "Dada Guru Name", id: "dadaguru_name" },
            { label: "Gender", id: "genderCode" },
            { label: "Gruhasth", id: "gruhasth" }
        ]
    };

    let filtersHtml = '';
    const commonPeriodHtml = `
        <div class="description-item">
            <label class="filter-label">Period</label>
            <div class="d-flex">
                <input type="text" class="form-control me-2" id="start" placeholder="From" style="flex: 1;" />
                <input type="text" class="form-control" id="end" placeholder="To" style="flex: 1;" />
            </div>
        </div>`;

    if (filtersMap[selectedIndex]) {
        filtersMap[selectedIndex].forEach(filter => {
            const collapseId = `collapse-${filter.id}`; // Unique ID for each collapsible div

            filtersHtml += `
                <div class="description-item">
                    <label class="filter-label">${filter.label}</label>
                    <button class="btn btn-link p-0 float-end" type="button" data-bs-toggle="collapse" data-bs-target="#${collapseId}" aria-expanded="false" aria-controls="${collapseId}" onclick="toggleArrow(this);">
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div id="${collapseId}" class="collapse">
                        <div id="${filter.id}" class="filter-list-data"></div>
                    </div>
                </div>`;
        });
        filtersHtml += commonPeriodHtml;
    }

    return filtersHtml;
}

function FillFilterValues(response, selectedIndex) {
    const filterMap = {
        "Hastprat": {
            "bhandar_Short_Name": response.bhandarInfoDtos,
            "lipi_Short_Nm": response.lipiInfoDtos
            //"vid_Type_Short_Name": response.vidTypeShortNameInfoDtos,
            //"vid_Nam": response.vidNameInfoDtos
        },
        "Kruti": {
            "language": response.languageInfoDtos,
            "KrVid": response.vidNameInfoDtos
        },
        "Prakashan": {
            "pblsr_Nam": response.publisherInfoDtos,
            "edition": response.editionInfoDtos,
            "dharma_code": response.dharmaCodeInfoDtos,
            "granthmala": response.granthmalaInfoDtos
        },
        "Vidvan": {
            "gach_name": response.gachNameInfoDtos,
            "guru_name": response.guruNameInfoDtos,
            "dadaguru_name": response.dadaGuruNameInfoDtos,
            "genderCode": response.genderCodeInfoDtos,
            "gruhasth": response.gruhasthInfoDtos
        }
    };

    if (filterMap[selectedIndex]) {
        Object.keys(filterMap[selectedIndex]).forEach(key => {
            populateSelectArray(filterMap[selectedIndex][key], key);
        });
    }
}

function populateSelectArray(optionsArray, selectId) {
    const selectElement = document.getElementById(selectId);
    selectElement.innerHTML = ''; // Clear existing options
    selectElement.removeAttribute('multiple'); // Remove the multiple attribute since we are replacing it with checkboxes

    if (optionsArray && optionsArray.length > 0) {
        const checkboxContainer = document.createElement('div');
        optionsArray.sort((a, b) => a.name.localeCompare(b.name));

        optionsArray.forEach(item => {
            const uniqueId = `${Date.now().toString(36)}-${Math.random().toString(36).substring(2)}`;
            const { name, count } = item;
            const displayName = name ? name : 'Blank';

            const innerDiv = document.createElement('div');
            innerDiv.classList = 'filter-item';

            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.id = uniqueId;
            checkbox.classList = 'filter-checkbox';
            checkbox.value = name || '(empty)';
            checkbox.name = selectId;

            const label = document.createElement('label');
            label.textContent = `${displayName} (${count})`;
            label.htmlFor = uniqueId;

            innerDiv.appendChild(checkbox);
            innerDiv.appendChild(label);

            checkboxContainer.appendChild(innerDiv);
        });

        selectElement.appendChild(checkboxContainer);
        selectElement.disabled = false;
    } else {
        selectElement.innerHTML = '<p>No Data</p>';
        selectElement.disabled = true;
    }
}

function getCheckedValues(checkBoxName) {
    const checkedValues = [];
    const checkboxes = document.querySelectorAll('input[name="' + checkBoxName + '"]:checked');

    checkboxes.forEach(checkbox => {
        checkedValues.push(checkbox.value);
    });

    return checkedValues;
}

function populateFilterCriterias(AdvancedSearchIndex) {
    let filterCriterias = [];

    const criteriaMap = {
        "Hastprat": ["bhandar_Short_Name", "lipi_Short_Nm"],//, "vid_Type_Short_Name", "vid_Nam"],
        "Kruti": ["language", { field: "KrVid", customField: "publisher_Name" }],
        "Prakashan": ["pblsr_Nam", "edition", "dharma_code", "granthmala"],
        "Vidvan": ["gach_name", "guru_name", "dadaguru_name", "genderCode", "gruhasth"]
    };

    if (criteriaMap[AdvancedSearchIndex]) {
        criteriaMap[AdvancedSearchIndex].forEach(item => {
            if (typeof item === "string") {
                addFilterCriteria(filterCriterias, AdvancedSearchIndex, item);
            } else if (typeof item === "object" && item.field && item.customField) {
                addFilterCriteria(filterCriterias, AdvancedSearchIndex, item.field, item.customField);
            }
        });
        addDateCriteria(filterCriterias, AdvancedSearchIndex, "year");
    }

    return filterCriterias;
}

function loadMoreResults() {
    if (isFetching) return;

    isFetching = true;
    pageNumber++; // Increment the page number

    const searchTerm = document.getElementById("searchTextBox").value;
    const selectedIndex = document.getElementById("advancedCategoryDropdown").value;
    const isExactSearch = document.getElementById("isExactSearchToggle").checked;
    const isAdvanceSearch = true;

    let filterCriterias = [];
    if (isAdvanceSearch) {
        var AdvancedSearchIndex = $("#advancedCategoryDropdown").val();
        filterCriterias = populateFilterCriterias(AdvancedSearchIndex);
    }
    ShowLoader("show");
    $.ajax({
        url: 'Browser/PerformSearch',
        type: 'POST',
        data: {
            SearchTerm: searchTerm,
            SelectedIndex: selectedIndex,
            IsExactSearch: !isExactSearch,
            IsAdvanceSearch: isAdvanceSearch,
            filterCriterias: filterCriterias,
            PageNumber: pageNumber,
            PageSize: pageSize,
            IsPaginationLoad: true
        },
        success: function (response) {
            $("#PartialView").append(response);
            isFetching = false; // Allow new requests
            ShowLoader("hide");
        },
        error: function () {
            toastr.error('Error loading more results');
            isFetching = false;
            ShowLoader("hide");
        }
    });
}

function highlightBadge() {
    if (CurrentselectedIndex.toLocaleLowerCase() == "all" || CurrentselectedIndex == "") {
        $('.badge-custom').removeClass('active');
        $(".all-badge").addClass('active');
        return;
    }
    $('.badge-custom').each(function () {
        if ($(this).text().toLowerCase().includes(CurrentselectedIndex.toLowerCase())) {
            $(this).addClass('active');
        } else {
            $(this).removeClass('active');
        }
    });
}

function toggleArrow(button) {
    var icon = button.querySelector('i');
    icon.classList.toggle('fa-chevron-down');
    icon.classList.toggle('fa-chevron-up');
}

function RequestClick(button) {
    var indexName = button.dataset.value;
    var BookName = button.dataset.name;
    var searchKey = button.dataset.id;
    if (indexName == "prakashan") {
        $.ajax({
            url: '/Browser/IsParakashanAvailableInLibrary',
            type: 'GET',
            data: {
                prksnNo: searchKey,
            },
            success: function (response) {
                if (response.isAvailabel) {
                    window.open(response.url, '_blank');
                }
                else {
                    window.location.href = "/Book?BookCategory=" + encodeURIComponent(indexName) +
                        "&BookSrNo=" + encodeURIComponent(searchKey) +
                        "&BookTitle=" + encodeURIComponent(BookName);
                }
            },
            error: function (xhr, status, error) {
                toastr.error("An error occurred while processing your request.");
            }
        });
    }
    else {
        window.location.href = "/Book?BookCategory=" + encodeURIComponent(indexName) +
            "&BookSrNo=" + encodeURIComponent(searchKey) +
            "&BookTitle=" + encodeURIComponent(BookName);
    }
}

function ClearFilters() {
    $('#dynamicFilters').find('input[type="checkbox"]').prop('checked', false);
    $('#dynamicFilters').find('input[type="text"]').val('');
}

$(function () {
    $(".category-checkbox").on('change', function () {
        const searchTerm = document.getElementById("searchTextBox").value;
        if ($(".category-checkbox:checked").length === 0) {
            $(this).prop('checked', true);
            toastr.error("At least one category must be selected. You cannot unselect this category.");
            return;
        }
        if (searchTerm == "") {
            toastr.error('Search term is mandetory.!');
            $(".category-checkbox").not(this).prop('checked', false);
            return;
        }
        $(".category-checkbox").not(this).prop('checked', false);
        var IndexName = $(this).data('category');
        $("#advancedCategoryDropdown").val(IndexName);
        performSearch(IndexName);
    });
});