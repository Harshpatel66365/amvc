﻿$(document).ready(function () {
    // Function to get a cookie value
    function getCookie(cookieName) {
        let cookieValue = "";
        let cookies = document.cookie.split(';');
        cookies.forEach(function (cookie) {
            let [key, value] = cookie.split('=');
            if ($.trim(key) === cookieName) {
                cookieValue = value;
            }
        });
        return cookieValue;
    }

    // Get the language code from cookie, default to 'en' if not found
    let languageCode = getCookie("selectedOption");
    if (!languageCode) {
        languageCode = "en";
    }

    // Set the value of the language dropdown to the current cookie value
    $('#languageDropdown').val(languageCode);

    // Event handler for the save language button, if it exists
    $('#saveLanguageButton').on('click', function () {
        let selectedLanguage = $('#languageDropdown').val() || 'en';
        document.cookie = 'selectedOption=' + selectedLanguage + '; path=/; expires=Fri, 31 Dec 9999 23:59:59 GMT';
        location.reload();
    });

    // Add event listener for the language dropdown change event only if URL contains "Login/LoginOptions"
    if (window.location.href.includes("Login/LoginOptions")) {
        $('#languageDropdown').on('change', function () {
            let selectedValue = $(this).val() || 'en';
            document.cookie = 'selectedOption=' + selectedValue + '; path=/;';
            location.reload();
        });
    }
});


//Common Function to get the button configuration for DataTables
function getCommonButtons() {
    return [
        {
            extend: 'csvHtml5',
            text: 'CSV',
            charset: 'utf-8',
            bom: true,
            titleAttr: 'CSV export',
            exportOptions: {
                columns: ':visible'
            }
        },
        {
            extend: 'excelHtml5',
            text: 'Excel',
            titleAttr: 'Excel export',
            charset: 'utf-8',
            exportOptions: {
                columns: ':visible'
            }
        },
        {
            extend: 'pdfHtml5',
            text: 'PDF',
            titleAttr: 'PDF export',
            customize: function (doc) {
                doc.defaultStyle = {
                    font: 'Mukta',
                    fontSize: 10
                };
            }
        }
    ];
}

function ShowLoader(action) {
    var loader = document.getElementById("loader");

    if (action === "show") {
        loader.style.display = "flex"; // Show loader
    } else if (action === "hide") {
        loader.style.display = "none"; // Hide loader
    }
}
