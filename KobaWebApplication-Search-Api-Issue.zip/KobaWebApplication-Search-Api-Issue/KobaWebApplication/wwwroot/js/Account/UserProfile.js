﻿$(document).ready(function () {
    $('#editIcon').click(function () {
        $('#Usr_Name').prop('readonly', false);
        $('#Permanent_Address').prop('readonly', false);
        $('#saveButton').show();
    });

    $('#saveButton').click(function () {
        var updateUser = {
            Id: $('#userId').val(),
            Usr_Name: $('#Usr_Name').val(),
            Permanent_Address: $('#Permanent_Address').val()
        };

        $.ajax({
            url: "/Account/UpdateUser",
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(updateUser),
            success: function (response) {
                //alert('User updated successfully');
                //location.reload(); // Reload the page to show updated details
                $('#Usr_Name').prop('readonly', true);
                $('#Permanent_Address').prop('readonly', true);
                $('#saveButton').hide()
            },
            error: function (xhr, status, error) {
                alert('Error updating user: ' + error);
            }
        });
    });
});