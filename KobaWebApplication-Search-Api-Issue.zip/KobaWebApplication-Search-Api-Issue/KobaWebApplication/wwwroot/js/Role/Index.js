﻿$(document).ready(function () {
    InitializeDatatable();
    $('#createRoleForm').submit(function (event) {
        event.preventDefault();

        var roleName = $('#RoleName').val();

        $.ajax({
            url: 'Roles/CreateRole',
            type: 'POST',
            data: { Name: roleName },
            success: function (response) {
                if (response.success) {
                    alert("Role created successfully!");
                    $('#createRoleModal').modal('hide');
                    location.reload(); // Refresh to update the roles dropdown
                } else {
                    alert("Error: " + response.message);
                }
            },
            error: function () {
                alert("An error occurred while creating the role.");
            }
        });
    });
});

function InitializeDatatable() {
    $("#RoleTable").DataTable({
        "dom": '<"top"lBf>rt<"bottom"ip><"clear">',
        "buttons": getCommonButtons(),
        "searching": true,
        "processing": true,
        "serverSide": true,
        "filter": false,
        "responsive": true,
        "scrollX": true,
        "order": [0, 'desc'],
        "ajax": {
            "url": "/Roles/GetRolesDataTable",
            "type": "POST",
            "datatype": "json",
            "data": function (d) {

            }
        },
        "columns": [
            { "data": 'name', "title": 'Role Name', "width": "80%" },
            { "data": 'id', "title": 'Id', "visible": false }, // Hide the ID column
            {
                "data": null,
                "title": "Action",
                "orderable": false,
                "width": "20%",
                "render": function (data, type, row) {
                    return `<a href="/Roles/RolePermission?Id=${row.id}" class="btn btn-primary btn-sm">Assign Permission</a>`;
                }
            }
        ]
    });
}
