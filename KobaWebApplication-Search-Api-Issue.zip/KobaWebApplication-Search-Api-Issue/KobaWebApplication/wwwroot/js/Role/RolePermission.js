﻿var isChecked;
var permissionData = [];

$("input[type='checkbox']").click(function () {
    if ($(this).hasClass("childPermission")) {
        var chkModule = this.checked;
        var isCheckedAny = false;
        var modulePermission = $(this).parent().parent().parent().parent().find('.permission--title').find('div.custom-switch').find('input');
        var allModulePermissions = $(this).parent().parent().next().find('li').find('div.custom-switch').find('input');
        var allModuleSwitches = $(this).parent().parent().parent().parent().find('li').find('div.custom-switch')
        if (chkModule) {
            $(modulePermission).prop('checked', true);
        }
        else {
            $(allModuleSwitches).each(function () {
                var isChecked = $(allModuleSwitches).find('input');
                isChecked.each(function () {
                    if ($(this).prop('checked')) {
                        isCheckedAny = true;
                    }
                });
            });
            $(modulePermission).prop('checked', isCheckedAny);
        }
        setPermissions(this);
    } else {
        var chkModule = this.checked;
        var allModulePermissions = $(this).parent().parent().next().find('li').find('div.custom-switch').find('input');
        $(allModulePermissions).each(function () {
            if (chkModule) {
                $(this).prop('checked', true);
            } else {
                $(this).prop('checked', false);
            }
            setPermissions(this);
        });
    }
});

function setPermissions(obj) {
    var data = {
        Permission: $(obj).val(),
        IsChecked: obj.checked,
        RoleId: $("#RoleId").val()
    };
    $.ajax({
        url: "/Roles/CreateRolePermission",
        type: "POST",
        data: data,
        async: false,
        success: function (response) {
            if (response != "success")
                alert("Error: " + response);
        }
    });
}

$(document).on('submit', '#frmCreateUpdateRolePermission', function (e) {
    $('#btnCreateUpdateRolePermission').buttonLoader('start');
});

$('#backToRolePage').click(function () {
    window.location.href = "/Roles/Index";
});