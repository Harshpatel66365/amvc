﻿$(document).ready(function () {
    InitializeDatatable();

    $('#UserWorkingType').change(function () {
        var isChecked = $(this).is(':checked');
        var label = isChecked ? 'Inactive' : 'Active';
        $('#workingTypeLabel').text(label);

        // Reload the DataTable with the new working type
        $('#userTable').DataTable().ajax.reload();
    });
});
function InitializeDatatable() {
    $("#userTable").DataTable({
        "dom": '<"top"lBf>rt<"bottom"ip><"clear">',
        "buttons": getCommonButtons(),
        "searching": true,
        "processing": true,
        "serverSide": true,
        "responsive": true,
        "scrollX": true,
        "pageLength": 25,
        "order": [0, 'desc'],
        "ajax": {
            "url": "/User/GetUsers",
            "type": "POST",
            "datatype": "json",
            "data": function (d) {
                // Get the working type based on the switch state
                d.workingType = $('#UserWorkingType').is(':checked') ? 'x' : 'c';
            }
        },
        "columns": [
            { "data": 'id', "title": 'ID', "visible": false },
            { "data": 'usr_Name', "title": 'Usr_Name' },
            { "data": 'usr_Init', "title": 'Usr Init' },
            { "data": 'designation', "title": 'Designation' },
            { "data": 'main_Work', "title": 'Main_Work' },
            { "data": 'permanent_Address', "title": 'Permanent_Address' },
            {
                "data": 'Working_Type',
                "title": 'Working Type',
                "render": function (data, type, row) {
                    // Display 'Active' if workingType is 'c', else 'Inactive'
                    return row.working_Type === 'C' ? 'Active' : 'Inactive';
                }
            }
        ]
    });
}
