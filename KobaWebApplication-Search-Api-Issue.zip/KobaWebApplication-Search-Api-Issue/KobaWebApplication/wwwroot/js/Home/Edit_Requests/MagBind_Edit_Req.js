﻿var tblMgBindEditReq = null;

$(document).ready(function () {
    var isReceiver = $('#isReceiverFlag_MagBind').val();
    InitializeDatatable(isReceiver);
});

function InitializeDatatable(isReceiver) {
    tblMgBindEditReq = $("#magBindEditReqTable").DataTable({
        "dom": '<"top"lBf>rt<"bottom"ip><"clear">',
        "buttons": getCommonButtons(),
        "searching": true,
        "processing": true,
        "serverSide": true,
        "filter": false,
        "responsive": true,
        "scrollX": true, 
        "pageLength": 25,
        "order": [0, 'desc'],
        "ajax": {
            "url": "/Home/GetMagBindEditReqData",
            "type": "POST",
            "datatype": "json",
            "data": function (d) {
                d.IsEditReqToYou = isReceiver.toLowerCase() == "false" ? false : true;
            }
        },
        columns: [
            { "data": 'msg_No' },
            { "data": 'bhandar_Code' },
            { "data": 'bind_No' },
            { "data": 'ank_Copy_Accession_No' },
            { "data": 'sender_Init' },
            { "data": 'sender_Msg' },
            { "data": 'receiver_init' },
            {
                "data": 'receiver_Reply',
                render: function (data) {
                    return data ? data : '';
                }
            },
            { "data": 'urgency_Type_Short_name' },
            { "data": 'status_Short_Name' },
            {
                "data": 'send_Dt',
                render: function (data) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            {
                "data": 'reply_Dt',
                render: function (data) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            { "data": 'add_Init' },
            { "data": 'updt_Init' },
            { "data": 'last_Edtr' },
            { "data": 'certifier' },
            {
                "data": 'updt_Authority_Level',
                render: function (data) {
                    return data != null ? data : '';
                }
            },
            {
                "data": 'certifier_Authority_Level',
                render: function (data) {
                    return data != null ? data : '';
                }
            }
        ]

    });
}