﻿var tblPrksnEditReq = null;

$(document).ready(function () {
    var isReceiver = $('#isReceiverFlag_Prksn').val();
    InitializeDatatable(isReceiver);
});

function InitializeDatatable(isReceiver) {
    tblPrksnEditReq = $("#prksnEditReqTable").DataTable({
        "dom": '<"top"lBf>rt<"bottom"ip><"clear">',
        "buttons": getCommonButtons(),
        "searching": true,
        "processing": true,
        "serverSide": true,
        "filter": false,
        "responsive": true,
        "scrollX": true,
        "pageLength": 25,
        "order": [0, 'desc'],
        "ajax": {
            "url": "/Home/GetPrksnEditReqData",
            "type": "POST",
            "datatype": "json",
            "data": function (d) {
                d.IsEditReqToYou = isReceiver.toLowerCase() == "false" ? false : true;
            }
        },
        columns: [
            { "data": 'msg_No' },
            { "data": 'prksn_key' },
            { "data": 'prksn_Pet_Key' },
            { "data": 'sender_Init' },
            { "data": 'sender_Msg' },
            {
                "data": 'send_Dt',
                render: function (data) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            { "data": 'receiver_init' },
            {
                "data": 'receiver_reply',
                render: function (data) {
                    return data ? data : '';
                }
            },
            {
                "data": 'reply_Dt',
                render: function (data) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            { "data": 'urgency_Type_Short_name' },
            { "data": 'status_Short_name' },
            { "data": 'add_Init' },
            { "data": 'updt_Init' },
            { "data": 'last_Edtr' },
            { "data": 'certifier' },
            {
                "data": 'updt_authority_level',
                render: function (data) {
                    return data != null ? data : '';
                }
            },
            {
                "data": 'certifier_authority_level',
                render: function (data) {
                    return data != null ? data : '';
                }
            }
        ]

    });
}