﻿var tblMagEditReq = null;
$(document).ready(function () {
    var isReceiver = $('#isReceiverFlag_Mag').val();
    InitializeDatatable(isReceiver);
});

function InitializeDatatable(isReceiver) {
    tblMagEditReq = $("#magEditRequestTable").DataTable({
        "dom": '<"top"lBf>rt<"bottom"ip><"clear">',
        "buttons": getCommonButtons(),
        "searching": true,
        "processing": true,
        "serverSide": true,
        "responsive": true,
        "scrollX": true, 
        "filter": false,
        "pageLength": 25,
        "order": [0, 'desc'],
        "ajax": {
            "url": "/Home/GetMagEditReqData",
            "type": "POST",
            "datatype": "json",
            "data": function (d) {
                d.IsEditReqToYou = isReceiver.toLowerCase() == "false" ? false : true;
            }
        },
        columns: [
            { "data": 'msg_No' },
            { "data": 'mag_No' },
            { "data": 'ank_No' },
            { "data": 'ank_Pet_Key' },
            { "data": 'sender_Init' },
            { "data": 'sender_Msg' },
            { "data": 'receiver_Init' },
            {
                "data": 'receiver_Reply',
                render: function (data) {
                    return data ? data : '';
                }
            },
            { "data": 'urgency_Type_Short_name' },
            { "data": 'status_Short_Name' },
            { "data": 'add_Init' },
            { "data": 'updt_Init' },
            { "data": 'last_Edtr' },
            { "data": 'certifier' },
            {
                "data": 'updt_Authority_Level',
                render: function (data) {
                    return data != null ? data : '';
                }
            },
            {
                "data": 'certifier_Authority_Level',
                render: function (data) {
                    return data != null ? data : '';
                }
            }
        ]

    });
}