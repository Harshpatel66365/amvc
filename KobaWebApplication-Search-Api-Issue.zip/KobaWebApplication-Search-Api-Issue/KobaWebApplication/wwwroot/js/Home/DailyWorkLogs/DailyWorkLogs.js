﻿var tblDailyView = null;
$(document).ready(function () {
    $("#fromDate").val($("#startDateVal").val());
    $("#toDate").val($("#endDateVal").val());
    InitializeDatatable();
});

function InitializeDatatable() {
    tblDailyView = $("#dailyViewTable").DataTable({
        "dom": '<"top"lBf>rt<"bottom"ip><"clear">',
        "buttons": getCommonButtons(),
        "searching": true,
        "processing": true,
        "serverSide": true,
        "filter": true,
        "responsive": true,
        "scrollX": true,
        "pageLength": 25,
        "order": [0, 'desc'],
        "ajax": {
            "url": "/Home/GetDailyWorkLogsData",
            "type": "POST",
            "datatype": "json",
            "data": function (d) {
                d.FromDate = $('#fromDate').val();
                d.ToDate = $('#toDate').val();
            }
        },
        columns: [
            { "data": "daily_Id" },
            {
                "data": "sess_datetime",
                "render": function (data) {
                    return new Date(data).toLocaleString();
                }
            },
            { "data": "leave" },
            { "data": "half_Day" },
            { "data": "dutyleave" },
            { "data": "arrival" },
            { "data": "departure" },
            { "data": "recess" },
            { "data": "tea_break" },
            { "data": "main_Work" },
            { "data": "main_Desc" },
            { "data": "work_Output" },
            { "data": "m_Rel_Work" },
            { "data": "m_Rel_Desc" },
            { "data": "m_Rel_Output" },
            { "data": "other_Work" },
            { "data": "other_Desc" },
            { "data": "other_Output" },
            { "data": "disturb" },
            { "data": "disturb_Desc" },
            { "data": "remark" },
            { "data": "supervisor_Remark" },
            {
                "data": "supervisor_Remark_Dt",
                "render": function (data) {
                    return data ? new Date(data).toLocaleString() : '';
                }
            },
            { "data": "user_Reply" },
            {
                "data": "user_Reply_Dt",
                "render": function (data) {
                    return data ? new Date(data).toLocaleString() : '';
                }
            },
            { "data": "supervisor_Remark_Status_Code" },
            { "data": "add_Init" },
            { "data": "updt_Init" },
            { "data": "last_Edtr" },
            { "data": "certifier" },
            { "data": "updt_Authority_Level" },
            { "data": "certifier_Authority_Level" },
            { "data": "status_Short_name" },
            { "data": "userName" },
            { "data": "usr_Init" }
        ]

    });
}


$('#filterButton').click(function () {
    const fromDate = new Date($('#fromDate').val());
    const toDate = new Date($('#toDate').val());

    if (fromDate && toDate && fromDate > toDate) {
        alert('From Date should be earlier than To Date.');
        return;
    }

    tblDailyView.ajax.reload();
});
