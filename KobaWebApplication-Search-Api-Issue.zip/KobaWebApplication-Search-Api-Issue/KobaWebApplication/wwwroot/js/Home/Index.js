﻿//-----------------------------------------------------------------------//
// Default Home Page Implementations
var tblHomePage = null;
$(document).ready(function () {
    InitializeDatatableForL_Gmandir();
})

function InitializeDatatableForL_Gmandir() {
    if ($.fn.DataTable.isDataTable('#l_Gmandir_Table')) {
        $('#l_Gmandir_Table').DataTable().destroy();
    }

    $('#l_Gmandir_Table tbody').empty();

    tblHomePage = $("#l_Gmandir_Table").DataTable({
        "dom": '<"top">rt<"bottom"ip><"clear">',
        "searching": false,
        "processing": true,
        "serverSide": true,
        "filter": false,
        "responsive": true,
        "scrollX": true,
        "pageLength": 25,
        "order": [0, 'desc'],
        "ajax": {
            "url": "/Home/GetHomePageData",
            "type": "POST",
            "datatype": "json",
            "data": function (d) {

            }
        },
        "columns": [
            { "data": 'message_id' },
            {
                "data": 'message_Date',
                render: function (data) {
                    return new Date(data).toLocaleDateString();
                }
            },
            { "data": 'message' },
            { "data": 'total_Facility' }
        ]
    });
}