﻿var tblDatatable = null;

$(document).ready(function () {
    var errorType = $('#error_TypeFlag').val();
    InitializeDatatable(errorType);
});

function InitializeDatatable(errorType) {
    tblDatatable = $("#errorDetailsTable").DataTable({
        "dom": '<"top"lBf>rt<"bottom"ip><"clear">',
        "buttons": getCommonButtons(),
        "searching": true,
        "processing": true,
        "serverSide": true,
        "filter": false,
        "responsive": true,
        "scrollX": true,
        "pageLength": 25,
        "order": [[0, "desc"]],
        "ajax": {
            "url": "/Home/GetErrorsViewData",
            "type": "POST",
            "datatype": "json",
            "data": function (d) {
                d.ErrorType = errorType;
            }
        },
        columns: [
            { "data": 'errorID' },
            { "data": 'error_Description' },
            { "data": 'error_Status_Description' },
            {
                "data": 'error_PostDate',
                "render": function (data) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            { "data": 'programmer_Remark' },
            { "data": 'typeOfError' },
            { "data": 'urgency_Type_Short_name' },
            { "data": 'user_Reply' },
            { "data": 'entity' },
            { "data": 'entity_Field' },
            { "data": 'programmer_Init' },
            {
                "data": 'error_Solved_Date',
                "render": function (data) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            { "data": 'error_Image_Path' },
            { "data": 'user_Init' }
        ]

    });
}



