﻿var tblDatatable = null;

$(document).ready(function () {
    InitializeDatatable();
});

function InitializeDatatable() {
    tblDatatable = $("#routineWorkTable").DataTable({
        "dom": '<"top"lBf>rt<"bottom"ip><"clear">',
        "buttons": getCommonButtons(),
        "searching": true,
        "processing": true,
        "serverSide": true,
        "filter": false,
        "responsive": true,
        "scrollX": true,
        "pageLength": 25,
        "order": [[0, "desc"]],
        "ajax": {
            "url": "/Home/GetRoutinWorkData",
            "type": "POST",
            "datatype": "json",
            "data": function (d) {
            }
        },
        columns: [
            { "data": 'routine_Work_Id' },
            { "data": 'title' },
            { "data": 'custom_Msg' },
            { "data": 'user_Group_Short_Name' },
            { "data": 'main_Attending_Person' },
            { "data": 'alternate_Attending_Person' },
            {
                "data": 'msg_Dt',
                "render": function (data) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            { "data": 'start_Remind_Duration_Day' },
            { "data": 'duration_Short_name' },
            {
                "data": 'duration_Deadline_Dt',
                "render": function (data) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            { "data": 'show_Msg' },
            { "data": 'doneBy_Init' },
            {
                "data": 'doneOn_Dt',
                "render": function (data) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            { "data": 'add_init' },
            { "data": 'updt_Init' },
            { "data": 'last_Edtr' },
            { "data": 'certifier' },
            { "data": 'updt_Authority_Level' },
            { "data": 'certifier_Authority_Level' }
        ]

    });
}

