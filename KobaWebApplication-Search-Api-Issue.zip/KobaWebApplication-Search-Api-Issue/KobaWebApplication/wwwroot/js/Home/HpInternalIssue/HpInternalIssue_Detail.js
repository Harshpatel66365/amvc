﻿var tblDataTable = null;
$(document).ready(function () {
    var issueType = $('#hp_IssueTypeFlag').val();
    InitializeDatatable(issueType);
});

function InitializeDatatable(issueType) {
    tblHpInternalIssue = $("#hpInternalIssueTable").DataTable({
        "dom": '<"top"lBf>rt<"bottom"ip><"clear">',
        "buttons": getCommonButtons(),
        "searching": true,
        "processing": true,
        "serverSide": true,
        "filter": false,
        "responsive": true,
        "scrollX": true,
        "pageLength": 25,
        "order": [0, 'desc'],
        "ajax": {
            "url": "/Home/GetHp_Internal_Issue_Data",
            "type": "POST",
            "datatype": "json",
            "data": function (d) {
                d.Hp_IssueType = issueType;
            }
        },
        columns: [
            { "data": 'tran_No' },
            { "data": 'bhandar_Code' },
            { "data": 'hp_No' },
            {
                "data": 'request_On_Dt',
                "render": function (data) {
                    return new Date(data).toLocaleDateString();
                }
            },
            { "data": 'to_Whom' },
            { "data": 'issue_Init' },
            {
                "data": 'issue_Dt',
                "render": function (data) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            { "data": 'receiver_Init' },
            {
                "data": 'received_By_User_Dt',
                "render": function (data) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            {
                "data": 'returned_By_User_Dt',
                "render": function (data) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            { "data": 'issue_Type_Short_name' },
            {
                "data": 'request_Cancelled',
                "render": function (data) {
                    return data ? 'Yes' : 'No';
                }
            },
            {
                "data": 'is_Lost',
                "render": function (data) {
                    return data ? 'Yes' : 'No';
                }
            },
            { "data": 'add_Init' },
            { "data": 'updt_Init' },
            {
                "data": 'updt_Authority_Level',
                "render": function (data) {
                    return data != null ? data : '';
                }
            }
        ]

    });
}
