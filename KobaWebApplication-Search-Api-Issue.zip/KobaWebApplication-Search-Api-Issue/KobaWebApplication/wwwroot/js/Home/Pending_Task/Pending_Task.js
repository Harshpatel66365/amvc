﻿var tblDatatable = null;

$(document).ready(function () {
    InitializeDatatable();
});

function InitializeDatatable() {
    tblDatatable = $("#gPendingWorkTable").DataTable({
        "dom": '<"top"lBf>rt<"bottom"ip><"clear">',
        "buttons": getCommonButtons(),
        "searching": true,
        "processing": true,
        "serverSide": true,
        "filter": false,
        "responsive": true,
        "scrollX": true,
        "pageLength": 25,
        "order": [[0, "desc"]],
        "ajax": {
            "url": "/Home/GetPendingTaskData",
            "type": "POST",
            "datatype": "json",
            "data": function (d) {
                
            }
        },
        columns: [
            { "data": 'pending_Id', "visible": false },
            { "data": 'pending_Work' },
            {
                "data": 'p_Date',
                "render": function (data) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            {
                "data": 'deadline_dt',
                "render": function (data) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            { "data": 'for_Whom' },
            { "data": 'remark' },
            { "data": 'main_Attending_Person' },
            { "data": 'alternate_Attending_Person' },
            {
                "data": 'reminder_St_Dt',
                "render": function (data) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            { "data": 'attending_User_Group_Short_Name' },
            { "data": 'add_Init' },
            { "data": 'updt_Init' },
            { "data": 'last_Edtr' },
            { "data": 'certifier' },
            { "data": 'section_Short_Name' },
            { "data": 'section_Name' },
            { "data": 'urgency_Type_name' },
            { "data": 'urgency_Type_Short_name' },
            { "data": 'status_name' },
            { "data": 'status_Short_name' },
            { "data": 'user_Group_Name' },
            { "data": 'user_Group_Short_Name' }
        ]

    });
}
