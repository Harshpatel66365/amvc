﻿var tblDatatable = null;

$(document).ready(function () {
    var bookType = $('#bookOverdueTypeFlag').val();
    InitializeDatatable(bookType);
});

function InitializeDatatable(bookType) {
    tblDatatable = $("#bookOverDueTable").DataTable({
        "dom": '<"top"lBf>rt<"bottom"ip><"clear">',
        "buttons": getCommonButtons(),
        "searching": true,
        "processing": true,
        "serverSide": true,
        "filter": false,
        "responsive": true,
        "scrollX": true,
        "pageLength": 25,
        "order": [[0, "desc"]],
        "ajax": {
            "url": "/Home/GetBookOVerDuesData",
            "type": "POST",
            "datatype": "json",
            "data": function (d) {
                d.BookTypeFlag = bookType;
            }
        },
        columns: [
            { "data": 'bhandar_Code' },
            { "data": 'book_No' },
            { "data": 'is_Lost' },
            { "data": 'issue_Tran_No' },
            {
                "data": 'issue_Date',
                "render": function (data, type, row) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            { "data": 'issue_init' },
            {
                "data": 'expected_Date',
                "render": function (data, type, row) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            {
                "data": 'receipt_Dt',
                "render": function (data, type, row) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            { "data": 'reciever_Init' },
            { "data": 'prksn_Nam' },
            { "data": 'vol_Sub_Vol' },
            { "data": 'reader_No' },
            { "data": 'receipt_Tran_No' },
            { "data": 'book_Remark' },
            { "data": 'l_Ext_Iss_Gatepass_Remark' },
            { "data": 'l_Ext_Iss_Detail_Remark' },
            { "data": 'prksn_Key' },
            { "data": 'certifier' }
        ]
    });
}


