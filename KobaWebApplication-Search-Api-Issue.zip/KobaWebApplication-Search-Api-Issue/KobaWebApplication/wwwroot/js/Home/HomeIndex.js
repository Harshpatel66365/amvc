﻿$(document).ready(function () {
    pdfMake.fonts = {
        Mukta: {
            normal: "Mukta-Regular.ttf",
            bold: "Mukta-Bold.ttf",
        }
    };

    var savedPartial =
        sessionStorage.getItem("lastPartialView");
    if (savedPartial) {
        var [partial, receiver] = savedPartial.split('_');
        $('a[data-partial]').removeClass("active");
        $('a[data-partial=' + partial + ']').each(function () {
            var $this = $(this);
            if ($this.attr('data-partial') === partial && $this.attr('data-receiver') === receiver) {
                $this.addClass('active');
            }
        });

        loadPartialView(partial, receiver);
        $("#AtxtPratNoStart").on('change', function () {
            var pratStartNo = $(this).val();
            if (pratStartNo.length > 0) {
                $("#AtxtTotPetaAnkEnd").prop('disabled', false);
            }
            else {
                $("#AtxtTotPetaAnkEnd").prop('disabled', true);
            }
        });
    }

    $('a[data-partial]').on('click', function (e) {
        e.preventDefault();
        var partial = $(this).data('partial');
        var isReceiver = $(this).data('receiver');
        $('a[data-partial]').removeClass("active");
        $(this).addClass("active");
        loadPartialView(partial, isReceiver);
    });

    $(document).on('click', '.navbar-brand', function () {
        sessionStorage.removeItem("lastPartialView");
        clearCollapseState();
    });

    // Restore state on page load
    restoreCollapseState();
});

// Function to restore collapse state
function restoreCollapseState() {
    $('.collapse').each(function () {
        var id = $(this).attr('id');
        var state = sessionStorage.getItem(id);
        if (state === 'true') {
            $(this).addClass('show');
        }
    });
}

// Function to save collapse state
function saveCollapseState(collapse) {
    var id = collapse.attr('id');
    var isExpanded = collapse.hasClass('show');
    sessionStorage.setItem(id, isExpanded);
}

// Function to clear all collapse states
function clearCollapseState() {
    $('.collapse').each(function () {
        var id = $(this).attr('id');
        sessionStorage.removeItem(id);
    });
}

// Attach event listeners to collapsible elements
$('[data-bs-toggle="collapse"]').on('click', function () {
    var collapse = $($(this).attr('href'));
    collapse.on('shown.bs.collapse', function () {
        saveCollapseState(collapse);
    });
    collapse.on('hidden.bs.collapse', function () {
        saveCollapseState(collapse);
    });
});

// General function to load partial views
function loadPartialView(partialId, isReceiver) {
    var urlMap = {
        "KrEditReq": "/Home/_Kr_Edit_Req_Partial",
        "HpEditReq": "/Home/_Hp_Edit_Req_Partial",
        "VidEditReq": "/Home/_Vid_Edit_Req_Partial",
        "GachEditReq": "/Home/_VidGach_Edit_Req_Partial",
        "MagEditReq": "/Home/_Mag_Edit_Req_Partial",
        "PblsrEditReq": "/Home/_Pblsr_Edit_Req_Partial",
        "PrksnEditReq": "/Home/_Prksn_Edit_Req_Partial",
        "MagBindEditReq": "/Home/_MagBind_Edit_Req_Partial", // End Edit Req
        "KrUS": "/Home/_Kr_Unqie_Suggestion_Partial",
        "VidUS": "/Home/_Vid_Unqie_Suggestion_Partial",
        "GachUS": "/Home/_Vid_Gach_Unqie_Suggestion_Partial",
        "PblsrUS": "/Home/_Pblsr_Unqie_Suggestion_Partial",
        "PrksnUS": "/Home/_Prksn_Unqie_Suggestion_Partial", // End User Suggestions
        "DailyWorkLog": "Home/_DailyWorkLogs_Partial",
        "PendingTasks": "Home/_PendingTask_Partial",
        "RoutinWork": "Home/_RoutinWork_Partial",
        "UserAddUpdateBoard": "Home/_User_Score_Board_Partial",
        "ErrorSuggestions": "Home/_Error_Suggestion_Partial",
        "HpInternalIssue": "Home/_Hp_InternalIssue_Partial",
        "RemarkManagement": "Home/_RemarkManagement_Partial",
        "BookOverdue": "Home/_Book_OverDues_Partial",
    };

    var url = urlMap[partialId];
    if (!url) {
        console.error("Invalid partial ID");
        return;
    }

    if (isReceiver === "false" || isReceiver === false) {
        isReceiver = "false";
    } else if (isReceiver === "true" || isReceiver === true) {
        isReceiver = "true";
    }

    // Save the state in localStorage
    sessionStorage.setItem("lastPartialView", `${partialId}_${isReceiver}`);
    // Pass Arguments in ajax call if required
    var today = new Date();
    var startOfTodayStr = formatDate(today);
    var endOfTodayStr = formatDate(today);

    var ajaxData = isReceiver == "N" ? {} : (isReceiver == "D" ? { startDate: startOfTodayStr, endDate: endOfTodayStr } : !isNaN(Number(isReceiver)) && Number.isInteger(Number(isReceiver)) ? { type: parseInt(isReceiver) } : { isReceiver: isReceiver });

    $.ajax({
        url: url,
        type: 'GET',
        data: ajaxData,
        success: function (response) {
            $('#hdnDefaultPage').css('display', 'none');
            $('#commonDataTableContainer').html(response);
        },
        error: function (xhr, status, error) {
            alert('An error occurred while loading the partial view.');
        }
    });
}

//-----------------------------------------------------------------------//
// Common Function for Formatting
function formatDateTime(date) {
    var year = date.getFullYear();
    var month = String(date.getMonth() + 1).padStart(2, '0');
    var day = String(date.getDate()).padStart(2, '0');
    var hours = String(date.getHours()).padStart(2, '0');
    var minutes = String(date.getMinutes()).padStart(2, '0');
    var seconds = String(date.getSeconds()).padStart(2, '0');

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

function formatDate(date) {
    var year = date.getFullYear();
    var month = String(date.getMonth() + 1).padStart(2, '0');
    var day = String(date.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
}
