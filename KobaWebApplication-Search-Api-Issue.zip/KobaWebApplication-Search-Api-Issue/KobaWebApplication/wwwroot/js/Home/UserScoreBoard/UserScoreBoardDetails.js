﻿var tblUserScore = null;
$(document).ready(function () {
    $("#startDate").val($("#startDateVal").val());
    $("#endDate").val($("#endDateVal").val());
    InitializeDatatable();
});

function InitializeDatatable() {
    tblUserScore = $("#userScoreBoardTable").DataTable({
        "dom": '<"top"lBf>rt<"bottom"ip><"clear">',
        "buttons": getCommonButtons(),
        "searching": true,
        "processing": true,
        "serverSide": true,
        "filter": true,
        "responsive": true,
        "scrollX": true,
        "pageLength": 25,
        "order": [0, 'desc'],
        "ajax": {
            "url": "/Home/GetUserScoreBoardData",
            "type": "POST",
            "datatype": "json",
            "data": function (d) {
                d.StartDate = $('#startDate').val();
                d.EndDate = $('#endDate').val();
                d.Username = $('#username').val();
            }
        },
        columns: [
            { "data": "tableName" },
            { "data": "add_Record_Count" },
            { "data": "update_Record_Count" }
        ]
    });
}

$('#flterData').click(function () {
    const fromDate = new Date($('#startDate').val());
    const toDate = new Date($('#endDate').val());

    if (fromDate && toDate && fromDate > toDate) {
        alert('From Date should be earlier than To Date.');
        return;
    }

    tblUserScore.ajax.reload();
});