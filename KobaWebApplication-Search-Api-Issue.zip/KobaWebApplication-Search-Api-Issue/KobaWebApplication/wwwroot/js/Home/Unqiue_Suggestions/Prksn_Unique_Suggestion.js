﻿var tblDatatable = null;

$(document).ready(function () {
    var isReceiver = $('#isReceiverFlag_PrksnUnq').val();
    InitializeDatatable(isReceiver);
});

function InitializeDatatable(isReceiver) {
    tblDatatable = $("#prksnUniqueSuggestionTable").DataTable({
        "dom": '<"top"lBf>rt<"bottom"ip><"clear">',
        "buttons": getCommonButtons(),
        "searching": true,
        "processing": true,
        "serverSide": true,
        "filter": false,
        "responsive": true,
        "scrollX": true,
        "pageLength": 10,
        "order": [[0, "desc"]],
        "ajax": {
            "url": "/Home/GetPrksnUniqueReqData",
            "type": "POST",
            "datatype": "json",
            "data": function (d) {
                d.IsSuggestionToYou = isReceiver.toLowerCase() == "false" ? false : true;
            }
        },
        columns: [
            { "data": 'unique_Suggestion_Id' },
            { "data": 'destination_Prksn_Key' },
            { "data": 'source_Prksn_Key' },
            { "data": 'unique_Type_Short_Name' },
            {
                "data": 'send_Dt',
                "render": function (data, type, row) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            { "data": 'send_Msg' },
            { "data": 'receiver_Init' },
            {
                "data": 'reply_Dt',
                "render": function (data, type, row) {
                    return data ? new Date(data).toLocaleDateString() : '';
                }
            },
            { "data": 'reply_Msg' },
            { "data": 'status_Short_Name' },
            { "data": 'remark' },
            { "data": 'add_Init' },
            { "data": 'updt_Init' },
            { "data": 'last_Edtr' },
            { "data": 'certifier' },
            { "data": 'updt_Authority_Level' },
            { "data": 'certifier_Authority_Level' }
        ]

    });
}


