﻿$(document).ready(function () {
    sessionStorage.clear();
});