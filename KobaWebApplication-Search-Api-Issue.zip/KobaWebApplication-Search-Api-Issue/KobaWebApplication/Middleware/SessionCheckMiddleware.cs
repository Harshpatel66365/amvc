﻿using System.Security.Claims;

namespace KobaWebApplication.Middleware
{
    public class SessionCheckMiddleware
    {
        private readonly RequestDelegate _next;

        public SessionCheckMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            context.Response.Headers["Cache-Control"] = "no-cache, no-store, must-revalidate";
            context.Response.Headers["Pragma"] = "no-cache";
            context.Response.Headers["Expires"] = "-1";

            if (context.Request.Path.Value == ("/") || context.Request.Path.Value.Contains("Login") || context.Request.Path.Value.Contains("Browser") || context.Request.Path.Value.Contains("Book"))
            {
            }
            else
            {
                // Check if the session value exists
                string currentRoleId = Convert.ToString(context.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value);
                if (string.IsNullOrEmpty(currentRoleId))
                {
                    // Capture the original path and query string
                    var returnPath = context.Request.Path + context.Request.QueryString;

                    // Redirect to login page with the ReturnPath
                    context.Response.Redirect($"/Login?ReturnPath={Uri.EscapeDataString(returnPath)}");
                    return;
                }
            }

            // Continue to the next middleware/component in the pipeline
            await _next(context);
        }
    }
}