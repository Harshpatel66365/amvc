﻿using KobaWebApplication.BusinessLogic.UnitOfWork;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace KobaWebApplication.Actionfilters
{
    public class LanguageListActionFilter : IAsyncActionFilter
    {
        private readonly IUnitOfWorkBL _unitOfWorkBL;
        private readonly HttpContext _httpContext;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public LanguageListActionFilter(IUnitOfWorkBL unitOfWorkBL, IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWorkBL = unitOfWorkBL;
            _httpContext = httpContextAccessor.HttpContext;
        }

        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var controller = context.Controller as Controller;
            if (controller != null)
            {
                string currentUserInitial = Convert.ToString(_httpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value);
                var languageList = await _unitOfWorkBL.LoginOptionBL.GetLanguageList();
                var bhandarList = await _unitOfWorkBL.LoginOptionBL.GetBhandarList(currentUserInitial);
                var bhandarGroup = await _unitOfWorkBL.LoginOptionBL.LoadBhandarGroupListAsync(currentUserInitial);
                controller.ViewData["LanguageList"] = languageList;
                controller.ViewData["BhandarGroupList"] = bhandarGroup;
                controller.ViewData["BhandarList"] = bhandarList;
            }

            await next();
        }
    }
}