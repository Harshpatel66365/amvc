﻿using KobaWebApplication.Localization;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Localization;

namespace KobaWebApplication.Core.Localization
{
    public static class JsonStringServiceHandler
    {
        public static void SetupJsonStrinLocalizer(this IServiceCollection services)
        {
            services.AddLocalization();
            services.AddDistributedMemoryCache();
            services.AddSingleton<IStringLocalizerFactory, JsonStringLocalizerFactory>();
            services
                .AddControllersWithViews()
                .AddViewLocalization();
        }
    }
}
