﻿namespace KobaWebApplication.Core.Common
{
    public class MagnusMindsCommon
    {
        
        //To get ghost name while adding name in the database
        //returns the string after filtering the vFilterCharArr characters.
        public static string GetFilteredName(string vStringData)
        {
            char[] vFilterCharacter = new char[] { '-', ' ', ':', ';', '(', ')', '[', ']', '{', '}', '\\', '<', '>', '~', '*', '|', '.', '%', '$', '#', '@', '/', ',', '?', '`', '\'', '!', '&', '^', '।', '॥', '०', '॰', '\u0022' };
            //char[] vFilterCharacter = new char[] {'-', ' ', ':', ';', '(', ')', '[', ']', '{', '}', '\\', '<', '>', '~', '*', '|', '.', '%', '$', '#', '@',  ',', '?', '`',  '!', '&', '^', '।', '॥', '०', '॰', '\u0022'}; //change by rajni 30-11-2017
            int vintLength = 0;
            vintLength = vStringData.IndexOfAny(vFilterCharacter);
            while (vintLength >= 0)
            {
                vStringData = vStringData.Remove(vintLength, 1);
                vintLength = vStringData.IndexOfAny(vFilterCharacter);
            }
            return vStringData;

        }

        public static string GetFilteredNameBuildQuery(string vStringData)
        {
            //Start - Added by ADP on 4-3-2018
            char[] vFilterCharacter = new char[] { '-', ' ', ':', ';', '[', ']', '{', '}', '<', '>', '~', '*', '|', '.', '%', '$', '#', '@', ',', '?', '`', '&', '^', '।', '॥', '०', '॰', '\u0022' };//'(', ')', //'\\', //'/', //'\'', //'!',
            int vintLength = 0;
            vintLength = vStringData.IndexOfAny(vFilterCharacter);
            while (vintLength >= 0)
            {
                vStringData = vStringData.Remove(vintLength, 1);
                vintLength = vStringData.IndexOfAny(vFilterCharacter);
            }

            if (vStringData.Contains("("))
            {
                char[] vConditionalOperator = { '+', '/', '\'' };
                char[] vSBraces = { '(' };
                char[] vEBraces = { ')' };
                vintLength = vStringData.IndexOfAny(vSBraces);
                while (vintLength > 0)
                {
                    if (Convert.ToBoolean(vStringData.Substring(vintLength - 1, 1).IndexOfAny(vConditionalOperator)))
                    {
                        vStringData = vStringData.Remove(vintLength, 1);
                        vintLength = vStringData.LastIndexOfAny(vEBraces);
                        vStringData = vStringData.Remove(vintLength, 1);
                        vintLength = vStringData.LastIndexOfAny(vSBraces);
                    }
                    else
                    {
                        vintLength = vStringData.LastIndexOfAny(vEBraces);
                        if (vStringData.Length - 1 > vintLength)
                        {
                            if (Convert.ToBoolean(vStringData.Substring(vintLength + 1, 1).IndexOfAny(vConditionalOperator)))
                            {
                                vStringData = vStringData.Remove(vintLength, 1);
                                vintLength = vStringData.IndexOfAny(vSBraces);
                                vStringData = vStringData.Remove(vintLength, 1);
                                vintLength = vStringData.IndexOfAny(vSBraces);
                            }
                            else
                            {
                                return vStringData;
                            }
                        }
                        else
                        {
                            return vStringData;
                        }
                    }
                }
            }
            return vStringData;
        }

        //This operation is performed when vidvan browser is opened for selection
        //Assign selected entity value in to setselected prop.
        //To get entity no, call getselectedno, to get entity nam seq, call getselectedseq
        public class SelectedEntity
        {
            private static string[] vStr = new string[2];

            public static string SetSelected
            {
                set
                {
                    if (value.IndexOf("-", StringComparison.Ordinal) != -1)
                    {
                        vStr = value.Split(new[] { '-' }, StringSplitOptions.None);
                    }
                    else
                    {
                        if (value.Length == 6)
                        {
                            vStr[0] = value;
                        }
                        else
                        {
                            vStr[0] = "";
                        }
                        vStr[1] = "";
                    }
                }
            }

            public static string GetSelectedNo
            {
                get
                {
                    return vStr[0];
                }
            }

            public static string GetSelectedSeq
            {
                get
                {
                    return vStr[1];
                }
            }
        }

        //To encrpt the password
        public static string g_Pwd_Encrypt(string Pwd)
        {
            string PwdEncrypt = "";
            int lenpwd = Pwd.Length;

            for (int i = 1; i <= lenpwd; i++)
            {
                PwdEncrypt = (char)(Pwd[i - 1] - i) + PwdEncrypt;
            }

            if (lenpwd % 2 == 0)
            {
                for (int i = 1; i <= 30 - lenpwd - 1; i++)
                {
                    PwdEncrypt += (char)(PwdEncrypt[i - 1] - 1);
                }
                PwdEncrypt += (char)(lenpwd + 60);
            }
            else
            {
                for (int i = 1; i <= 30 - lenpwd - 1; i++)
                {
                    PwdEncrypt = (char)(PwdEncrypt[i - 1] - 1) + PwdEncrypt;
                }
                PwdEncrypt += (char)(lenpwd + 60);
            }

            return PwdEncrypt;
        }


        //To decrypt password
        public static string g_Pwd_Decrypt(string Pwd_Encrypt)
        {
            string password = "";
            int len_pwd = (int)Pwd_Encrypt[Pwd_Encrypt.Length - 1] - 60;

            if (len_pwd % 2 == 0)
            {
                string pwd_full = Pwd_Encrypt.Substring(0, len_pwd);
                int j = 1;
                for (int i = len_pwd; i >= 1; i--)
                {
                    password += (char)(pwd_full[len_pwd - j] + j);
                    j++;
                }
            }
            else
            {
                string pwd_full = Pwd_Encrypt.Substring(30 - len_pwd - 1);
                int j = 1;
                for (int i = len_pwd; i >= 1; i--)
                {
                    password += (char)(pwd_full[len_pwd - j] + j);
                    j++;
                }
            }

            return password;
        }

    }
}