﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KobaWebApplication.Core.Common
{
    public class KobaEnums
    {
    }
    public enum LoginMSG
    {
        EmptyUserPsw = 5001,
        ErrorInvalidLogin = 5002,
        ErrorAlreadyLogin = 5003
    }

    public enum Tables
    {
        Vid_Edit_Request,
        Kr_Edit_Request,
        Mag_Edit_Request,
        Vid_Gach_Edit_Request,
        Pblsr_Edit_Request,
        Prksn_Edit_Request,
        Hp_Edit_Request,
        Kr_Unique_Suggestion,
        Vid_Unique_Suggestion,
        Vid_Gach_Unique_Suggestion,
        Prksn_Unique_Suggestion,
        Pblsr_Unique_Suggestion,
        Mag_Bind_Edit_Request
    }

    public enum BrowserType
    {
        OthersVidEditRequest,
        OthersKrEditRequest,
        OthersMagEditRequest,
        OthersPblsrEditRequest,
        OthersPrksnEditRequest,
        OthersHpEditRequest,
        OthersVidGachRequest,
        YoursVidEditRequest,
        YoursKrEditRequest,
        YoursMagEditRequest,
        YoursPblsrEditRequest,
        YoursPrksnEditRequest,
        YoursHpEditRequest,
        YoursVidGachRequest,
        OthersVidUniqueSuggestion,
        OthersKrUniqueSuggestion,
        OthersPblsrUniqueSuggestion,
        OthersPrksnUniqueSuggestion,
        OthersVidGachUniqueSuggestion,
        YoursVidUniqueSuggestion,
        YoursKrUniqueSuggestion,
        YoursPblsrUniqueSuggestion,
        YoursPrksnUniqueSuggestion,
        YoursVidGachUniqueSuggestion,
        Kruti, //' This line is added by nigam 291109
        HastpratBrowser, //' This line is added by nigam 291109
        VidBrowser, //' This line is added by nigam 301109
        PrksnBrowser, //' This line is added By Nigam 301109
        PblsrBrowser, //' This line is added By Nigam 301109
        GachBrowser, //' This line is added By Nigam 301109
        MagBrowser, //' This line is added By Nigam 041209
        MagBindBrowser, //' This line is Added By Manish Bhai
        OthersMagbindRequest, //' This Line is added By Nigam on 311209
        YoursMagbindEditRequest //' This Line is added By Nigam on 311209
    }

    public enum BookOverDueType
    {
        DailyOverdue = 1,
        WeeklyOverdue = 2,
        MonthlyOverdue = 3,
        OldOverdue = 4,
        FollowupPendingOverdue = 5
    }

    public enum ErrorType
    {
        ErrorsPosted = 1,
        ErrorsSolved = 2,
        ErrorsPending = 3,
        ErrorsExplainationNeeded = 4,
        ErrorsCompletedByProgrammer = 5,
        Suggestion_Posted = 6
    }

    public enum HpInternalIssueType
    {
        Hp_InternalIssue_Detail = 1,
        Hp_Internal_Issue_Pending_Detail = 2,
        Hp_Internal_Issued_But_Not_Returned_Detail = 3
    }
}
