﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Globalization;
using System.Text.RegularExpressions;
using Wkhtmltopdf.NetCore;

namespace KobaWebApplication.Core.CommonHelper
{
    public class CommonMethod
    {
        private readonly IGeneratePdf _generatePdf;

        public CommonMethod(IGeneratePdf generatePdf)
        {
            _generatePdf = generatePdf;
        }

        public static decimal GetCalculatedPrice(decimal CostPrice, decimal? RetailerPercentage, int? RoundTo)
        {
            decimal retailerPrice = RetailerPercentage > 0 ? CostPrice + (CostPrice * Convert.ToDecimal(RetailerPercentage) / 100) : CostPrice;
            retailerPrice = RoundTo > 0 ? (decimal)(RoundTo) * Math.Round((decimal)(retailerPrice / RoundTo)) : retailerPrice;
            return Math.Round(Math.Round(retailerPrice));
        }

        public static string ToCurrencyFormat(decimal num)
        {
            return String.Format(new CultureInfo("en-IN", false), "{0:n}", Convert.ToDouble(num)).Replace(".000", "").Replace(".00", "");
        }

        public static string ToRemoveDecimalFormat(decimal num)
        {
            return String.Format("{0:n}", Convert.ToDouble(num)).Replace(".000", "").Replace(".00", "");
        }

        public byte[] GeneratePDF(string html)
        {
            var options = new ConvertOptions
            {
                PageMargins = new Wkhtmltopdf.NetCore.Options.Margins()
                {
                    Top = 6,
                    Right = 4,
                    Left = 4,
                    Bottom = 6
                },
                PageSize = Wkhtmltopdf.NetCore.Options.Size.A4,
                PageOrientation = Wkhtmltopdf.NetCore.Options.Orientation.Portrait
            };
            _generatePdf.SetConvertOptions(options);
            return _generatePdf.GetPDF(html);
        }

        public static string GetUniqueFileName(string fileName)
        {
            fileName = Path.GetFileName(fileName);
            var UniqueFileName =
                Path.GetFileNameWithoutExtension(fileName).Substring(0, 1)
                + "_" +
                Convert.ToString(Guid.NewGuid())//.Substring(0, 4)
                      + Path.GetExtension(fileName).ToLower();
            return UniqueFileName;
        }

        public static string ProvidedByCustomer = "PROCUST";

        public string GetURL()
        {
            // List of characters and numbers to be used...
            List<int> numbers = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 };
            List<char> characters = new List<char>() {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
                                                        'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D',
                                                        'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S',
                                                        'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '-', '_'};
            string URL = "";
            Random rand = new Random();
            // run the loop till I get a string of 10 characters
            for (int i = 0; i < 8; i++)
            {
                // Get random numbers, to get either a character or a number...
                int random = rand.Next(0, 3);
                if (random == 1)
                {
                    // use a number
                    random = rand.Next(0, numbers.Count);
                    URL += Convert.ToString(numbers[random]);
                }
                else
                {
                    random = rand.Next(0, characters.Count);
                    URL += Convert.ToString(characters[random]);
                }
            }
            return URL;
        }

        public bool IsBase64String(string base64)
        {
            base64 = base64.Trim();
            return (base64.Length % 4 == 0) && Regex.IsMatch(base64, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None);
        }

        public bool IsValidJson(string strInput)
        {
            if (string.IsNullOrWhiteSpace(strInput)) { return false; }
            strInput = strInput.Trim();
            if ((strInput.StartsWith("{") && strInput.EndsWith("}")) || //For object
                (strInput.StartsWith("[") && strInput.EndsWith("]"))) //For array
            {
                try
                {
                    var obj = JToken.Parse(strInput);
                    return true;
                }

                //Exception in parsing json
                catch (JsonReaderException jex)
                {
                    Console.WriteLine(jex.Message);
                    return false;
                }

                //some other exception
                catch (Exception ex) 
                {
                    Console.WriteLine(Convert.ToString(ex));
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

    }
}