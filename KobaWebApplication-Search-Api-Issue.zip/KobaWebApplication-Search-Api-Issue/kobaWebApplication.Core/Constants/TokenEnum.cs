﻿namespace KobaWebApplication.Core.Constants
{
    public enum TokenEnum
    {
        intUserId,
        UserId,
        FullName,
        Name,
        NameIdentifier,
        Role,
        RoleId,
        EmailAddress,
        TenantID,
        TenantName,
        TenantLogo,
        LoginUserToken,
        MacAddress
    }
}