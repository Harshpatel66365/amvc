﻿namespace KobaWebApplication.Core.Constants
{
    public enum MemoryCacheEnum
    {
        UserTenantDetails_,
        Tenant,
        TenantInfo,
        TenantModulePermissions_,
        TenantWhatsAppDetails_,
        TenantSMTPDetail,
        TenantReminderSettings,
        UserTenantMapping,
        UserTenantMappingByTenantIdWithDelete_,
        Complains,
        Feedback,
        Leads,
        SocialMedia,
        BackOfficePermission,
        Role,
        RoleClaims,
        Category,
        Offer,
    }
}
