﻿namespace KobaWebApplication.Core.Constants
{
    public enum ModuleNameEnum
    {
        Product,
        Order
    }
}