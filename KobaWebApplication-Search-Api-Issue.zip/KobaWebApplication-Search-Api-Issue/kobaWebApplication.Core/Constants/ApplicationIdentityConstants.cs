﻿namespace KobaWebApplication.Core.Constants
{
    public static class ApplicationIdentityConstants
    {
        public static readonly string DefaultPassword = "Password@1";
        public static readonly string EncryptionSecret = "MAGNUSMINDS_SAB_KA_BAAP";

        public static class Roles
        {
            public static readonly string SuperAdmin = "SuperAdmin_0";
            public static readonly string[] RolesSupported = { SuperAdmin };
        }
        public static class Permissions
        {
            public static List<string> GeneratePermissionsForModule(string application, string module)
            {
                return new List<string>()
                {
                    $"Permissions.{application}.{module}.View",
                    $"Permissions.{application}.{module}.Create",
                    $"Permissions.{application}.{module}.Delete",
                };
            }

            public static List<string> GeneratePermissionsForModule(string application, string module, string permission)
            {
                return new List<string>() { $"Permissions.{application}.{module}.{permission}" };
            }

            public static List<string> GetAllPermissions()
            {
                return GeneratePermissionsForModule("WebApp", "Home", "YoursEditRequest")
                    .Union(GeneratePermissionsForModule("WebApp", "Home", "OthersEditRequest"))
                    .Union(GeneratePermissionsForModule("WebApp", "Home", "YoursUniqueSuggestion"))
                    .Union(GeneratePermissionsForModule("WebApp", "Home", "OthersUniqueSuggestion"))
                    .Union(GeneratePermissionsForModule("WebApp", "Home", "DailyWorkLog"))
                    .Union(GeneratePermissionsForModule("WebApp", "Home", "PendingTasks"))
                    .Union(GeneratePermissionsForModule("WebApp", "Home", "RoutineWork"))
                    .Union(GeneratePermissionsForModule("WebApp", "Home", "UserAddUpdateScoreBoard"))
                    .Union(GeneratePermissionsForModule("WebApp", "Home", "UserErrorSuggestionScoreBoard"))
                    .Union(GeneratePermissionsForModule("WebApp", "Home", "HpInternalIssueReceive"))
                    .Union(GeneratePermissionsForModule("WebApp", "Home", "RemarkManagement"))
                    .Union(GeneratePermissionsForModule("WebApp", "Home", "BookOverdue"))
                    .Union(GeneratePermissionsForModule("WebApp", "Identity", "UserManage"))
                    .Union(GeneratePermissionsForModule("WebApp", "Identity", "RoleManage"))
                    .Union(GeneratePermissionsForModule("WebApp", "Header", "Tool"))
                    .Union(GeneratePermissionsForModule("WebApp", "Header", "Browser"))
                    .Union(GeneratePermissionsForModule("WebApp", "Header", "Museum"))
                    .Union(GeneratePermissionsForModule("WebApp", "Header", "Reports"))
                    .ToList();
            }

            public static class PortalAccess
            {
                public const string PortalAccessView = "Permissions.Portal.PortalAccess.View";
            }

            public static class WebAppHome
            {
                public const string YoursEditRequest = "Permissions.WebApp.Home.YoursEditRequest";
                public const string OthersEditRequest = "Permissions.WebApp.Home.OthersEditRequest";
                public const string YoursUniqueSuggestion = "Permissions.WebApp.Home.YoursUniqueSuggestion";
                public const string OthersUniqueSuggestion = "Permissions.WebApp.Home.OthersUniqueSuggestion";
                public const string DailyWorkLog = "Permissions.WebApp.Home.DailyWorkLog";
                public const string PendingTasks = "Permissions.WebApp.Home.PendingTasks";
                public const string RoutineWork = "Permissions.WebApp.Home.RoutineWork";
                public const string UserAddUpdateScoreBoard = "Permissions.WebApp.Home.UserAddUpdateScoreBoard";
                public const string UserErrorSuggestionScoreBoard = "Permissions.WebApp.Home.UserErrorSuggestionScoreBoard";
                public const string HpInternalIssueReceive = "Permissions.WebApp.Home.HpInternalIssueReceive";
                public const string RemarkManagement = "Permissions.WebApp.Home.RemarkManagement";
                public const string BookOverdue = "Permissions.WebApp.Home.BookOverdue";

                public const string UserManage = "Permissions.WebApp.Identity.UserManage";
                public const string RoleManage = "Permissions.WebApp.Identity.RoleManage";
                
                public const string Tool = "Permissions.WebApp.Header.Tool";
                public const string Browser = "Permissions.WebApp.Header.Browser";
                public const string Museum = "Permissions.WebApp.Header.Museum";
                public const string Reports = "Permissions.WebApp.Header.Reports";
            }
        }
    }
}