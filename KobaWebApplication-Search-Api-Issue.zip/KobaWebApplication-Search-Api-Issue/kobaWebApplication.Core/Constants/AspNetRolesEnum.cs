﻿namespace KobaWebApplication.Core.Constants
{
    public enum AspNetRolesEnum
    {
        Administrator,
        Contractor,
        SuperAdmin,
        StoreManager,
        SalesRepresentative,
        Supervisor,
        Wholesaler,
        SystemUser
    }
}