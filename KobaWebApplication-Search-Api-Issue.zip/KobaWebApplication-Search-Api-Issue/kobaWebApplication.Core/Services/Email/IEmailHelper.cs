﻿using MimeKit;

namespace KobaWebApplication.Core.Services.Email
{
    public interface IEmailHelper
    {
        Task<MimeMessage> SendEmail(string subject, string htmlContent, List<string> to, List<string> cc = null, List<string> bcc = null, string mailFrom = null);

        Task SendEmailWithAttachment(string subject, string htmlContent, List<byte[]> attachmentsArray, string attachmentFileName, List<string> to, List<string> cc = null, List<string> bcc = null, string mailFrom = null);
    }
}