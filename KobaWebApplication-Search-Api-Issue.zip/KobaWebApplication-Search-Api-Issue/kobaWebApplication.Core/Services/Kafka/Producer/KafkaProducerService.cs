﻿using Confluent.Kafka;
using Microsoft.Extensions.Configuration;

namespace KobaWebApplication.Core.Services.Kafka.Producer
{
    public class KafkaProducerService : IKafkaProducerService
    {
        private readonly IProducer<string, string> _producer;

        public KafkaProducerService(IConfiguration configuration)
        {
            var kafkaConfig = new ProducerConfig
            {
                BootstrapServers = configuration["KafkaConfig:BootstrapServers"],
                BrokerAddressFamily = BrokerAddressFamily.V4
            };

            _producer = new ProducerBuilder<string, string>(kafkaConfig).Build();
        }

        public async Task ProduceAsync(string topic, string key, string value)
        {
            var message = new Message<string, string>
            {
                Key = key,
                Value = value
            };

            var deliveryResult = await _producer.ProduceAsync(topic, message);
        }

        public Task Dispose()
        {
            throw new NotImplementedException();
        }
    }
}
