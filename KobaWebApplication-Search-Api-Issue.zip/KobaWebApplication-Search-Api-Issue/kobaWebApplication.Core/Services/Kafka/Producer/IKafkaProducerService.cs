﻿namespace KobaWebApplication.Core.Services.Kafka.Producer
{
    public interface IKafkaProducerService
    {
        Task ProduceAsync(string topic, string key, string value);
        Task Dispose();
    }
}
