﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using KobaWebApplication.DataEntities;

namespace KobaWebApplication.Infrastructure.ServiceDependency
{
    public static class DatabaseConfig
    {
        /// <summary>
        ///     Setup ASP.NET Core Identity DB, including connection string, Identity options, token providers, and token services, etc..
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        public static void SetupIdentityDatabase(this IServiceCollection services, IConfiguration configuration)
        {
            string dataBaseEnvironment = configuration.GetConnectionString("DataBaseEnvironment");

            if (dataBaseEnvironment == "MSSQL")
            {
                /*
                  services.AddDbContext<ApplicationDbContext>(options =>
                  {
                      if (Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Development")
                          options.UseLoggerFactory(LoggerFactory.Create(builder => builder.AddConsole()));
                      options.UseSqlServer(configuration.GetConnectionString("DefaultConnection"), b => b.MigrationsAssembly("MidCapERP.DataEntities"));
                  });
                  */
                services.AddDbContext<ApplicationDbContext>(options =>
                {
                    if (Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Development")
                        options.UseLoggerFactory(LoggerFactory.Create(builder => builder.AddConsole()));
                    options.UseSqlServer(configuration.GetConnectionString("DefaultConnection"), sqlServerOptions =>
                    {
                        sqlServerOptions.MigrationsAssembly("MidCapERP.DataEntities");
                        sqlServerOptions.EnableRetryOnFailure(
                            maxRetryCount: 5,
                            maxRetryDelay: TimeSpan.FromSeconds(30),
                            errorNumbersToAdd: null
                        );
                    });
                });
            }

            if (dataBaseEnvironment == "MYSQL")
            {
                services.AddDbContextPool<ApplicationDbContext>(options =>
                {
                    options.UseMySql(
                        configuration.GetConnectionString("DefaultConnection"),
                        ServerVersion.AutoDetect(configuration.GetConnectionString("DefaultConnection")),
                        options => options.EnableRetryOnFailure(
                            maxRetryCount: 5,
                            maxRetryDelay: System.TimeSpan.FromSeconds(30),
                            errorNumbersToAdd: null)
                        );
                });
            }
        }
    }
}