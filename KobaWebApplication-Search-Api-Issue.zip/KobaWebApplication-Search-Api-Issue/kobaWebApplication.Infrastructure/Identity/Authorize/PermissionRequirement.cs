﻿using Microsoft.AspNetCore.Authorization;

namespace KobaWebApplication.Infrastructure.Identity.Authorization
{
    public class PermissionRequirement : IAuthorizationRequirement
    {
        public string Permission { get; private set; }

        public PermissionRequirement(string permission)
        {
            Permission = permission;
        }
    }
}