﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using KobaWebApplication.DataEntities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace KobaWebApplication.Infrastructure.Identity.Authorize
{
    public class AppClaimsPrincipalFactory : UserClaimsPrincipalFactory<L_User, Role>
    {
        public AppClaimsPrincipalFactory(UserManager<L_User> userManager, 
            RoleManager<Role> roleManager,
            IOptions<IdentityOptions> optionsAccessor)
               : base(userManager, roleManager, optionsAccessor)
        {
        }
        public override async Task<ClaimsPrincipal> CreateAsync(L_User user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }
            var userId = await UserManager.GetUserIdAsync(user);
            var userName = await UserManager.GetUserNameAsync(user);
            var id = new ClaimsIdentity("Identity.Application",
                Options.ClaimsIdentity.UserNameClaimType,
                Options.ClaimsIdentity.RoleClaimType);
            id.AddClaim(new Claim(Options.ClaimsIdentity.UserIdClaimType, userId));
            id.AddClaim(new Claim(Options.ClaimsIdentity.UserNameClaimType, userName));
            if (UserManager.SupportsUserSecurityStamp)
            {
                id.AddClaim(new Claim(Options.ClaimsIdentity.SecurityStampClaimType,
                    await UserManager.GetSecurityStampAsync(user)));
            }

            // code removed that adds the role claims 
            if (UserManager.SupportsUserClaim)
            {
                var claims = await UserManager.GetClaimsAsync(user);
                id.AddClaims(claims);

            }

            return new ClaimsPrincipal(id);
        }
    }
}
