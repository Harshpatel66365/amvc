using Microsoft.AspNetCore.Identity;
using KobaWebApplication.Core.Constants;
using KobaWebApplication.DataEntities.Models;
using System.Security.Claims;

namespace KobaWebApplication.Infrastructure.Identity.Seed
{
    public class ApplicationDbContextDataSeed
    {
        /// <summary>
        ///     Seed users and roles in the Identity database.
        /// </summary>
        /// <param name="userManager">ASP.NET Core Identity User Manager</param>
        /// <param name="roleManager">ASP.NET Core Identity Role Manager</param>
        /// <returns></returns>
        /*public static async Task SeedAsync()
        {
            // Add roles supported
            await roleManager.CreateAsync(new ApplicationRole(ApplicationIdentityConstants.Roles.SuperAdmin, 0));

            // New admin user
            string adminUserName = "kparmar@magnusminds.net";
            var adminUser = new ApplicationUser
            {
                UserName = adminUserName,
                Email = adminUserName,
                IsActive = true,
                EmailConfirmed = true,
                FirstName = "Kishan",
                LastName = "Parmar"
            };

            var checkAdminUser = await userManager.FindByNameAsync(adminUserName);
            // Add new user and their role
            if (checkAdminUser == null)
            {
                await userManager.CreateAsync(adminUser, ApplicationIdentityConstants.DefaultPassword);
                await userManager.AddToRoleAsync(adminUser, ApplicationIdentityConstants.Roles.SuperAdmin);
            }
            var administratorRole = await roleManager.FindByNameAsync(ApplicationIdentityConstants.Roles.SuperAdmin);
            await GrantPermissionToAdminUser(roleManager, administratorRole);
        }

        private static async Task GrantPermissionToAdminUser(RoleManager<ApplicationRole> roleManager, ApplicationRole administratorRole)
        {
            var allClaims = await roleManager.GetClaimsAsync(administratorRole);
            foreach (var item in allClaims)
                await roleManager.RemoveClaimAsync(administratorRole, item);


            var allRoles = roleManager.Roles.ToList();
            foreach (var role in allRoles)
            {
                if (role.Name != administratorRole.Name)
                {
                    var allRoleClaims = await roleManager.GetClaimsAsync(role);
                    if (!allRoleClaims.Any(a => a.Value == ApplicationIdentityConstants.Permissions.PortalAccess.PortalAccessView))
                    {
                        await roleManager.AddClaimAsync(role, new Claim(CustomClaimTypes.Permission, "Permissions.Portal.PortalAccess.View"));
                    }
                }
            }

            var allPermissions = ApplicationIdentityConstants.Permissions.GetAllPermissions();
            foreach (var permission in allPermissions)
                await roleManager.AddClaimAsync(administratorRole, new Claim(CustomClaimTypes.Permission, permission));
        }*/
    }
}