﻿using KobaWebApplication.DataEntities.Models;

namespace KobaWebApplication.Infrastructure.Identity.Models
{
    public class TokenResponse
    {
        public TokenResponse()
        { }

        public TokenResponse(L_User user,
                             string role,
                             string token,
                             string tenantId,
                             string roleId,
                            //string refreshToken
                            string organizationType,
                            bool isDimensionVisible,
                            bool isPaymentIntegrated,
                            string? razorPayKeyId)
        {
            Id = user.Id.ToString();
            Initial = Convert.ToString(user.Usr_Init).ToUpper();
            FullName = user.Usr_Name;
            EmailAddress = user.Email;
            Token = token;
            Role = role;
            RoleId = roleId;
            UserId = user.Id;
            OrganizationType = organizationType;
            IsDimensionVisible = isDimensionVisible;
            IsPaymentIntegrated = isPaymentIntegrated;
            RazorPayKeyId = razorPayKeyId;
            //RefreshToken = refreshToken;
        }

        public string Id { get; set; }
        public string Initial { get; set; }
        public string FullName { get; set; }
        public string EmailAddress { get; set; }
        public string Token { get; set; }
        public string Role { get; set; }
        public string RoleId { get; set; }
        public string FCMToken { get; set; }
        public long UserId { get; set; }
        public string OrganizationType { get; set; }
        public bool IsDimensionVisible { get; set; }
        public bool IsPaymentIntegrated { get; set; }
        public string? RazorPayKeyId { get; set; }

        //[JsonIgnore]
        //public string RefreshToken { get; set; }
    }
}