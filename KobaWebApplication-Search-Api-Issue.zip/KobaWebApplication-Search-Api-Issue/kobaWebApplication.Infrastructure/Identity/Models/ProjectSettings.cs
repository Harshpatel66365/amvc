﻿namespace KobaWebApplication.Infrastructure.Identity.Models
{
    public class ProjectSettings
    {
        public bool IsAPI { get; set; }
    }
}