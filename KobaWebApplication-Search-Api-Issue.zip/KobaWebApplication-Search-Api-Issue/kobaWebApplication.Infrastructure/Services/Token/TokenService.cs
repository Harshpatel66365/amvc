﻿using AutoMapper;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using KobaWebApplication.Core.Constants;
using KobaWebApplication.Core.UserDefinedException;
using KobaWebApplication.DataAccess.UnitOfWork;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Infrastructure.Identity.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace KobaWebApplication.Infrastructure.Services.Token
{
    /// <inheritdoc cref="ITokenService" />
    public class TokenService : ITokenService
    {
        private readonly TokenConfiguration _token;
        private readonly HttpContext _httpContext;
        private readonly IUnitOfWorkDA _unitOfWorkDA;
        public readonly IMapper _mapper;

        /// <inheritdoc cref="ITokenService" />
        public TokenService(
            IUnitOfWorkDA unitOfWorkDA,
            IOptions<TokenConfiguration> tokenOptions,
            IHttpContextAccessor httpContextAccessor,
             IMapper mapper
             )
        {
            _token = tokenOptions.Value;
            _httpContext = httpContextAccessor.HttpContext;
            _unitOfWorkDA = unitOfWorkDA;
            _mapper = mapper;
        }

        /// <summary>
        ///     Issue JWT token
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        private async Task<string> GenerateJwtToken(L_User user, CancellationToken cancellationToken, bool isCookie = false)
        {
            byte[] secret = Encoding.ASCII.GetBytes(_token.Secret);
            var claimsIdentity = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, user.Email),
                    new Claim(ClaimTypes.NameIdentifier, user.Email),
                    new Claim(ClaimTypes.Role, "roleName"),

                    new Claim(Convert.ToString(TokenEnum.EmailAddress), user.Email),
                    new Claim(Convert.ToString(TokenEnum.UserId), user.Id.ToString()),
                    new Claim(Convert.ToString(TokenEnum.intUserId), Convert.ToString(user.Id)),
                    new Claim(Convert.ToString(TokenEnum.FullName), user.Usr_Name),
                    new Claim(Convert.ToString(TokenEnum.Name), user.Email),
                    new Claim(Convert.ToString(TokenEnum.NameIdentifier), user.Email),
                }, isCookie ? CookieAuthenticationDefaults.AuthenticationScheme : JwtBearerDefaults.AuthenticationScheme);
            JwtSecurityTokenHandler handler = new JwtSecurityTokenHandler();
            SecurityTokenDescriptor descriptor = new SecurityTokenDescriptor
            {
                Issuer = _token.Issuer,
                Audience = _token.Audience,
                Subject = claimsIdentity,
                Expires = DateTime.UtcNow.AddMinutes(_token.Expiry),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(secret), SecurityAlgorithms.HmacSha256Signature)
            };

            var randomNumber = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
            }

            if (isCookie)
            {
                var authProperties = new AuthenticationProperties
                {
                    ExpiresUtc = DateTime.UtcNow.AddMinutes(_token.Expiry),
                    //AllowRefresh = <bool>,
                    // Refreshing the authentication session should be allowed.

                    //ExpiresUtc = DateTimeOffset.UtcNow.AddMinutes(10),
                    // The time at which the authentication ticket expires. A
                    // value set here overrides the ExpireTimeSpan option of
                    // CookieAuthenticationOptions set with AddCookie.

                    //IsPersistent = true,
                    // Whether the authentication session is persisted across
                    // multiple requests. When used with cookies, controls
                    // whether the cookie's lifetime is absolute (matching the
                    // lifetime of the authentication ticket) or session-based.

                    //IssuedUtc = <DateTimeOffset>,
                    // The time at which the authentication ticket was issued.

                    //RedirectUri = <string>
                    // The full path or absolute URI to be used as an http
                    // redirect response value.
                };

                await _httpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), authProperties);
            }
            SecurityToken token = handler.CreateToken(descriptor);
            return handler.WriteToken(token);
        }

    }
}