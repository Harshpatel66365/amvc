﻿using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Infrastructure.Identity.Models;
using System.Security.Claims;

namespace KobaWebApplication.Infrastructure.Services.Token
{
    /// <summary>
    ///     A collection of token related services
    /// </summary>
    public interface ITokenService
    {
        
    }
}