﻿using KobaWebApplication.DataAccess.Interface;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.DataEntities;
using KobaWebApplication.Models;
using Microsoft.EntityFrameworkCore;

namespace KobaWebApplication.DataAccess.Repositories
{
    public class LoginOptionDA : ILoginOptionDA
    {
        private readonly ApplicationDbContext _dbContext;

        public LoginOptionDA(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<List<BhandarViewModel>> GetBhandarListByUser(string userInt)
        {
            var bhandarList = await _dbContext.Bhandar_List
                .Where(b => _dbContext.User_Bhandar_Access_View
                    .Any(uba => uba.Bhandar_Code == b.Bhandar_Code && uba.Usr_Init == userInt))
                .OrderByDescending(b => b.IsDefault)
                .ThenBy(b => b.Bhandar_Short_Name)
                .Select(b => new BhandarViewModel
                {
                    BhandarCode = b.Bhandar_Code,
                    BhandarName = b.Bhandar_Name,
                    IsDefault = b.IsDefault
                })
                .ToListAsync();

            return bhandarList;
        }

        public async Task<List<BhandarGroupViewModel>> GetBhandarGroupsAsync(string userInitial)
        {
            var bhandarGroups = await _dbContext.Bhandar_Group_Inf
                .Where(bg => _dbContext.Bhandar_Group_Lnk
                    .Where(bgl => _dbContext.User_Bhandar_Access_View
                        .Any(ubav => ubav.Usr_Init == userInitial && ubav.Bhandar_Code == bgl.Bhandar_Code))
                    .Select(bgl => bgl.Group_Short_Name)
                    .Contains(bg.Group_Short_Name))
                .OrderBy(bg => bg.Group_Name).Select(b => new BhandarGroupViewModel
                {
                    GroupCode = b.Group_Short_Name,
                    GroupName = b.Group_Name
                })
                .ToListAsync();

            return bhandarGroups;
        }

        public async Task<List<LanguageViewModel>> GetLanguages()
        {
            return await _dbContext.R_Language
           .OrderBy(l => l.Language_ID)
           .Select(l => new LanguageViewModel
           {
               LanguageName = l.Language_Name,
               LanguageShortKey = l.LanguageShortKey
           })
           .ToListAsync();
        }

        public List<R_Message_List> GetMessages(string errorCode, int languageId)
        {
            if (string.IsNullOrEmpty(errorCode))
            {
                return new List<R_Message_List>();
            }

            var messageIds = errorCode
                .Split(',')
                .Distinct()
                .Select(id => int.Parse(id.Trim()))
                .ToList();

            return _dbContext.R_Message_List
                .Where(m => m.Language_Id == languageId && messageIds.Contains(m.Message_Id))
                .OrderBy(m => m.Message_Id)
                .ToList();
        }
    }
}