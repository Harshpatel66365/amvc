﻿using KobaWebApplication.DataAccess.Interface;
using KobaWebApplication.DataEntities;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Browser;
using Microsoft.EntityFrameworkCore;

namespace KobaWebApplication.DataAccess.Repositories
{
    public class HastPratDA : IHastPratDA
    {
        private readonly ApplicationDbContext _dbContext;

        public HastPratDA(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<bool> AddHastPratInfo(AddHastpratInfoRequest_Dto request)
        {
            try
            {
                _dbContext.HpInf.Add(new DataEntities.Models.HpInf()
                {
                    CatalogNo = request.CatalogNumber,
                    DharmaCode = request.Dharma,
                    FormNo = request.FormNumber,
                    ImportanceLevelCode = request.ImportanceLevel,
                    OldNo = request.OldNumber,
                    PgsNet = Convert.ToInt32(request.NetPages),
                    PurDonLotNo = Convert.ToInt32(request.PurDonLotNo),
                    LaksnCodeString = request.LakshanCodeString,
                    LipiShortName = request.Lipi,
                    LekhanPrakarShortName = request.LekhanPrakar,
                    MaterialShortName = request.MaterialPrakar,
                    PgsAvstGhtTot = Convert.ToInt32(request.AvastavikGhatateTotal),
                    PgsAvstGht = request.AvastavikGhatatePatra,
                    PurnataRemarkCode = Convert.ToInt32(request.PurnataRemarkCode),
                    PgsBdth = request.BadhtePatra,
                    PgsBdthTot = Convert.ToInt32(request.BadhteTotal),
                    PgsGht = request.GhatatePatra,
                    PgsGhtTot = Convert.ToInt32(request.GhatateTotal),
                    HpVishesh = request.PratVishesh,
                    PurnataShortName = request.Purnata,
                    PurnataRemark = request.PurnataVishesh,
                    HpNo = request.PratNumber,
                    HpTypeShortName = request.PratPrakar,
                    PgsLast = Convert.ToInt32(request.LastPage),
                    ReadershipLvl = request.ReadershipLevel
                });
                _dbContext.SaveChanges();
            }
            catch (Exception e)
            {

            }
            return true;
        }
        public async Task<List<City_State_Country_View>> GetCitiesList()
        {
            return await _dbContext.City_State_Country_View.ToListAsync();
        }
        public async Task<List<City_State_Country_View>> GetHpLinkCitiesList()
        {
            return await _dbContext.City_State_Country_View.ToListAsync();
        }

        public async Task<List<L_Dasha_Code>> GetdashaCodeList()
        {
            return await _dbContext.L_Dasha_Code.Where(x => x.For_Other == "Y").ToListAsync();
        }

        public async Task<List<L_Purnata_Code>> GetPurnataCodeList()
        {
            return await _dbContext.L_Purnata_Code.ToListAsync();
        }

        public async Task<List<L_Purnata_Remark_Code>> GetLPurnataRemarkCodeList()
        {
            return await _dbContext.L_Purnata_Remark_Code.ToListAsync();
        }
        public async Task<List<L_Dharma_Code>> GetLDharmaCodeList()
        {
            return await _dbContext.L_Dharma_Code.ToListAsync();
        }
        public async Task<List<HP_PDF_LNK>> GetHpPdfLinkList()
        {
            try
            {
                return await _dbContext.HP_PDF_LNK.ToListAsync();
            }
            catch (Exception w)
            {
                return null;
            }
        }

        public async Task<IQueryable<Hp_Inf_View>> GetHaspPratDataList()
        {
            try
            {
                return _dbContext.Hp_Inf_View;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IQueryable<Hp_Petank_View>> GetPetaAnkDataList()
        {
            try
            {
                return _dbContext.Hp_Petank_View;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IQueryable<Hp_Shlok_Lnk_View>> GetHpShlokLnkDataList()
        {
            try
            {
                return _dbContext.Hp_Shlok_Lnk_View;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}