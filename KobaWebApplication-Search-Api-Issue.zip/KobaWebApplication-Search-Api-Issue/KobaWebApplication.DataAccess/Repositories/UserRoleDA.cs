﻿using Microsoft.AspNetCore.Identity;
using KobaWebApplication.Core.UserDefinedException;
using KobaWebApplication.DataAccess.Generic;
using KobaWebApplication.DataAccess.Interface;
using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto;
using Microsoft.EntityFrameworkCore;
using KobaWebApplication.DataEntities;

namespace KobaWebApplication.DataAccess.Repositories
{
    public class UserRoleDA : IUserRoleDA
    {
        private readonly ApplicationDbContext _context;

        public UserRoleDA(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task AssignRoleToUserAsync(long userId, int roleId)
        {
            var Existing =_context.UserRoles.Where(x => x.UserId == userId).ToList().FirstOrDefault();
            if (Existing != null)
            {
                _context.UserRoles.Remove(Existing);
            }
            var userRole = new UserRole { UserId = userId, RoleId = roleId };
            _context.UserRoles.Add(userRole);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Role>> GetUserRolesAsync(long userId)
        {
            return await _context.UserRoles
                .Where(ur => ur.UserId == userId)
                .Join(_context.Roles, ur => ur.RoleId, r => r.Id, (ur, r) => r)
                .ToListAsync();
        }
    }
}