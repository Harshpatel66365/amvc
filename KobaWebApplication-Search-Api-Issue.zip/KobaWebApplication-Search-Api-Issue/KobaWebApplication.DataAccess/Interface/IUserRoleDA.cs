﻿using Microsoft.AspNetCore.Identity;
using KobaWebApplication.DataEntities.Models;

namespace KobaWebApplication.DataAccess.Interface
{
    public interface IUserRoleDA
    {
        public Task AssignRoleToUserAsync(long userId, int roleId);
        public Task<List<Role>> GetUserRolesAsync(long userId);
    }
}