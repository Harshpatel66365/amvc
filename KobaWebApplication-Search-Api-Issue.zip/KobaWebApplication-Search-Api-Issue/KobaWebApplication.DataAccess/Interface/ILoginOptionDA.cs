﻿using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Models;

namespace KobaWebApplication.DataAccess.Interface
{
    public interface ILoginOptionDA
    {
        public Task<List<BhandarViewModel>> GetBhandarListByUser(string userInt);
        public Task<List<BhandarGroupViewModel>> GetBhandarGroupsAsync(string userInitial);
        public Task<List<LanguageViewModel>> GetLanguages();
        public List<R_Message_List> GetMessages(string errorCode, int languageId);
    }
}