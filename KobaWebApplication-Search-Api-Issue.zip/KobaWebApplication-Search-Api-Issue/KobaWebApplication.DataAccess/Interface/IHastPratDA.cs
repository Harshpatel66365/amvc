﻿using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.Dto.Browser;

namespace KobaWebApplication.DataAccess.Interface
{
    public interface IHastPratDA
    {
        Task<bool> AddHastPratInfo(AddHastpratInfoRequest_Dto? request);
        public Task<List<City_State_Country_View>> GetCitiesList();

        public Task<List<L_Dasha_Code>> GetdashaCodeList();

        public Task<List<L_Purnata_Code>> GetPurnataCodeList();

        public Task<List<L_Purnata_Remark_Code>> GetLPurnataRemarkCodeList();

        public Task<IQueryable<Hp_Inf_View>> GetHaspPratDataList();

        public Task<IQueryable<Hp_Petank_View>> GetPetaAnkDataList();

        public Task<IQueryable<Hp_Shlok_Lnk_View>> GetHpShlokLnkDataList();
        public Task<List<L_Dharma_Code>> GetLDharmaCodeList();
        public Task<List<HP_PDF_LNK>> GetHpPdfLinkList();
    }
}