﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace KobaWebApplication.DataEntities.Models
{
    [Table("ActivityLogs")]
    public class ActivityLogs
    {
        [Key]
        public int ActivityLogID { get; set; }

        public int SubjectTypeId { get; set; }
        public long SubjectId { get; set; } = default!;

        [DisplayName("Description")]
        public string Description { get; set; } = default!;

        [DisplayName("Action")]
        public string Action { get; set; } = default!;

        public int CreatedBy { get; set; }

        [DisplayName("Activity Date")]
        public DateTimeOffset CreatedDate { get; set; }

        public DateTime CreatedUTCDate { get; set; }

        [DisplayName("Remarks")]
        public string? Remarks { get; set; }
    }
}