﻿using System.ComponentModel.DataAnnotations;

namespace KobaWebApplication.DataEntities.Models
{
    public class L_Remark_Master
    {
        public int Remark_Serial_No { get; set; }
        public DateTime Email_Receive_Date { get; set; }
        public DateTime Report_Receive_Date { get; set; }
        public DateTime Remark_Entry_Date { get; set; }
        public string Document_Name { get; set; }
        public string Email_Document_Name { get; set; }
        public string Main_Sec_Short_Name { get; set; }
        public string? Other_Sec_Short_Name { get; set; }
        public string Main_Sec_User_Init { get; set; }
        public string? Other_Sec_User_Init { get; set; }
        public string Remark_Image_Path { get; set; }
        public string Remark_Image_Message { get; set; }
        public string? Remark_User_Reply { get; set; }
        public DateTime? Remark_User_Reply_Date { get; set; }
        public string? Remark_Sec_Head_Reply { get; set; }
        public DateTime? Remark_Sec_Head_Reply_Date { get; set; }
        public string? Remark_Admin_Reply { get; set; }
        public DateTime? Remark_Admin_Reply_Date { get; set; }
        public DateTime? Remark_Return_Date { get; set; }
        public string? Remark_Conclusion { get; set; }
        public DateTime? Remark_Conclusion_Date { get; set; }
        public string Remark_Status_Short_Name { get; set; }
        public int Is_Parent_Remark { get; set; }
        public string? Remark_Type { get; set; }
    }

}
