﻿using System.ComponentModel.DataAnnotations;

namespace KobaWebApplication.DataEntities.Models
{
    public class Mag_Bind_Edit_Request
    {
        [Key]
        public int Msg_No { get; set; }
        public string Bhandar_Code { get; set; }
        public string Bind_No { get; set; }
        public string? Ank_Copy_Accession_No { get; set; }
        public string Sender_Init { get; set; }
        public string Sender_Msg { get; set; }
        public string Receiver_init { get; set; }
        public string? Receiver_Reply { get; set; }
        public string Urgency_Type_Short_name { get; set; }
        public string Status_Short_Name { get; set; }
        public DateTime Send_Dt { get; set; }
        public DateTime? Reply_Dt { get; set; }
        public string Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }
        public DateTime? Add_Date_Time { get; set; }
        public DateTime? Updt_Date_Time { get; set; }
        public DateTime? Edit_Date_Time { get; set; }
        public DateTime? Certi_Date_Time { get; set; }
    }

}
