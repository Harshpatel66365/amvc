﻿namespace KobaWebApplication.DataEntities.Models
{
    public class BaseEntity
    {
        public bool IsDeleted { get; set; }
        public int CreatedBy { get; set; }
        public DateTimeOffset CreatedDate { get; set; }
        public DateTime CreatedUTCDate { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTimeOffset? UpdatedDate { get; set; }
        public DateTime? UpdatedUTCDate { get; set; }
    }
}