﻿using System.ComponentModel.DataAnnotations;

namespace KobaWebApplication.DataEntities.Models
{
    public class Hp_Internal_Issue
    {
        [Key]
        public int Tran_No { get; set; }
        public string Bhandar_Code { get; set; }
        public string Hp_No { get; set; }
        public DateTime Request_On_Dt { get; set; }
        public string To_Whom { get; set; }
        public string? Issue_Init { get; set; }
        public DateTime? Issue_Dt { get; set; }
        public string? Receiver_Init { get; set; }
        public DateTime? Received_By_User_Dt { get; set; }
        public DateTime? Returned_By_User_Dt { get; set; }
        public string? Issue_Type_Short_name { get; set; }
        public string Request_Cancelled { get; set; }
        public string Is_Lost { get; set; }
        public string Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public int? Updt_Authority_Level { get; set; }
    }
}
