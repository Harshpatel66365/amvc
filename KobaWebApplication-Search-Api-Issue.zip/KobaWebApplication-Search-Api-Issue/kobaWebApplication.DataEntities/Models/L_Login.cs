﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KobaWebApplication.DataEntities.Models
{
    public class L_Login
    {
        [Key]
        public string Usr_Init { get; set; }

        public DateTime Login_Time { get; set; }

        public DateTime? LogOut_Time { get; set; }

        public string Machine_Name { get; set; }
    }

}
