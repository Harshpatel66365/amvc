﻿namespace KobaWebApplication.DataEntities.Models
{
    public class L_Gmandir_Messages
    {
        public int Message_id { get; set; }
        public DateTime Message_Date { get; set; }
        public string Message { get; set; }
        public string Display_Flag { get; set; }
        public int? Total_Facility { get; set; }
    }
}
