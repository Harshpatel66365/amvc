﻿using System.ComponentModel.DataAnnotations;

namespace KobaWebApplication.DataEntities.Models
{
    public class Pblsr_Unique_Suggestion
    {
        [Key]
        public int Unique_Suggestion_Id { get; set; }
        public string Destination_Pblsr_Key { get; set; }
        public string Source_Pblsr_Key { get; set; }
        public string Unique_Type_Short_Name { get; set; }
        public DateTime Send_Dt { get; set; }
        public string Send_Msg { get; set; }
        public string Receiver_Init { get; set; }
        public DateTime? Reply_Dt { get; set; }
        public string? Reply_Msg { get; set; }
        public string? Status_Short_Name { get; set; }
        public string? Remark { get; set; }
        public string Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }
    }

}
