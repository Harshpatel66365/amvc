﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KobaWebApplication.DataEntities.Models
{
    public class User_Technical_Data_Detail
    {
        [Key]
        public int Record_id { get; set; }

        public string User_Init { get; set; }

        public string Rec_Type { get; set; }

        public string Main_Key { get; set; }

        public string Sub_Key { get; set; }

        public string Pet_No { get; set; }

        public DateTime Date_Time { get; set; }

        public string Proc_Type { get; set; }

        public string Prakar_type_short_name { get; set; }

        public string Entry_Time_Duration { get; set; }

        //public YNType? Between_11_15 { get; set; }

        //public YNType? Between_16_20 { get; set; }

        //public YNType? Above_20 { get; set; }

        public string User_Remark { get; set; }

        public string Authority_Remark { get; set; }

        public string Authirity_Init { get; set; }

        //public YNType? IsApproved { get; set; }

        public string NonProjectTime { get; set; }

        public string DisApprovedTime { get; set; }

        public string LunchTime { get; set; }

        public string TeaTime { get; set; }

        public string DiscussionTime { get; set; }

        public string FlagType { get; set; }

        public string TypeOfRecord { get; set; }

        public DateTime? Add_Date_Time { get; set; }

        public DateTime? Updt_Date_Time { get; set; }

        public DateTime? Certi_Date_Time { get; set; }

        //public YNType? LockedRow { get; set; }

        public string VachakSevaTime { get; set; }

        public string AdminKaryaTime { get; set; }
    }

}
