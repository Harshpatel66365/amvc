﻿namespace KobaWebApplication.DataEntities.Result
{
    public class UserScoreBoardViewModel
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public List<UserAddUpdateScoreBoard_Response> _ScoreDetails { get; set; }
    }
    public class UserAddUpdateScoreBoard_Response
    {
        public string TableName { get; set; }
        public int Add_Record_Count { get; set; }
        public int Update_Record_Count { get; set; }
    }
}
