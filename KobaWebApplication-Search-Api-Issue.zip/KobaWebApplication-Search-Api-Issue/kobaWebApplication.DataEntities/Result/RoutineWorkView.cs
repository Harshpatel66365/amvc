﻿namespace KobaWebApplication.DataEntities.Result
{
    public class RoutineWorkView
    {
        public int Routine_Work_Id { get; set; }
        public string Title { get; set; }
        public string Custom_Msg { get; set; }
        public string? User_Group_Short_Name { get; set; }
        public string Main_Attending_Person { get; set; }
        public string? Alternate_Attending_Person { get; set; }
        public DateTime Msg_Dt { get; set; }
        public string Start_Remind_Duration_Day { get; set; }
        public string Duration_Short_name { get; set; }
        public DateTime Duration_Deadline_Dt { get; set; }
        public string? Show_Msg { get; set; }
        public string? DoneBy_Init { get; set; }
        public DateTime? DoneOn_Dt { get; set; }
        public string? Add_init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }
    }

}
