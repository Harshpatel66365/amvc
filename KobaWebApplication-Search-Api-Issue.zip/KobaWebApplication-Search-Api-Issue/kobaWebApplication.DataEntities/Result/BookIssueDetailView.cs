﻿namespace KobaWebApplication.DataEntities.Result
{
    public class BookIssueDetailView
    {
        public string Bhandar_Code { get; set; } 
        public string Book_No { get; set; }
        public string Is_Lost { get; set; }
        public int Issue_Tran_No { get; set; }
        public DateTime? Issue_date { get; set; } 
        public string? Issue_init { get; set; }
        public DateTime? Expected_date { get; set; } 
        public DateTime? Receipt_Dt { get; set; } 
        public string? Reciever_Init { get; set; }
        public string? Prksn_Nam { get; set; }
        public string? Vol_Sub_Vol { get; set; }
        public string? Reader_No { get; set; }
        public int? Receipt_Tran_No { get; set; }
        public string? Book_Remark { get; set; }
        public string? L_Ext_Iss_Gatepass_Remark { get; set; }
        public string? L_Ext_Iss_Detail_Remark { get; set; }
        public string Prksn_Key { get; set; }
        public string? Certifier { get; set; }
    }
}
