﻿namespace KobaWebApplication.DataEntities.Result
{
    public class GPendingWorkView
    {
        public decimal Pending_Id { get; set; }
        public string Pending_Work { get; set; }
        public DateTime P_Date { get; set; }
        public DateTime Deadline_dt { get; set; }
        public string? For_Whom { get; set; }
        public string? Remark { get; set; }
        public string Main_Attending_Person { get; set; }
        public string Alternate_Attending_Person { get; set; }
        public DateTime Reminder_St_Dt { get; set; }
        public string? Attending_User_Group_Short_Name { get; set; }
        public string Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public string? Section_Short_Name { get; set; }
        public string? Section_Name { get; set; }
        public string? Urgency_Type_name { get; set; }
        public string? Urgency_Type_Short_name { get; set; }
        public string? Status_name { get; set; }
        public string? Status_Short_name { get; set; }
        public string? User_Group_Name { get; set; }
        public string? User_Group_Short_Name { get; set; }
    }

}
