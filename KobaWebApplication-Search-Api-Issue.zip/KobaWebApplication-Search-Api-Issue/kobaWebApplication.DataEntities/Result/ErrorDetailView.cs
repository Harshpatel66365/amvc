﻿namespace KobaWebApplication.DataEntities.Result
{
    public class ErrorDetailView
    {
        public int ErrorID { get; set; }
        public string? Error_Description { get; set; }
        public string? Error_Status_Description { get; set; }
        public DateTime? Error_PostDate { get; set; }
        public string? Programmer_Remark { get; set; }
        public string? TypeOfError { get; set; }
        public string? Urgency_Type_Short_name { get; set; }
        public string? User_Reply { get; set; }
        public string? Entity { get; set; }
        public string? Entity_Field { get; set; }
        public string? Programmer_Init { get; set; }
        public DateTime? Error_Solved_Date { get; set; }
        public string? Error_Image_Path { get; set; }
        public string? User_Init { get; set; }
    }

}
