﻿namespace KobaWebApplication.DataEntities.Result
{
    public class L_DailyView
    {
        public int Daily_Id { get; set; }
        public DateTime Sess_datetime { get; set; }
        public string Leave { get; set; }
        public string Half_Day { get; set; }
        public string Dutyleave { get; set; }
        public string? Arrival { get; set; }
        public string? Departure { get; set; }
        public string? Recess { get; set; }
        public string? Tea_break { get; set; }
        public string? Main_Work { get; set; }
        public string? Main_Desc { get; set; }
        public string? Work_Output { get; set; }
        public string? M_Rel_Work { get; set; }
        public string? M_Rel_Desc { get; set; }
        public string? M_Rel_Output { get; set; }
        public string? Other_Work { get; set; }
        public string? Other_Desc { get; set; }
        public string? Other_Output { get; set; }
        public string? Disturb { get; set; }
        public string? Disturb_Desc { get; set; }
        public string? Remark { get; set; }
        public string? Supervisor_Remark { get; set; }
        public DateTime? Supervisor_Remark_Dt { get; set; }
        public string? User_Reply { get; set; }
        public DateTime? User_Reply_Dt { get; set; }
        public string? Supervisor_Remark_Status_Code { get; set; }
        public string Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }
        public string? Status_Short_name { get; set; }
        public string? UserName { get; set; }
        public string? Usr_Init { get; set; }
    }

}
