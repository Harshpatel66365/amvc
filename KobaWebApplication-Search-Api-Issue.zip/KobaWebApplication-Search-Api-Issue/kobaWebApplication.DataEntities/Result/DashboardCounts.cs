﻿using Microsoft.Identity.Client;

namespace KobaWebApplication.DataEntities.Result
{
    public class DashboardCounts
    {
        public int Kr_Edit_Sender_Count { get; set; }
        public int Kr_Edit_Receiver_Count { get; set; }
        public int Hp_Edit_Sender_Count { get; set; }
        public int Hp_Edit_Receiver_Count { get; set; }
        public int Vid_Edit_Sender_Count { get; set; }
        public int Vid_Edit_Receiver_Count { get; set; }
        public int Vid_Gach_Edit_Sender_Count { get; set; }
        public int Vid_Gach_Edit_Receiver_Count { get; set; }
        public int Mag_Edit_Sender_Count { get; set; }
        public int Mag_Edit_Receiver_Count { get; set; }
        public int Prksn_Edit_Sender_Count { get; set; }
        public int Prksn_Edit_Receiver_Count { get; set; }
        public int Pblsr_Edit_Sender_Count { get; set; }
        public int Pblsr_Edit_Receiver_Count { get; set; }
        public int Mag_EditBind_Sender_Count { get; set; }
        public int Mag_EditBind_Receiver_Count { get; set; }
        public int Kr_Unique_Sugg_Sender_Count { get; set; }
        public int Kr_Unique_Sugg_Receiver_Count { get; set; }
        public int Vid_Unique_Sugg_Sender_Count { get; set; }
        public int Vid_Unique_Sugg_Receiver_Count { get; set; }
        public int Pblsr_Unique_Sugg_Sender_Count { get; set; }
        public int Pblsr_Unique_Sugg_Receiver_Count { get; set; }
        public int Prksn_Unique_Sugg_Sender_Count { get; set; }
        public int Prksn_Unique_Sugg_Receiver_Count { get; set; }
        public int Vid_Gach_Unique_Sugg_Sender_Count { get; set; }
        public int Vid_Gach_Unique_Sugg_Receiver_Count { get; set; }
        public int GPending_Work_FromView_Count { get; set; }
        public int GPending_Routin_FromView_Count { get; set; }
        public int LRemark_Master_Sender_Count { get; set; }
        public int LRemark_Master_Receiver_Count { get; set; }
        public int Hp_InternalIssue_ToWhom_Count { get; set; }
        public int Hp_Issue_Pending_Count { get; set; }
        public int Hp_Issued_ButNot_Returned_Count { get; set; }
        public int User_Error_Posted_Count { get; set; }
        public int User_Error_Solved_Count { get; set; }
        public int User_Error_Pedning_Count { get; set; }
        public int User_Error_ExplainationNeed_Count { get; set; }
        public int User_Errors_Completed_Count { get; set; }
        public int User_Suggestion_Posted_Count { get; set; }
        public int Daily_WorkLogs_FromView_Count { get; set; }
        public int Book_Overdue_Daily_Count {get; set; }
	    public int Book_Overdue_Weekly_Count {get; set; }
	    public int Book_Overdue_Monthly_Count {get; set; }
	    public int Book_Overdue_Old_Count {get; set; }
	    public int Book_Followup_Pending_Overdue_Count { get; set; }
        public int Yours_Edit_Req_Total_Counts
        {
            get
            {
                return Kr_Edit_Sender_Count + Hp_Edit_Sender_Count + Vid_Edit_Sender_Count
                       + Vid_Gach_Edit_Sender_Count + Mag_Edit_Sender_Count
                       + Prksn_Edit_Sender_Count + Pblsr_Edit_Sender_Count
                       + Mag_EditBind_Sender_Count;
            }
        }
        public int Others_Edit_Req_Total_Counts
        {
            get
            {
                return Kr_Edit_Receiver_Count + Hp_Edit_Receiver_Count + Vid_Edit_Receiver_Count + Vid_Gach_Edit_Receiver_Count + Mag_Edit_Receiver_Count + Prksn_Edit_Receiver_Count
                + Pblsr_Edit_Receiver_Count + Mag_EditBind_Receiver_Count;
            }
        }
        public int Yours_Unique_Sugg_Total_Counts
        {
            get
            {
                return Kr_Unique_Sugg_Sender_Count + Vid_Unique_Sugg_Sender_Count + Pblsr_Unique_Sugg_Sender_Count + Prksn_Unique_Sugg_Sender_Count + Vid_Gach_Unique_Sugg_Sender_Count;
            }
        }
        public int Others_Unique_Sugg_Total_Counts
        {
            get
            {
                return Kr_Unique_Sugg_Receiver_Count + Vid_Unique_Sugg_Receiver_Count + Pblsr_Unique_Sugg_Receiver_Count + Prksn_Unique_Sugg_Receiver_Count + Vid_Gach_Unique_Sugg_Receiver_Count;
            }
        }
        public int User_Error_Sugg_Score_Board_Total_Counts
        {
            get
            {
                return User_Error_Posted_Count + User_Error_Solved_Count + User_Error_Pedning_Count + User_Error_ExplainationNeed_Count + User_Errors_Completed_Count + User_Suggestion_Posted_Count;
            }          
        }
        public int Hp_Internal_Issue_Total_Count
        {
            get
            {
                return Hp_InternalIssue_ToWhom_Count + Hp_Issue_Pending_Count + Hp_Issued_ButNot_Returned_Count;
            }
        }
    }
}                     
                       