﻿namespace KobaWebApplication.DataEntities.Result
{
    public class OverdueBookFollowupDetail
    {
        public decimal Followup_Id { get; set; }
        public string Reader_No { get; set; }
        public DateTime? Date_Suggested { get; set; }
        public string Followup_Media { get; set; }
        public string? Remark { get; set; }
        public string? Overdue_Followup_Status { get; set; }
        public string Add_Init { get; set; }
        public string? Updt_Init { get; set; }
        public string? Last_Edtr { get; set; }
        public string? Certifier { get; set; }
        public int? Updt_Authority_Level { get; set; }
        public int? Certifier_Authority_Level { get; set; }
        public DateTime? Add_Date_Time { get; set; }
        public DateTime? Updt_Date_Time { get; set; }
        public DateTime? Edit_Date_Time { get; set; }
        public DateTime? Certi_Date_Time { get; set; }
    }

}
