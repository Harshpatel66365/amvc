﻿using KobaWebApplication.DataEntities.Models;
using KobaWebApplication.DataEntities.Result;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using System.ComponentModel;
using System.Reflection;

namespace KobaWebApplication.DataEntities
{
    public partial class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<User_Bhandar_Access_View>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("User_Bhandar_Access_View");
            });
            builder.Entity<UserRole>().HasKey(ur => new { ur.UserId, ur.RoleId }); // Define composite primary key

            builder.Entity<L_User>(entity =>
            {
                entity.Property(u => u.Id).UseIdentityColumn();
                entity.Property(x => x.Id).Metadata.SetAfterSaveBehavior(PropertySaveBehavior.Ignore);
            });

            builder.Entity<GPendingWorkView>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("G_Pending_Work_View");
            });

            builder.Entity<RoutineWorkView>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("G_Routine_Work_View");
            });

            builder.Entity<BookIssueDetailView>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("Book_Issue_Detail_View");
            });

            builder.Entity<OverdueBookFollowupDetail>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("Overdue_Book_Followup_Detail");
            });

            builder.Entity<ErrorDetailView>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("L_Error_Details_View");
            });

            builder.Entity<L_DailyView>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("l_daily_view");
            });

            builder.Entity<UserAddUpdateScoreBoard_Response>(entity =>
            {
                entity.HasNoKey();
            });

            builder.Entity<DashboardCounts>(entity =>
            {
                entity.HasNoKey();
            });

            builder.Entity<L_Remark_Master>(entity =>
            {
                entity.HasNoKey();
            });

            builder.Entity<L_Gmandir_Messages>(entity =>
            {
                entity.HasNoKey();
            });
            builder.Entity<City_State_Country_View>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("City_State_Country_View");
            });
            builder.Entity<L_Dasha_Code>(entity =>
            {
                entity.HasNoKey();
            });
            builder.Entity<L_Purnata_Code>(entity =>
            {
                entity.HasNoKey();
            });
            builder.Entity<L_Purnata_Remark_Code>(entity =>
            {
                entity.HasNoKey();
            });
            builder.Entity<Hp_Inf_View>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("Hp_Inf_View");
            });
            builder.Entity<Hp_Petank_View>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("Hp_Petank_View");
            });
            builder.Entity<HpInf>(entity =>
            {
                entity.HasKey(h => new { h.HpNo, h.BhandarCode });
                entity.ToTable("Hp_Inf");
            });

            builder.Entity<Hp_Shlok_Lnk_View>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("Hp_Shlok_Lnk_View");
            });
            builder.Entity<L_Dharma_Code>(entity =>
            {
                entity.HasNoKey();
            }); 
            builder.Entity<HP_PDF_LNK>(entity =>
            {
                entity.HasNoKey();
            });
        }

        public DbSet<L_User> L_User { get; set; }
        public DbSet<L_Login> L_Login { get; set; }
        public DbSet<User_Technical_Data_Detail> User_Technical_Data_Detail { get; set; }
        public DbSet<Bhandar_List> Bhandar_List { get; set; }
        public DbSet<User_Bhandar_Access_View> User_Bhandar_Access_View { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }
        public DbSet<Bhandar_Group_Inf> Bhandar_Group_Inf { get; set; }
        public DbSet<Bhandar_Group_Lnk> Bhandar_Group_Lnk { get; set; }
        public DbSet<R_Language> R_Language { get; set; }
        public DbSet<R_Message_List> R_Message_List { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<RoleClaim> RoleClaims { get; set; }
        public DbSet<Kr_Edit_Request> Kr_Edit_Request { get; set; }
        public DbSet<Hp_Edit_Request> Hp_Edit_Request { get; set; }
        public DbSet<HpInf> HpInf { get; set; }
        public DbSet<Vid_Edit_Request> Vid_Edit_Request { get; set; }
        public DbSet<Vid_Gach_Edit_Request> Vid_Gach_Edit_Request { get; set; }
        public DbSet<Mag_Edit_Request> Mag_Edit_Request { get; set; }
        public DbSet<Prksn_Edit_Request> Prksn_Edit_Request { get; set; }
        public DbSet<Pblsr_Edit_Request> Pblsr_Edit_Request { get; set; }
        public DbSet<Mag_Bind_Edit_Request> Mag_Bind_Edit_Request { get; set; }
        public DbSet<Kr_Unique_Suggestion> Kr_Unique_Suggestion { get; set; }
        public DbSet<Vid_Unique_Suggestion> Vid_Unique_Suggestion { get; set; }
        public DbSet<Vid_Gach_Unique_Suggestion> Vid_Gach_Unique_Suggestion { get; set; }
        public DbSet<Pblsr_Unique_Suggestion> Pblsr_Unique_Suggestion { get; set; }
        public DbSet<Prksn_Unique_Suggestion> Prksn_Unique_Suggestion { get; set; }
        public DbSet<GPendingWorkView> GPendingWorkView { get; set; }
        public DbSet<RoutineWorkView> RoutineWorkView { get; set; }
        public DbSet<L_Remark_Master> L_Remark_Master { get; set; }
        public DbSet<BookIssueDetailView> Book_Issue_Detail_View { get; set; }
        public DbSet<OverdueBookFollowupDetail> OverdueBookFollowupDetail { get; set; }
        public DbSet<ErrorDetailView> ErrorDetailView { get; set; }
        public DbSet<Hp_Internal_Issue> Hp_Internal_Issue { get; set; }
        public DbSet<UserAddUpdateScoreBoard_Response> UserAddUpdateScoreBoard_Response { get; set; }
        public DbSet<L_DailyView> L_DailyView { get; set; }
        public DbSet<DashboardCounts> DashboardCounts { get; set; }
        public DbSet<L_Gmandir_Messages> L_Gmandir_Messages { get; set; }
        public DbSet<City_State_Country_View> City_State_Country_View { get; set; }
        public DbSet<L_Dasha_Code> L_Dasha_Code { get; set; }
        public DbSet<L_Purnata_Code> L_Purnata_Code { get; set; }
        public DbSet<L_Purnata_Remark_Code> L_Purnata_Remark_Code { get; set; }
        public DbSet<Hp_Inf_View> Hp_Inf_View { get; set; }
        public DbSet<Hp_Petank_View> Hp_Petank_View { get; set; }
        public DbSet<Hp_Shlok_Lnk_View> Hp_Shlok_Lnk_View { get; set; }
        public DbSet<L_Dharma_Code> L_Dharma_Code { get; set; }
        public DbSet<HP_PDF_LNK> HP_PDF_LNK { get; set; }

        #region Capture Audit Logs

        //public List<AuditLogs> OnBeforeSaveChanges(long userId, Dictionary<string, string> captionValues)
        //{
        //    string[] excludeColumnNames = { "isdeleted", "categorytypeid", "tenantid", "updatedby", "updateddate", "updatedutcdate", "createdby", "createddate", "createdutcdate", "lastmodifiedby", "lastmodifieddate", "lastmodifiedutcdate" };
        //    List<AuditLogs> lstAuditLogs = new List<AuditLogs>();

        //    ChangeTracker.DetectChanges();
        //    var auditEntries = new List<AuditEntry>();
        //    foreach (var entry in ChangeTracker.Entries())
        //    {
        //        if (entry.Entity is AuditLogs || entry.State == EntityState.Detached || entry.State == EntityState.Unchanged)
        //            continue;

        //        if (entry.State == EntityState.Modified)
        //            captionValues = GetDisplayNameValue(entry.Entity);

        //        long primaryKeyValue = 0;
        //        foreach (var property in entry.Properties)
        //        {
        //            string tableName = entry.Entity.GetType().Name;
        //            string propertyName = property.Metadata.Name;

        //            if (excludeColumnNames.Contains(propertyName.ToLower()))
        //                continue;

        //            var auditEntry = new AuditEntry(entry);
        //            auditEntry.TableName = tableName;
        //            auditEntry.CreatedBy = userId;

        //            auditEntry.CaptionName = captionValues.ContainsKey(propertyName) ? captionValues[propertyName] : string.Empty;

        //            if (property.Metadata.IsPrimaryKey())
        //            {
        //                primaryKeyValue = Convert.ToInt64(property.CurrentValue);
        //                auditEntry.TableKey = primaryKeyValue;
        //                continue;
        //            }

        //            switch (entry.State)
        //            {
        //                case EntityState.Added:
        //                    auditEntry.TableKey = primaryKeyValue;
        //                    auditEntry.FieldName = propertyName;
        //                    auditEntry.Actions = "Insert";
        //                    auditEntry.NewValue = Convert.ToString(property.CurrentValue);
        //                    break;

        //                case EntityState.Deleted:
        //                    auditEntry.TableKey = primaryKeyValue;
        //                    auditEntry.FieldName = propertyName;
        //                    auditEntry.Actions = "Delete";
        //                    auditEntry.OldValue = Convert.ToString(property.OriginalValue);
        //                    break;

        //                case EntityState.Modified:
        //                    if (property.IsModified)
        //                    {
        //                        if (Convert.ToString(property.OriginalValue) == Convert.ToString(property.CurrentValue))
        //                            break;

        //                        auditEntry.TableKey = primaryKeyValue;
        //                        auditEntry.FieldName = propertyName;
        //                        auditEntry.Actions = "Update";
        //                        auditEntry.OldValue = Convert.ToString(property.OriginalValue);
        //                        auditEntry.NewValue = Convert.ToString(property.CurrentValue);
        //                        break;
        //                    }
        //                    break;
        //            }

        //            if (!string.IsNullOrEmpty(auditEntry.FieldName) && (!string.IsNullOrEmpty(auditEntry.OldValue) || !string.IsNullOrEmpty(auditEntry.NewValue)))
        //                auditEntries.Add(auditEntry);
        //        }
        //    }

        //    foreach (var auditEntry in auditEntries)
        //    {
        //        if (auditEntry.Actions == "Insert") {
        //            lstAuditLogs.Add(auditEntry.ToAudit());
        //        }
        //        else {
        //            //AuditLogs.Add(auditEntry.ToAudit());
        //        }
        //    }

        //    return lstAuditLogs;
        //}

        private Dictionary<string, string> GetDisplayNameValue<T>(T entity)
        {
            Dictionary<string, string> keyValuePairs = new Dictionary<string, string>();
            PropertyInfo[] properties = entity.GetType().GetProperties();
            foreach (PropertyInfo property in properties)
            {
                var attribute = Attribute.GetCustomAttribute(property, typeof(DisplayNameAttribute)) as DisplayNameAttribute;
                if (attribute != null)
                    keyValuePairs.Add(property.Name, attribute.DisplayName);
                else
                    keyValuePairs.Add(property.Name, property.Name);
            }
            return keyValuePairs;
        }

        //public void OnAfterSaveChanges(List<AuditLogs> lstAuditLogs, long primaryKeyValue)
        //{
        //    lstAuditLogs.ForEach(x => x.TableKey = primaryKeyValue);
        //    foreach (var auditEntry in lstAuditLogs) { }
        //        //AuditLogs.Add(auditEntry);
        //}

        //public class AuditEntry
        //{
        //    public AuditEntry(EntityEntry entry)
        //    {
        //        Entry = entry;
        //    }

        //    public EntityEntry Entry { get; }
        //    public long TableKey { get; set; }
        //    public string TableName { get; set; }
        //    public string FieldName { get; set; }
        //    public string CaptionName { get; set; }
        //    public string? OldValue { get; set; }
        //    public string? NewValue { get; set; }
        //    public string Actions { get; set; }
        //    public long CreatedBy { get; set; }

        //    public AuditLogs ToAudit()
        //    {
        //        var audit = new AuditLogs();
        //        audit.Actions = Actions;
        //        audit.TableName = TableName;
        //        audit.TableKey = TableKey;
        //        audit.FieldName = FieldName;
        //        audit.CaptionName = CaptionName;
        //        audit.OldValue = OldValue;
        //        audit.NewValue = NewValue;
        //        audit.CreatedBy = CreatedBy;
        //        audit.CreatedDate = DateTimeOffset.Now;
        //        audit.CreatedUTCDate = DateTime.UtcNow;
        //        return audit;
        //    }
        //}

        #endregion Capture Audit Logs
    }
}